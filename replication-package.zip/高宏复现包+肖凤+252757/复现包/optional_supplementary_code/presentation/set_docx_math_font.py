#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Set default Word math font in a DOCX.

Pandoc-generated equations become OMML objects. Word usually renders them
using Cambria Math. This script injects (or updates) settings.xml:

<w:mathPr><w:mathFont w:val="Times New Roman"/></w:mathPr>

so equations are rendered in Times New Roman.
"""

from __future__ import annotations

import sys
import zipfile
import xml.etree.ElementTree as ET
from pathlib import Path


NS = {
    "w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
}


def qn(tag: str) -> str:
    prefix, local = tag.split(":", 1)
    return f"{{{NS[prefix]}}}{local}"


def set_math_font(docx_path: Path, font_name: str = "Times New Roman"):
    tmp_path = docx_path.with_suffix(docx_path.suffix + ".tmp")

    with zipfile.ZipFile(docx_path, "r") as zin, zipfile.ZipFile(tmp_path, "w") as zout:
        for item in zin.infolist():
            data = zin.read(item.filename)
            if item.filename != "word/settings.xml":
                zout.writestr(item, data)
                continue

            root = ET.fromstring(data)

            mathPr = root.find(qn("w:mathPr"))
            if mathPr is None:
                mathPr = ET.Element(qn("w:mathPr"))
                # place it near the top for readability
                root.insert(0, mathPr)

            mathFont = mathPr.find(qn("w:mathFont"))
            if mathFont is None:
                mathFont = ET.SubElement(mathPr, qn("w:mathFont"))

            mathFont.set(qn("w:val"), font_name)

            xml_bytes = ET.tostring(root, encoding="utf-8", xml_declaration=True)
            zout.writestr(item, xml_bytes)

    tmp_path.replace(docx_path)


def main():
    if len(sys.argv) < 2:
        print("usage: set_docx_math_font.py <docx_path> [font_name]", file=sys.stderr)
        raise SystemExit(2)

    docx_path = Path(sys.argv[1])
    font_name = sys.argv[2] if len(sys.argv) >= 3 else "Times New Roman"
    set_math_font(docx_path, font_name=font_name)
    print(f"set math font to {font_name} in {docx_path}")


if __name__ == "__main__":
    main()
