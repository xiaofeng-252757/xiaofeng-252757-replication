"""Force per-run mixed-script fonts across the entire DOCX.

For every run in every paragraph:
  * if the run belongs to a code block (paragraph style "Source Code") or is
    inline verbatim, apply Consolas / SimSun at 10pt;
  * otherwise apply Times New Roman for ASCII (ascii/hAnsi/cs) and 宋体 for
    CJK (eastAsia).  Font size is left untouched for non-code runs so section
    heading sizes remain intact.

This normalises the "mixed CJK / Latin font" chaos reported by the user
even when other post-processors have left some runs with stale w:rFonts
inherited from pandoc's default template.
"""

from __future__ import annotations

import sys
from pathlib import Path

from docx import Document
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Pt

CODE_PARA_STYLES = {"Source Code", "SourceCode", "Code"}
CODE_RUN_STYLES = {"Verbatim Char", "VerbatimChar"}


def set_run_fonts(run, ascii_name: str, ea_name: str, size_pt: int | None = None):
    rPr = run._element.get_or_add_rPr()
    rFonts = rPr.find(qn("w:rFonts"))
    if rFonts is None:
        rFonts = OxmlElement("w:rFonts")
        rPr.insert(0, rFonts)
    rFonts.set(qn("w:ascii"), ascii_name)
    rFonts.set(qn("w:hAnsi"), ascii_name)
    rFonts.set(qn("w:cs"), ascii_name)
    rFonts.set(qn("w:eastAsia"), ea_name)
    if size_pt is not None:
        run.font.size = Pt(size_pt)


def is_code_para(p) -> bool:
    style_name = p.style.name if p.style is not None else ""
    return style_name in CODE_PARA_STYLES


def is_code_run(r) -> bool:
    style_name = r.style.name if r.style is not None else ""
    return style_name in CODE_RUN_STYLES


def main(path: str) -> None:
    docx_path = Path(path)
    doc = Document(str(docx_path))

    n_body = n_code = 0
    for para in doc.paragraphs:
        if is_code_para(para):
            for run in para.runs:
                set_run_fonts(run, "Consolas", "SimSun", size_pt=10)
                n_code += 1
        else:
            for run in para.runs:
                if is_code_run(run):
                    set_run_fonts(run, "Consolas", "SimSun", size_pt=10)
                    n_code += 1
                else:
                    set_run_fonts(run, "Times New Roman", "宋体")
                    n_body += 1

    # tables: same rule
    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                for para in cell.paragraphs:
                    for run in para.runs:
                        if is_code_run(run):
                            set_run_fonts(run, "Consolas", "SimSun", size_pt=10)
                            n_code += 1
                        else:
                            set_run_fonts(run, "Times New Roman", "宋体")
                            n_body += 1

    doc.save(str(docx_path))
    print(f"normalised fonts: {n_body} body runs, {n_code} code runs in {docx_path}")


if __name__ == "__main__":
    default = "gaohong_replication_package/report/高级宏观经济学期末复现报告_最终提交版.docx"
    path = sys.argv[1] if len(sys.argv) > 1 else default
    main(path)
