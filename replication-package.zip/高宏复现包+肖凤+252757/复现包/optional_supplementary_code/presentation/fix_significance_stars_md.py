#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Escape significance stars in markdown tables to avoid Pandoc/Word swallowing.

We only touch table rows (lines containing '|') and only when stars immediately
follow a digit or ')' so ordinary markdown emphasis is not affected.

Transforms:
  0.315*** -> 0.315\*\*\*
  0.109*   -> 0.109\*
  (0.049)*** -> (0.049)\*\*\*

Idempotent: already-escaped stars are left unchanged.
"""

from __future__ import annotations

import re
from pathlib import Path

IN_PATH = Path("gaohong_replication_package/report/高级宏观经济学期末复现报告_最终提交版.md")

# lookbehind: digit or ')'; negative lookbehind: backslash (already escaped)
RE_3 = re.compile(r"(?<!\\)(?<=[0-9)])\*\*\*")
RE_2 = re.compile(r"(?<!\\)(?<=[0-9)])\*\*(?!\*)")
RE_1 = re.compile(r"(?<!\\)(?<=[0-9)])\*(?!\*)")


def fix_line(line: str) -> str:
    if "|" not in line:
        return line
    # Skip markdown alignment row to avoid accidental changes (though unlikely)
    if re.match(r"^\s*\|\s*[-: ]+\|\s*$", line):
        return line

    line = RE_3.sub(r"\\*\\*\\*", line)
    line = RE_2.sub(r"\\*\\*", line)
    line = RE_1.sub(r"\\*", line)
    return line


def main():
    text = IN_PATH.read_text(encoding="utf-8")
    out_lines = []
    changed = 0
    for ln in text.splitlines(True):
        new_ln = fix_line(ln)
        if new_ln != ln:
            changed += 1
        out_lines.append(new_ln)

    IN_PATH.write_text("".join(out_lines), encoding="utf-8")
    print(f"updated {IN_PATH} (changed_lines={changed})")


if __name__ == "__main__":
    main()
