#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Lint & lightly fix Markdown formatting for captions/headings.

Goals:
- Ensure table/figure captions are standalone paragraphs (one line) and not bold-marked.
- Ensure blank line between caption and table/image.
- Ensure heading levels are consistent (# -> ## -> ###) without skipping.

This script performs conservative edits; it will not change any numbers.
"""

from __future__ import annotations

import re
from pathlib import Path

IN_PATH = Path("gaohong_replication_package/report/高级宏观经济学期末复现报告_最终提交版.md")

CAP_BOLD_RE = re.compile(r"^\*\*(表|图)\s*\d+[\s\S]*?\*\*\s*$")
CAP_RE = re.compile(r"^(表|图)\s*\d+")
HEADING_RE = re.compile(r"^(#+)\s+")


def normalize_caption(line: str) -> str:
    # Remove surrounding **...** if the whole line is bold.
    if CAP_BOLD_RE.match(line.strip()):
        return line.strip().strip("*") + "\n"
    return line


def main():
    text = IN_PATH.read_text(encoding="utf-8")
    lines = text.splitlines(True)

    out = []
    issues = []

    prev_h = None
    for i, ln in enumerate(lines, 1):
        # heading hierarchy lint
        m = HEADING_RE.match(ln)
        if m:
            level = len(m.group(1))
            if prev_h is not None and level > prev_h + 1:
                issues.append(f"Heading jump at line {i}: {prev_h} -> {level}")
            prev_h = level

        ln2 = normalize_caption(ln)
        out.append(ln2)

    # enforce blank line after captions when followed by table or image immediately
    fixed = []
    i = 0
    while i < len(out):
        line = out[i]
        fixed.append(line)
        if CAP_RE.match(line.strip()):
            # lookahead
            if i + 1 < len(out):
                nxt = out[i + 1]
                if nxt.strip().startswith("|") or nxt.strip().startswith("!["):
                    fixed.append("\n")
        i += 1

    new_text = "".join(fixed)
    if new_text != text:
        IN_PATH.write_text(new_text, encoding="utf-8")

    # write lint log
    log_path = IN_PATH.parent / "format_lint.log"
    log = "\n".join(issues) if issues else "OK"
    log_path.write_text(log + "\n", encoding="utf-8")
    print(f"wrote {log_path} ({len(issues)} issues)")


if __name__ == "__main__":
    main()
