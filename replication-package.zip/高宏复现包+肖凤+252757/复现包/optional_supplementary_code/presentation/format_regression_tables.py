"""
Format regression CSV outputs into Chinese three-line Markdown tables.

Produces five tables (Table A – Table E) matching the layout requested
in the extension brief.  Each table follows GB/T-7714-style "三线表"
conventions: a bold header rule, a header/body separator, and a bottom
rule; internal vertical lines are suppressed for a clean academic look.
Stars follow standard conventions:  *** p<0.01, ** p<0.05, * p<0.10.

Inputs (produced by ``micro_empirical_analysis.py`` and
``micro_robustness.py``):
    output/tables/regression_coefficients.csv
    output/tables/time_trend_coefficients.csv
    output/tables/robustness_results.csv
    output/tables/heterogeneity_results.csv
    output/tables/iv_regression_results.csv
    output/tables/iv_regression_results_no_provFE.csv

Outputs (Markdown):
    output/tables/formatted_table_A_baseline.md
    output/tables/formatted_table_B_yearly.md
    output/tables/formatted_table_C_robustness.md
    output/tables/formatted_table_D_heterogeneity.md
    output/tables/formatted_table_E_iv.md

Author: 肖凤
Date:   2026-08
"""
from __future__ import annotations

import os
import re
import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", ".."))
TAB = os.path.join(ROOT, "gaohong_replication_package", "output", "tables")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def stars(p: float) -> str:
    if pd.isna(p):
        return ""
    if p < 0.01:
        return "***"
    if p < 0.05:
        return "**"
    if p < 0.10:
        return "*"
    return ""


def cell_from_bp(b: float, se: float, p: float,
                 fmt: str = "{:.4f}") -> tuple[str, str]:
    """Return two strings: (coef+stars, "(se)")."""
    if pd.isna(b):
        return "", ""
    return f"{fmt.format(b)}{stars(p)}", f"({fmt.format(se)})"


def parse_cell(cell: str) -> tuple[str, str]:
    """Parse a `'0.1234*** (0.0567)'` cell -> ('0.1234***', '(0.0567)')."""
    if pd.isna(cell) or not str(cell).strip():
        return "", ""
    m = re.match(r"\s*(-?\d+\.\d+\**)\s*\((-?\d+\.\d+)\)\s*", str(cell))
    if not m:
        return str(cell), ""
    return m.group(1), f"({m.group(2)})"


def md_table(header: list[str], rows: list[list[str]],
             align: str = "l") -> str:
    """Render a Markdown three-line table with clean alignment.

    Uses `:---` alignment tokens; renderers show a top rule + header rule
    + bottom rule which is visually equivalent to the 三线表 style.
    """
    ncol = len(header)
    if align == "l":
        alignments = [":---"] + ["---:"] * (ncol - 1)
    else:
        alignments = ["---:"] * ncol

    def pad_row(cells):
        return "| " + " | ".join(str(c) for c in cells) + " |"

    lines = [pad_row(header),
             "| " + " | ".join(alignments) + " |"]
    for r in rows:
        lines.append(pad_row(r))
    return "\n".join(lines)


def wrap_table(title: str, note: str, body_md: str) -> str:
    return (f"### {title}\n\n"
            f"{body_md}\n\n"
            f"*注：{note}*\n")


# ---------------------------------------------------------------------------
# Table A: Baseline (M1) + Time-trend (M2)
# ---------------------------------------------------------------------------
def build_table_A() -> str:
    df = pd.read_csv(os.path.join(TAB, "regression_coefficients.csv"))
    df = df.set_index("variable")

    # Map internal variable names -> Chinese labels
    label_map = [
        ("manufacturing",                "制造业"),
        ("low_skill",                    "低技能"),
        ("manufacturing:low_skill",      "制造业 × 低技能"),
        ("manufacturing:low_skill:yr_idx", "制造业 × 低技能 × 年份"),
        ("age",                          "年龄"),
        ("age2",                         "年龄²"),
        ("female",                       "女性"),
        ("rural_hukou",                  "农村户籍"),
    ]

    rows: list[list[str]] = []
    for key, cn in label_map:
        cell_m1 = df.loc[key, "M1_lnIncome"] if key in df.index else ""
        cell_m2 = df.loc[key, "M2_triple_yr"] if key in df.index else ""
        coef1, se1 = parse_cell(cell_m1)
        coef2, se2 = parse_cell(cell_m2)
        rows.append([cn, coef1, coef2])
        rows.append(["", se1, se2])

    rows.append(["年份 FE", "是", "是"])
    rows.append(["省份 FE", "是", "是"])
    rows.append(["观测值 N",
                 f"{int(float(df.loc['N', 'M1_lnIncome'])):,}",
                 f"{int(float(df.loc['N', 'M2_triple_yr'])):,}"])
    rows.append(["R²",
                 f"{float(df.loc['R2', 'M1_lnIncome']):.4f}",
                 f"{float(df.loc['R2', 'M2_triple_yr']):.4f}"])

    body = md_table(["变量", "M1 基准", "M2 时间趋势"], rows)
    note = ("被解释变量为对数年收入 ln(income)。括号内为按省份聚类的稳健标准误；"
            "*** p<0.01，** p<0.05，* p<0.10。M2 用连续年份指数 "
            "`yr_idx=(year-2012)/6` 与关键交互项相乘，故三重交互项系数刻画"
            "『制造业 × 低技能』溢价随时间的线性变化。")
    return wrap_table("表 A  基准与时间趋势估计（ln_income）", note, body)


# ---------------------------------------------------------------------------
# Table B: Year-by-year manuf × low_skill
# ---------------------------------------------------------------------------
def build_table_B() -> str:
    df = pd.read_csv(os.path.join(TAB, "time_trend_coefficients.csv"))
    df = df.sort_values("year").reset_index(drop=True)

    header = ["项目"] + [f"{int(y)} 年" for y in df["year"].values]
    coefs = ["制造业 × 低技能"]
    ses = [""]
    ns = ["观测值 N"]
    for _, r in df.iterrows():
        coefs.append(f"{r['manuf_x_lowskill']:.4f}{stars(r['p'])}")
        ses.append(f"({r['se']:.4f})")
        ns.append(f"{int(r['N']):,}")

    rows = [coefs, ses, ns,
            ["控制变量 + 省份FE"] + ["是"] * len(df)]

    body = md_table(header, rows)
    note = ("每列为单独一年子样本回归所得的『制造业 × 低技能』交互项估计值；"
            "回归中包含年龄、年龄²、性别、户籍及省份 FE，按省份聚类稳健 SE。")
    return wrap_table("表 B  『制造业 × 低技能』逐年估计", note, body)


# ---------------------------------------------------------------------------
# Table C: Robustness (R1-R5)
# ---------------------------------------------------------------------------
def build_table_C() -> str:
    df = pd.read_csv(os.path.join(TAB, "robustness_results.csv"))
    cn_map = {
        "R1_alt_low_skill(<=4)":     "R1 放宽低技能定义（≤高中）",
        "R2_exposed(manuf+mining)":  "R2 广义暴露行业（制造业+采矿）",
        "R3_income_winsor_1_99":     "R3 收入 1%/99% 缩尾",
        "R4_wage_employees_only":    "R4 仅雇员样本（I3a_16=1）",
        "R5_ln_hourly_wage":         "R5 改用小时工资对数",
    }
    key = "manufacturing:low_skill"
    rows = []
    for _, r in df.iterrows():
        label = cn_map.get(r["spec"], r["spec"])
        b = r[f"{key}_coef"]; se = r[f"{key}_se"]; p = r[f"{key}_p"]
        rows.append([label,
                     f"{b:.4f}{stars(p)}",
                     f"({se:.4f})",
                     f"{int(r['N']):,}",
                     f"{r['R2']:.4f}"])

    body = md_table(["稳健性设定", "制造业 × 低技能", "SE", "N", "R²"], rows)
    note = ("所有列均采用主回归 `ln_income ~ 制造业 × 低技能 + 控制变量 + "
            "年份 FE + 省份 FE`，按省份聚类稳健 SE。R4 因 CLDS 2012 未采集"
            "从业身份问题（I3a_16），样本仅包含 2014/2016/2018 三期。")
    return wrap_table("表 C  稳健性检验", note, body)


# ---------------------------------------------------------------------------
# Table D: Heterogeneity (H1-H4)
# ---------------------------------------------------------------------------
def build_table_D() -> str:
    df = pd.read_csv(os.path.join(TAB, "heterogeneity_results.csv"))
    cn_map = {
        "H1_rural_hukou": "H1 农村户籍",
        "H1_urban_hukou": "H1 城市户籍",
        "H2_female":      "H2 女性",
        "H2_male":        "H2 男性",
        "H3_age_16_35":   "H3 青年（16–35 岁）",
        "H3_age_36_65":   "H3 中年（36–65 岁）",
        "H4_coastal":     "H4 沿海省份",
        "H4_inland":      "H4 内陆省份",
    }
    key = "manufacturing:low_skill"
    rows = []
    for _, r in df.iterrows():
        label = cn_map.get(r["spec"], r["spec"])
        b = r[f"{key}_coef"]; se = r[f"{key}_se"]; p = r[f"{key}_p"]
        rows.append([label,
                     f"{b:.4f}{stars(p)}",
                     f"({se:.4f})",
                     f"{int(r['N']):,}",
                     f"{r['R2']:.4f}"])

    body = md_table(["子样本", "制造业 × 低技能", "SE", "N", "R²"], rows)
    note = ("分样本回归均采用主设定，控制变量与固定效应同基准。沿海省份编码："
            "北京(11)、天津(12)、河北(13)、辽宁(21)、上海(31)、江苏(32)、"
            "浙江(33)、福建(35)、山东(37)、广东(44)、海南(46)。")
    return wrap_table("表 D  异质性分析", note, body)


# ---------------------------------------------------------------------------
# Table E: IV vs OLS
# ---------------------------------------------------------------------------
def build_table_E() -> str:
    ols_iv = pd.read_csv(os.path.join(TAB, "iv_regression_results.csv"))
    iv_alt = pd.read_csv(os.path.join(TAB, "iv_regression_results_no_provFE.csv"))
    ols_iv = ols_iv.set_index("variable")
    iv_alt = iv_alt.set_index("variable")

    label_map = [
        ("manufacturing", "制造业"),
        ("manuf_x_low",   "制造业 × 低技能"),
        ("low_skill",     "低技能"),
        ("age",           "年龄"),
        ("age2",          "年龄²"),
        ("female",        "女性"),
        ("rural_hukou",   "农村户籍"),
    ]

    def get3(row_df, k, prefix):
        try:
            b = float(row_df.loc[k, f"{prefix}_coef"])
            se = float(row_df.loc[k, f"{prefix}_se"])
            p = float(row_df.loc[k, f"{prefix}_p"])
            return b, se, p
        except Exception:
            return np.nan, np.nan, np.nan

    rows = []
    for k, cn in label_map:
        b_ols, se_ols, p_ols = get3(ols_iv, k, "OLS")
        b_iv,  se_iv,  p_iv  = get3(ols_iv, k, "IV")
        b_alt, se_alt, p_alt = get3(iv_alt, k, "IV_alt")
        rows.append([cn,
                     (f"{b_ols:.4f}{stars(p_ols)}" if not pd.isna(b_ols) else ""),
                     (f"{b_iv:.4f}{stars(p_iv)}"   if not pd.isna(b_iv)  else ""),
                     (f"{b_alt:.4f}{stars(p_alt)}" if not pd.isna(b_alt) else "")])
        rows.append(["",
                     (f"({se_ols:.4f})" if not pd.isna(se_ols) else ""),
                     (f"({se_iv:.4f})"  if not pd.isna(se_iv)  else ""),
                     (f"({se_alt:.4f})" if not pd.isna(se_alt) else "")])

    # First-stage F stats
    def sget(row_df, name, prefix):
        try:
            return float(row_df.loc[name, f"{prefix}_coef"])
        except Exception:
            return np.nan

    fs_manuf_iv   = sget(ols_iv, "First-stage F (manufacturing)", "IV")
    fs_int_iv     = sget(ols_iv, "First-stage F (manuf x low)",   "IV")
    fs_manuf_alt  = sget(iv_alt, "First-stage F (manufacturing)", "IV_alt")
    fs_int_alt    = sget(iv_alt, "First-stage F (manuf x low)",   "IV_alt")
    n_ols = int(sget(ols_iv, "N", "OLS"))
    n_iv  = int(sget(ols_iv, "N", "IV"))
    n_alt = int(sget(iv_alt, "N", "IV_alt"))

    rows.append(["省份 FE", "是", "是", "否"])
    rows.append(["年份 FE", "是", "是", "是"])
    rows.append(["第一阶段 F（制造业）", "—",
                 f"{fs_manuf_iv:.2f}",  f"{fs_manuf_alt:.2f}"])
    rows.append(["第一阶段 F（制造业×低技能）", "—",
                 f"{fs_int_iv:.2f}",    f"{fs_int_alt:.2f}"])
    rows.append(["观测值 N",
                 f"{n_ols:,}", f"{n_iv:,}", f"{n_alt:,}"])

    body = md_table(["变量", "OLS（含省份FE）", "IV（含省份FE）", "IV（不含省份FE）"],
                    rows)
    note = ("被解释变量为 ln(income)。IV 采用 Bartik-lite 型工具变量："
            "2012 年省级制造业就业份额（`prov_manuf_share_2012`）与线性时间指数 "
            "`yr_idx` 的交互作为『制造业』的外生扰动，其再与低技能虚拟变量的乘积"
            "作为『制造业×低技能』的工具。省份 FE 会吸收 `prov_manuf_share_2012`"
            "的横截面变异，因此第二列的第一阶段 F 值明显偏低；第三列去掉省份 FE "
            "以恢复识别力，可作为稳健性对照。")
    return wrap_table("表 E  IV / OLS 对比（内生变量：制造业、制造业×低技能）",
                      note, body)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main():
    outputs = {
        "formatted_table_A_baseline.md":     build_table_A(),
        "formatted_table_B_yearly.md":       build_table_B(),
        "formatted_table_C_robustness.md":   build_table_C(),
        "formatted_table_D_heterogeneity.md":build_table_D(),
        "formatted_table_E_iv.md":           build_table_E(),
    }
    for name, content in outputs.items():
        path = os.path.join(TAB, name)
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(content)
        print("Wrote", path)


if __name__ == "__main__":
    main()
