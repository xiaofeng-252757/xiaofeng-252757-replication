#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Replot time_trend_interaction.png with journal-like readability.

Input:
  gaohong_replication_package/output/tables/time_trend_coefficients.csv
Output (overwrite):
  gaohong_replication_package/output/figures/time_trend_interaction.png
"""

from pathlib import Path
import pandas as pd
import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator

ROOT = Path("gaohong_replication_package")
IN_CSV = ROOT / "output/tables/time_trend_coefficients.csv"
OUT_PNG = ROOT / "output/figures/time_trend_interaction.png"

mpl.rcParams["font.family"] = "Noto Serif CJK SC"
mpl.rcParams["axes.unicode_minus"] = False
mpl.rcParams["figure.dpi"] = 200


def main():
    df = pd.read_csv(IN_CSV)
    df = df.sort_values("year")

    years = df["year"].astype(int).tolist()
    coef = df["manuf_x_lowskill"].astype(float).tolist()
    se = df["se"].astype(float).tolist()

    # 95% CI
    lower = [c - 1.96 * s for c, s in zip(coef, se)]
    upper = [c + 1.96 * s for c, s in zip(coef, se)]

    fig, ax = plt.subplots(figsize=(7.6, 4.8), dpi=300)

    # main series
    ax.plot(
        years,
        coef,
        color="black",
        linewidth=1.8,
        marker="o",
        markersize=5.8,
        markerfacecolor="white",
        markeredgewidth=1.2,
        zorder=3,
    )

    # CI as thin whiskers
    ax.vlines(years, lower, upper, colors="0.30", linewidth=1.2, zorder=2)

    ax.axhline(0, color="black", linewidth=1.0, zorder=1)
    ax.grid(True, linestyle=":", color="0.75", linewidth=0.9)

    ax.set_title("制造业 × 低技能交互项的逐年估计（点估计与95%置信区间）", fontsize=12, pad=10)
    ax.set_xlabel("年份", fontsize=11)
    ax.set_ylabel("交互项系数（对数收入）", fontsize=11)

    ax.xaxis.set_major_locator(MaxNLocator(integer=True))
    ax.tick_params(axis="both", labelsize=10)

    # 给标签留出上方空间，避免与误差线重叠
    ymin = min(lower)
    ymax = max(upper)
    pad = 0.10 * (ymax - ymin)
    ax.set_ylim(ymin - 0.05 * (ymax - ymin), ymax + pad)

    # 数值标注：使用白底框 + 交错的 y 偏移，避免与误差线/点位重叠
    offsets = [0.030, 0.045, 0.030, 0.045]
    for i, (x, y) in enumerate(zip(years, coef)):
        dy = offsets[i % len(offsets)]
        ax.text(
            x,
            y + dy,
            f"{y:+.3f}",
            ha="center",
            va="bottom",
            fontsize=9,
            color="0.15",
            bbox=dict(boxstyle="round,pad=0.18", fc="white", ec="0.7", lw=0.6, alpha=0.95),
            zorder=4,
        )

    fig.tight_layout()
    OUT_PNG.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(OUT_PNG, dpi=300, bbox_inches="tight")
    plt.close(fig)
    print(f"saved: {OUT_PNG}")


if __name__ == "__main__":
    main()
