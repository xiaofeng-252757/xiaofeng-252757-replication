#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
matplotlib 重绘齐亚东等（2026）DSGE 复现图（图1/图2/图3/拓展A/拓展B）。

- 中文字体使用 Noto Serif CJK SC
- 黑色为主，辅以深灰、虚线、点划线
- 网格：灰色浅虚线；跨零轴时加细黑水平零线
- 输出到 gaohong_replication_package/output/figures/ 覆盖旧文件

数据来源：output/data/*.mat（Octave 保存）。fig2_workspace.mat 是
Octave 文本格式（不是 v5 二进制），因此需要单独的解析函数。

变量名参考 code/original/fig_1.m、fig_2.m、fig_3.m，以及 optional_supplementary_code/dsge_extension/fig_ext_alpha_wide.m。
"""
from __future__ import annotations

import os
import re
from pathlib import Path

import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.ticker import ScalarFormatter, MaxNLocator
from scipy.io import loadmat

# ---------------------------------------------------------------------
# 全局字体与样式
# ---------------------------------------------------------------------
mpl.rcParams["font.family"] = "Noto Serif CJK SC"
mpl.rcParams["axes.unicode_minus"] = False
mpl.rcParams["axes.titlesize"] = 11
mpl.rcParams["axes.labelsize"] = 10
mpl.rcParams["xtick.labelsize"] = 10
mpl.rcParams["ytick.labelsize"] = 10
mpl.rcParams["legend.fontsize"] = 9
mpl.rcParams["axes.linewidth"] = 0.8
mpl.rcParams["lines.linewidth"] = 1.4

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "output" / "data"
FIG_DIR = ROOT / "output" / "figures"
FIG_DIR.mkdir(parents=True, exist_ok=True)

# 曲线样式清单（黑—深灰—虚线—点划线）
LINE_STYLES = [
    dict(color="black", linestyle="-", linewidth=1.4),
    dict(color="0.30", linestyle="-", linewidth=1.4),
    dict(color="black", linestyle="--", linewidth=1.4),
    dict(color="0.30", linestyle="-.", linewidth=1.4),
]


def style_ax(ax):
    ax.grid(True, linestyle=":", alpha=0.5, color="0.6")
    ax.yaxis.set_major_locator(MaxNLocator(nbins=5, prune="both"))
    fmt = ScalarFormatter(useMathText=True)
    fmt.set_powerlimits((-3, 4))
    ax.yaxis.set_major_formatter(fmt)
    ax.tick_params(axis="both", which="both", direction="out", length=3)
    for spine in ("top", "right"):
        ax.spines[spine].set_visible(True)
        ax.spines[spine].set_linewidth(0.6)


def add_zero_line(ax, x):
    """当 y 范围跨越 0，加一条细黑水平零线帮助辨识方向。"""
    ylim = ax.get_ylim()
    if ylim[0] <= 0 <= ylim[1] and (ylim[1] - ylim[0]) > 0:
        ax.axhline(0, color="black", linewidth=0.6, linestyle="-", alpha=0.6)


# ---------------------------------------------------------------------
# Octave 文本 .mat 解析（仅覆盖当前需要的两种类型）
# ---------------------------------------------------------------------
def _load_octave_text_mat(path: Path) -> dict:
    data = {}
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        lines = f.readlines()
    i = 0
    n = len(lines)
    while i < n:
        line = lines[i].strip()
        if line.startswith("# name:"):
            name = line.split(":", 1)[1].strip()
            i += 1
            # next line: # type:
            tline = lines[i].strip()
            assert tline.startswith("# type:"), f"unexpected line: {tline}"
            tp = tline.split(":", 1)[1].strip()
            i += 1
            if tp == "double_range":
                # # base, limit, increment
                assert lines[i].strip().startswith("# base"), lines[i]
                i += 1
                base, limit, inc = [float(x) for x in lines[i].split()]
                i += 1
                # inclusive range
                arr = np.arange(base, limit + inc / 2.0, inc)
                data[name] = arr
            elif tp == "matrix":
                # # rows: N
                assert lines[i].strip().startswith("# rows:")
                rows = int(lines[i].split(":", 1)[1])
                i += 1
                assert lines[i].strip().startswith("# columns:")
                cols = int(lines[i].split(":", 1)[1])
                i += 1
                values = []
                while len(values) < rows * cols:
                    if i >= n:
                        break
                    parts = lines[i].split()
                    if parts and not parts[0].startswith("#"):
                        values.extend(float(x) for x in parts)
                    i += 1
                arr = np.array(values, dtype=float).reshape(rows, cols)
                data[name] = arr
            else:
                # skip unknown type
                i += 1
        else:
            i += 1
    return data


def load_mat_any(path: Path) -> dict:
    """兼容加载：先试二进制 scipy.io.loadmat，失败则走 Octave 文本解析。"""
    try:
        return loadmat(str(path))
    except (ValueError, NotImplementedError):
        return _load_octave_text_mat(path)


def flat(arr) -> np.ndarray:
    return np.asarray(arr).reshape(-1)


# ---------------------------------------------------------------------
# 图 1：4x4，16 个短期脉冲响应
# ---------------------------------------------------------------------
FIG1_SPEC = [
    ("Y_ee_xi", "经济总产出"),
    ("A_ee_xi", "机器人技术创新"),
    ("ROB_F_ee_xi", "机器人规模"),
    ("R_F_ee_xi", "机器人回报"),
    ("K_ee_xi", "传统资本"),
    ("R_K_ee_xi", "传统资本回报"),
    ("L_ee_xi", "低技能劳动"),
    ("w_ee_xi", "低技能实际工资"),
    ("L_S_ee_xi", "高技能劳动"),
    ("w_S_ee_xi", "高技能实际工资"),
    ("fe_u_ee_xi", "低技能收入份额"),
    ("fe_M_ee_xi", "机器人收入份额"),
    ("C1_ee_xi", "低技能家庭实际收入"),
    ("C2_ee_xi", "高技能家庭实际收入"),
    ("income3_ee_xi", "资本型家庭实际收入"),
    ("INDX_ee_xi", "收入差距指数"),
]


def plot_fig1():
    d = load_mat_any(DATA_DIR / "fig1_workspace.mat")
    T = np.arange(21)
    fig, axes = plt.subplots(4, 4, figsize=(12, 9), dpi=200)
    for ax, (var, title) in zip(axes.flat, FIG1_SPEC):
        if var not in d:
            ax.set_title(f"{title}\n(变量 {var} 不在工作区)")
            ax.axis("off")
            continue
        y = flat(d[var])
        ax.plot(T, y, **LINE_STYLES[0])
        ax.set_title(title)
        style_ax(ax)
        ax.set_xlim(0, 20)
        ax.set_xticks([0, 5, 10, 15, 20])
        add_zero_line(ax, T)
    fig.tight_layout(pad=0.6, h_pad=1.0, w_pad=0.8)
    out = FIG_DIR / "fig1_reproduced.png"
    fig.savefig(out, dpi=200, bbox_inches="tight")
    plt.close(fig)
    print(f"[fig1] saved -> {out}")


# ---------------------------------------------------------------------
# 图 2：3x4，完整对应原文长期稳态图的 12 个子图
# ---------------------------------------------------------------------
FIG2_SPEC = [
    ("Y", "经济总产出"),
    ("ROB", "机器人规模"),
    ("wu_Y", "低技能收入份额"),
    ("ROB_Y", "机器人收入份额"),
    ("wu", "低技能实际工资"),
    ("ws", "高技能实际工资"),
    ("income1", "低技能家庭实际收入"),
    ("income2", "高技能家庭实际收入"),
    ("income3", "资本型家庭实际收入"),
    ("wu_Y", "低技能收入占产出比重"),
    ("ws_Y", "高技能收入占产出比重"),
    ("we_Y", "资本型收入占产出比重"),
]


def plot_fig2():
    d = load_mat_any(DATA_DIR / "fig2_workspace.mat")
    x = flat(d["ht"] if "ht" in d else d["xx"] / 0.25)
    fig, axes = plt.subplots(3, 4, figsize=(12, 8.6), dpi=200)
    for ax, (var, title) in zip(axes.flat, FIG2_SPEC):
        y = flat(d[var])
        # 第 3 幅按原图口径展示为低技能收入份额 = 低技能收入占产出比重 / MC_ss
        if title == "低技能收入份额" and "MC_ss" in d:
            y = y / float(np.asarray(d["MC_ss"]).reshape(-1)[0])
        ax.plot(x, y, **LINE_STYLES[0])
        ax.set_title(title)
        style_ax(ax)
        ax.set_xlim(x.min(), x.max())
        ax.set_xticks(np.linspace(round(x.min(), 1), round(x.max(), 1), 6))
    fig.tight_layout(pad=0.8, h_pad=1.0, w_pad=0.9)
    out = FIG_DIR / "fig2_reproduced.png"
    fig.savefig(out, dpi=200, bbox_inches="tight")
    plt.close(fig)
    print(f"[fig2] saved -> {out}")


# ---------------------------------------------------------------------
# 图 3：完整对应原文图 3 的 8 个子图
# ---------------------------------------------------------------------
FIG3_SPEC = [
    ("L_ee_xi", "低技能劳动"),
    ("w_ee_xi", "低技能工资"),
    ("lambda1_ee_xi", "低技能家庭边际效用"),
    ("C1_ee_xi", "低技能家庭实际收入"),
    ("income3_ee_xi", "资本型家庭实际收入"),
    ("INDX_ee_xi", "收入差距"),
    ("MC_ee_xi", "中间品价格"),
    ("Y_ee_xi", "经济总产出"),
]

FIG3_POLICY = [
    ("_e", "情形1：一次性转移支付", LINE_STYLES[2]),
    ("_l", "情形2：劳动补贴", LINE_STYLES[0]),
    ("_c", "情形3：消费补贴", LINE_STYLES[3]),
]


def plot_fig3():
    d = load_mat_any(DATA_DIR / "fig3_workspace.mat")
    T = np.arange(21)
    fig, axes = plt.subplots(3, 3, figsize=(12, 8.8), dpi=200)
    axes_flat = axes.flat
    for idx, (base, title) in enumerate(FIG3_SPEC):
        ax = axes_flat[idx]
        for suffix, label, style in FIG3_POLICY:
            y = flat(d[base + suffix])
            ax.plot(T, y, label=label, **style)
        ax.set_title(title)
        ax.set_xlim(0, 20)
        ax.set_xticks([0, 5, 10, 15, 20])
        style_ax(ax)
        add_zero_line(ax, T)
    # 最后一个子图留给图例
    legend_ax = axes_flat[len(FIG3_SPEC)]
    legend_ax.axis("off")
    handles, labels = axes[0, 0].get_legend_handles_labels()
    legend_ax.legend(handles, labels, loc="center", ncol=1, frameon=True)
    fig.tight_layout(pad=0.8, h_pad=1.0, w_pad=0.9)
    out = FIG_DIR / "fig3_reproduced.png"
    fig.savefig(out, dpi=200, bbox_inches="tight")
    plt.close(fig)
    print(f"[fig3] saved -> {out}")


# ---------------------------------------------------------------------
# 拓展 A：ext_alpha_wide 2x3
# ---------------------------------------------------------------------
EXTA_SPEC = [
    ("income1", "低技能实际收入"),
    ("income2", "高技能实际收入"),
    ("income3", "资本型实际收入"),
    ("wu_Y", "低技能收入份额"),
    ("ws_Y", "高技能收入份额"),
    ("we_Y", "资本型收入份额"),
]


def plot_ext_alpha():
    d = load_mat_any(DATA_DIR / "ext_alpha_wide.mat")
    x = flat(d["xx"])
    fig, axes = plt.subplots(2, 3, figsize=(11, 6.5), dpi=200)
    for ax, (var, title) in zip(axes.flat, EXTA_SPEC):
        y = flat(d[var])
        ax.plot(x, y, **LINE_STYLES[0])
        ax.set_title(title)
        ax.set_xlabel(r"$\alpha$")
        style_ax(ax)
        ax.set_xlim(x.min(), x.max())
    fig.suptitle(r"拓展 A：α∈[0.15, 0.75]", fontsize=12, y=1.00)
    fig.tight_layout(pad=0.6, h_pad=1.2, w_pad=1.0, rect=(0, 0, 1, 0.97))
    out = FIG_DIR / "ext_alpha_wide.png"
    fig.savefig(out, dpi=200, bbox_inches="tight")
    plt.close(fig)
    print(f"[ext_alpha] saved -> {out}")


# ---------------------------------------------------------------------
# 拓展 B：ext_policy_mix 3 子图，4 条曲线
# ---------------------------------------------------------------------
EXTB_SPEC = [
    ("C1", "低技能家庭实际收入 IRF"),
    ("Y", "经济总产出 IRF"),
    ("INDX", "收入差距指数 IRF"),
]

EXTB_POLICY = [
    ("_ee_xi_e", "一次性转移支付", LINE_STYLES[2]),      # 虚线
    ("_ee_xi_l", "劳动补贴", LINE_STYLES[0]),            # 黑实线
    ("_ee_xi_c", "消费补贴", LINE_STYLES[3]),            # 深灰点划
    ("_mix",    "组合政策（转移+劳补 50/50）", LINE_STYLES[1]),  # 深灰实线
]


def plot_ext_policy_mix():
    d = load_mat_any(DATA_DIR / "ext_policy_mix.mat")
    T = np.arange(21)
    fig, axes = plt.subplots(1, 3, figsize=(12, 4), dpi=200)
    for ax, (base, title) in zip(axes, EXTB_SPEC):
        for suffix, label, style in EXTB_POLICY:
            key = base + suffix
            if key not in d:
                continue
            y = flat(d[key])
            ax.plot(T, y, label=label, **style)
        ax.set_title(title)
        ax.set_xlabel("期")
        ax.set_xlim(0, 20)
        ax.set_xticks([0, 5, 10, 15, 20])
        style_ax(ax)
        add_zero_line(ax, T)
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(
        handles,
        labels,
        loc="lower center",
        bbox_to_anchor=(0.5, -0.04),
        ncol=4,
        frameon=True,
    )
    fig.tight_layout(pad=0.6, h_pad=1.0, w_pad=1.0, rect=(0, 0.06, 1, 1))
    out = FIG_DIR / "ext_policy_mix.png"
    fig.savefig(out, dpi=200, bbox_inches="tight")
    plt.close(fig)
    print(f"[ext_policy_mix] saved -> {out}")


# ---------------------------------------------------------------------
# 主入口
# ---------------------------------------------------------------------
def main():
    errors = []
    for name, fn in [
        ("fig1", plot_fig1),
        ("fig2", plot_fig2),
        ("fig3", plot_fig3),
        ("ext_alpha_wide", plot_ext_alpha),
        ("ext_policy_mix", plot_ext_policy_mix),
    ]:
        try:
            fn()
        except Exception as e:  # noqa: BLE001
            import traceback
            traceback.print_exc()
            errors.append((name, str(e)))
    if errors:
        print("\n==== 存在失败图 ====")
        for n, msg in errors:
            print(f"  {n}: {msg}")
    else:
        print("\n全部 5 张图重绘完成。")


if __name__ == "__main__":
    main()
