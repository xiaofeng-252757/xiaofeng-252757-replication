"""将主报告中“本文复现”的两张核心表格渲染为 PNG（三线表），用于展示层引用。

注意：本脚本只做“呈现层（presentation layer）”渲染，不改变任何模型/数据。
表格数据读取自 output/tables 下已导出的 CSV（真实复现输出），以避免硬编码。

输出（与主报告表编号一致）：
  output/figures/reproduced/table_5-2_本文复现_稳态拟合结果.png
  output/figures/reproduced/table_5-4_本文复现_长期稳态结果.png
"""

import csv
import os

import matplotlib as mpl
import matplotlib.pyplot as plt

mpl.rcParams["font.family"] = "Noto Serif CJK SC"
mpl.rcParams["axes.unicode_minus"] = False

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
out_dir = os.path.join(BASE, "output", "figures", "reproduced")
tab_dir = os.path.join(BASE, "output", "tables")
os.makedirs(out_dir, exist_ok=True)


def three_line_table(fig_path, title, columns, cell_text, col_widths):
    fig, ax = plt.subplots(
        figsize=(sum(col_widths) / 96 * 1.2, (len(cell_text) + 2) * 0.42),
        dpi=200,
    )
    ax.axis("off")

    ax.set_title(title, fontsize=14, fontweight="bold", pad=14)

    tbl = ax.table(
        cellText=cell_text,
        colLabels=columns,
        cellLoc="center",
        colLoc="center",
        loc="center",
        colWidths=[w / sum(col_widths) for w in col_widths],
    )
    tbl.auto_set_font_size(False)
    tbl.set_fontsize(11)
    tbl.scale(1, 1.6)

    # 三线表：仅保留表头上下线 + 表底线
    n_rows = len(cell_text) + 1
    n_cols = len(columns)
    for (r, c), cell in tbl.get_celld().items():
        cell.set_linewidth(0)
        cell.set_edgecolor("none")

    for c in range(n_cols):
        cell = tbl[(0, c)]
        cell.visible_edges = "TB"
        cell.set_linewidth(1.4)
        cell.set_edgecolor("black")
        cell.set_text_props(fontweight="bold")

    for c in range(n_cols):
        cell = tbl[(n_rows - 1, c)]
        cell.visible_edges = "B"
        cell.set_linewidth(1.4)
        cell.set_edgecolor("black")

    plt.savefig(fig_path, bbox_inches="tight", dpi=200, facecolor="white")
    plt.close(fig)
    print("saved", fig_path)


def fmt_number(x, k=2):
    return f"{x:.{k}f}"


def fmt_signed_pct(x, k=2):
    # 与主报告一致：正数显示 +，负数显示 Unicode 负号“−”
    if x < 0:
        return f"−{abs(x):.{k}f}"
    return f"+{x:.{k}f}"


# ---------------- 表 5-2：本文复现：稳态拟合结果 ----------------
# 数据来源：output/tables/table1_model_fit.csv（列：复现值(%)）
label_map = {
    "消费产出比": "消费产出比 C/Y",
    "投资产出比": "投资产出比 I/Y",
    "政府支出产出比": "政府支出产出比 G/Y",
    "技术推广比(A/Z)": "技术推广比 A/Z",
    "研发支出产出比": "研发支出产出比 R/Y",
    "机器人最终品份额": "机器人最终品份额",
    "传统资本回报率": "传统资本回报率 r",
}

with open(os.path.join(tab_dir, "table1_model_fit.csv"), "r", encoding="utf-8-sig") as f:
    reader = csv.DictReader(f)
    t1_body = []
    for r in reader:
        raw_name = (r.get("指标") or r.get("﻿指标") or "").strip()
        display_name = label_map.get(raw_name, raw_name)
        val = float(r["复现值(%)"])
        t1_body.append([display_name, fmt_number(val, 2)])

three_line_table(
    os.path.join(out_dir, "table_5-2_本文复现_稳态拟合结果.png"),
    "表 5-2  本文复现：稳态拟合结果",
    ["指标", "本文复现值（%）"],
    t1_body,
    col_widths=[380, 220],
)


# ---------------- 表 5-4：本文复现：长期稳态结果 ----------------
# 数据来源：output/tables/table2_steady_state.csv（列：复现α=0.25 / 复现α=0.5 / 复现变化幅度(%)）
# 注：该 CSV 的首行把“表头”和“第一条数据行”用字面量 "\\n" 拼在了一起，需要拆开。
with open(os.path.join(tab_dir, "table2_steady_state.csv"), "r", encoding="utf-8-sig") as f:
    raw_lines = [ln for ln in f.read().splitlines() if ln.strip()]

first = raw_lines[0]
if "\\n" in first:
    header_part, first_row_part = first.split("\\n", 1)
    lines = [header_part, first_row_part] + raw_lines[1:]
else:
    lines = raw_lines

reader = csv.DictReader(lines)

# 只取复现列，确保与主报告表 5-4 展示一致
#（保留 4 位小数的水平值，变化幅度保留 2 位并带符号）
t2_body = []
for r in reader:
    var = (r.get("变量") or r.get("﻿变量") or "").strip()
    v25 = float(r["复现α=0.25"])
    v50 = float(r["复现α=0.5"])
    chg = float(r["复现变化幅度(%)"])
    t2_body.append([var, f"{v25:.4f}", f"{v50:.4f}", fmt_signed_pct(chg, 2)])

three_line_table(
    os.path.join(out_dir, "table_5-4_本文复现_长期稳态结果.png"),
    "表 5-4  本文复现：长期稳态结果",
    ["变量", "α = 0.25", "α = 0.50", "变化幅度（%）"],
    t2_body,
    col_widths=[360, 130, 130, 170],
)
