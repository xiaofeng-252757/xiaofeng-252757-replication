#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Post-process pandoc generated DOCX into a more journal-like layout.

- Center all figure/table captions and image paragraphs
- Convert markdown tables to centered three-line tables
- Apply page margins, body font, line spacing, first-line indent
- Standardize title / subtitle / heading typography
"""
from __future__ import annotations

import re
from pathlib import Path
from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Pt, Cm

import sys

DOCX_PATH = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("gaohong_replication_package/report/高级宏观经济学期末复现报告_最终提交版.docx")


def set_run_fonts(run, size=12, bold=False, ascii_font="Times New Roman", east_font="宋体"):
    run.font.size = Pt(size)
    run.bold = bold
    run.font.name = ascii_font
    rPr = run._element.get_or_add_rPr()
    rFonts = rPr.rFonts
    if rFonts is None:
        rFonts = OxmlElement("w:rFonts")
        rPr.insert(0, rFonts)
    rFonts.set(qn("w:ascii"), ascii_font)
    rFonts.set(qn("w:hAnsi"), ascii_font)
    rFonts.set(qn("w:eastAsia"), east_font)
    rFonts.set(qn("w:cs"), ascii_font)


def paragraph_has_drawing(para):
    return bool(para._p.xpath('.//w:drawing'))


def set_page_layout(doc: Document):
    for section in doc.sections:
        section.page_width = Cm(21.0)
        section.page_height = Cm(29.7)
        section.top_margin = Cm(2.54)
        section.bottom_margin = Cm(2.54)
        section.left_margin = Cm(2.8)
        section.right_margin = Cm(2.6)


def set_cell_border(cell, **kwargs):
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    tcBorders = tcPr.first_child_found_in("w:tcBorders")
    if tcBorders is None:
        tcBorders = OxmlElement("w:tcBorders")
        tcPr.append(tcBorders)
    for edge in ("left", "top", "right", "bottom", "insideH", "insideV"):
        edge_data = kwargs.get(edge)
        tag = qn(f"w:{edge}")
        element = tcBorders.find(tag)
        if edge_data:
            if element is None:
                element = OxmlElement(f"w:{edge}")
                tcBorders.append(element)
            for key in ["val", "sz", "space", "color"]:
                if key in edge_data:
                    element.set(qn(f"w:{key}"), str(edge_data[key]))
        else:
            if element is not None:
                tcBorders.remove(element)


def clear_all_borders(table):
    for row in table.rows:
        for cell in row.cells:
            set_cell_border(cell)


def apply_three_line_style(table):
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = True

    # clear all existing borders
    clear_all_borders(table)

    n_rows = len(table.rows)
    n_cols = len(table.columns)
    if n_rows == 0 or n_cols == 0:
        return

    # apply top and header bottom rule to first row
    for c in range(n_cols):
        cell = table.cell(0, c)
        set_cell_border(
            cell,
            top={"val": "single", "sz": 12, "space": "0", "color": "000000"},
            bottom={"val": "single", "sz": 8, "space": "0", "color": "000000"},
        )

    # apply bottom rule to last row
    for c in range(n_cols):
        cell = table.cell(n_rows - 1, c)
        set_cell_border(
            cell,
            bottom={"val": "single", "sz": 12, "space": "0", "color": "000000"},
        )

    # cell text alignment and font size
    for r, row in enumerate(table.rows):
        for c, cell in enumerate(row.cells):
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            for para in cell.paragraphs:
                if r == 0:
                    para.alignment = WD_ALIGN_PARAGRAPH.CENTER
                elif c == 0:
                    para.alignment = WD_ALIGN_PARAGRAPH.LEFT
                else:
                    para.alignment = WD_ALIGN_PARAGRAPH.CENTER
                for run in para.runs:
                    set_run_fonts(run, size=11, bold=(r == 0))


def style_caption_paragraphs(doc: Document):
    # NOTE: caption lines are like "表4  XXX" / "图2  XXX".
    # We must avoid mis-classifying narrative text such as "表4 显示，..." as captions.
    cap_re = re.compile(r"^(表|图)\s*\d+")
    for para in doc.paragraphs:
        txt = para.text.strip()
        if not cap_re.match(txt):
            continue

        # If the line contains Chinese punctuation like "，" / "。", it is very likely a normal paragraph.
        if re.search(r"[，。；：]", txt):
            continue

        para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        para.paragraph_format.first_line_indent = Pt(0)
        para.paragraph_format.space_before = Pt(3)
        para.paragraph_format.space_after = Pt(3)
        para.paragraph_format.line_spacing = 1.15
        # Keep caption with the following object (table/figure) to avoid large blank areas.
        para.paragraph_format.keep_with_next = True

        for run in para.runs:
            set_run_fonts(run, size=11, bold=False)


def style_main_text(doc: Document):
    title_done = False
    for para in doc.paragraphs:
        txt = para.text.strip()
        if not txt and not paragraph_has_drawing(para):
            continue

        # center images
        if paragraph_has_drawing(para):
            para.alignment = WD_ALIGN_PARAGRAPH.CENTER
            para.paragraph_format.first_line_indent = Pt(0)
            para.paragraph_format.space_before = Pt(3)
            para.paragraph_format.space_after = Pt(3)
            continue

        style_name = para.style.name if para.style else ""

        # title (first H1)
        if not title_done and txt == "高级宏观经济学期末复现报告":
            para.alignment = WD_ALIGN_PARAGRAPH.CENTER
            para.paragraph_format.first_line_indent = Pt(0)
            para.paragraph_format.space_before = Pt(6)
            para.paragraph_format.space_after = Pt(12)
            for run in para.runs:
                set_run_fonts(run, size=16, bold=True, east_font="黑体")
            title_done = True
            continue

        # subtitle line under title
        if txt.startswith("工业智能化如何改变增长收益的分配方式"):
            para.alignment = WD_ALIGN_PARAGRAPH.CENTER
            para.paragraph_format.first_line_indent = Pt(0)
            para.paragraph_format.space_after = Pt(10)
            for run in para.runs:
                set_run_fonts(run, size=13, bold=True)
            continue

        # meta lines near top
        if txt.startswith("课程：") or txt.startswith("姓名：") or txt.startswith("学号：") or txt.startswith("完成时间："):
            para.alignment = WD_ALIGN_PARAGRAPH.CENTER
            para.paragraph_format.first_line_indent = Pt(0)
            para.paragraph_format.space_after = Pt(0)
            for run in para.runs:
                set_run_fonts(run, size=11)
            continue

        # headings
        if style_name.startswith("Heading") or re.match(r"^(摘要|一、|二、|三、|四、|五、|六、|七、|八、|九、|参考文献|附录)", txt):
            para.alignment = WD_ALIGN_PARAGRAPH.LEFT
            para.paragraph_format.first_line_indent = Pt(0)
            para.paragraph_format.space_before = Pt(10)
            para.paragraph_format.space_after = Pt(6)
            for run in para.runs:
                set_run_fonts(run, size=13 if txt == "摘要" or re.match(r"^[一二三四五六七八九]、", txt) else 12, bold=True, east_font="黑体")
            continue

        # captions already handled elsewhere.
        # IMPORTANT: do NOT mis-classify narrative paragraphs such as "表 4 显示，...".
        if re.match(r"^(表|图)\s*\d+", txt) and not re.search(r"[，。；：]", txt):
            continue

        # keyword line
        if txt.startswith("关键词"):
            para.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
            para.paragraph_format.first_line_indent = Pt(0)
            para.paragraph_format.space_after = Pt(6)
            para.paragraph_format.line_spacing = Pt(20)
            for run in para.runs:
                set_run_fonts(run, size=11)
            continue

        # body paragraphs
        para.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
        para.paragraph_format.first_line_indent = Pt(24)
        para.paragraph_format.space_before = Pt(0)
        para.paragraph_format.space_after = Pt(0)
        para.paragraph_format.line_spacing = Pt(20)
        for run in para.runs:
            set_run_fonts(run, size=12)


def main():
    doc = Document(str(DOCX_PATH))
    set_page_layout(doc)
    style_caption_paragraphs(doc)
    style_main_text(doc)
    for table in doc.tables:
        apply_three_line_style(table)
    doc.save(str(DOCX_PATH))
    print(f"styled tables in {DOCX_PATH}")


if __name__ == "__main__":
    main()
