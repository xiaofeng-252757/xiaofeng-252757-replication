"""Force fixed-width font on code-block paragraphs in the exported DOCX.

Pandoc emits code blocks as paragraphs with style name "Source Code" (and
inline code with the "Verbatim Char" run style).  When the document is
later re-styled by :mod:`style_docx_tables.py`, the CJK East-Asian font
"宋体" is applied globally, and Word's fallback stretches ASCII glyphs to
full-width — producing the ugly "g a m m a _ y" spacing seen in the report.

This post-processor walks the document and, for every paragraph belonging
to a code-block style, resets both ``rFonts w:ascii`` and ``rFonts w:eastAsia``
(and ``w:hAnsi`` / ``w:cs``) to a real monospaced family (Consolas by
default, with a Chinese-friendly fallback SimSun for stray CJK comments in
the code samples).  Run this AFTER ``style_docx_tables.py``.
"""

from __future__ import annotations

import sys
from pathlib import Path

from docx import Document
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Pt

CODE_PARA_STYLES = {"Source Code", "First Paragraph", "SourceCode", "Code"}
CODE_RUN_STYLES = {"Verbatim Char", "VerbatimChar"}
MONO_ASCII = "Consolas"
MONO_EA = "SimSun"


def set_run_font(run, ascii_name: str = MONO_ASCII, ea_name: str = MONO_EA):
    rPr = run._element.get_or_add_rPr()
    rFonts = rPr.find(qn("w:rFonts"))
    if rFonts is None:
        rFonts = OxmlElement("w:rFonts")
        rPr.insert(0, rFonts)
    rFonts.set(qn("w:ascii"), ascii_name)
    rFonts.set(qn("w:hAnsi"), ascii_name)
    rFonts.set(qn("w:cs"), ascii_name)
    rFonts.set(qn("w:eastAsia"), ea_name)
    # keep font size stable; explicit size prevents inheritance surprises
    run.font.size = Pt(10)


def is_code_paragraph(p) -> bool:
    style_name = p.style.name if p.style is not None else ""
    return style_name in CODE_PARA_STYLES


def main(path: str) -> None:
    docx_path = Path(path)
    doc = Document(str(docx_path))
    n_para = 0
    n_run = 0
    for para in doc.paragraphs:
        if is_code_paragraph(para):
            for run in para.runs:
                set_run_font(run)
                n_run += 1
            n_para += 1
        else:
            # also fix inline verbatim runs inside normal paragraphs
            for run in para.runs:
                style_name = run.style.name if run.style is not None else ""
                if style_name in CODE_RUN_STYLES:
                    set_run_font(run)
                    n_run += 1
    doc.save(str(docx_path))
    print(f"fixed {n_para} code paragraphs, {n_run} code runs in {docx_path}")


if __name__ == "__main__":
    default = "gaohong_replication_package/report/高级宏观经济学期末复现报告_最终提交版.docx"
    path = sys.argv[1] if len(sys.argv) > 1 else default
    main(path)
