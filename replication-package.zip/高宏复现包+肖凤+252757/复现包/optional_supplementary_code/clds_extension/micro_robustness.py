"""
Micro robustness + heterogeneity + time-trend visualisation
============================================================

Builds directly on ``micro_empirical_analysis.py`` (the pooled CLDS
2012/2014/2016/2018 loader).  Rather than duplicating the loading logic
this script uses ``runpy.run_path`` to execute the baseline analysis
once, harvest the cleaned pooled DataFrame ``df`` and helper ``run_ols``
and then extends the analysis:

Deliverable A – 5 robustness specifications (R1-R5)
Deliverable B – 4 heterogeneity subsamples (H1-H4)
Deliverable C – time-trend visualisation (matplotlib PNG)

All specifications use the main regression:
    ln_income ~ manufacturing * low_skill
              + age + age² + female + rural_hukou
              + year FE + province FE
with SE clustered at the province level.

Author: 肖凤
Date:   2026-08
"""
from __future__ import annotations

import os
import runpy
import warnings

import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
# Use DejaVu Sans for numeric labels (Noto Sans CJK renders '3' with a heavy
# hook that visually resembles '8' at figure scale).
plt.rcParams["font.family"] = ["DejaVu Sans", "Noto Sans CJK SC"]
plt.rcParams["axes.unicode_minus"] = False

warnings.filterwarnings("ignore", category=UserWarning)
warnings.filterwarnings("ignore", category=FutureWarning)

# ---------------------------------------------------------------------------
# 0. Paths
# ---------------------------------------------------------------------------
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", ".."))
BASE_SCRIPT = os.path.join(HERE, "micro_empirical_analysis.py")

OUT_TABLES = os.path.join(ROOT, "gaohong_replication_package", "output", "tables")
OUT_FIGS = os.path.join(ROOT, "gaohong_replication_package", "output", "figures")
os.makedirs(OUT_TABLES, exist_ok=True)
os.makedirs(OUT_FIGS, exist_ok=True)


# ---------------------------------------------------------------------------
# 1. Reuse the baseline pooled loader
# ---------------------------------------------------------------------------
print("Running baseline analysis to obtain the pooled DataFrame ...")
BASE_G = runpy.run_path(BASE_SCRIPT)  # This produces the baseline's CSVs and returns its globals

df: pd.DataFrame = BASE_G["df"].copy()
run_ols = BASE_G["run_ols"]
stars = BASE_G["stars"]
frames_years = sorted(BASE_G["frames"].keys())
DTA12 = BASE_G["DTA12"]
DTA14 = BASE_G["DTA14"]
DTA16 = BASE_G["DTA16"]
DTA18 = BASE_G["DTA18"]
clean_missing = BASE_G["clean_missing"]
print(f"  pooled df: {df.shape}, years: {frames_years}")


# ---------------------------------------------------------------------------
# 2. Augment df with additional variables needed for robustness
# ---------------------------------------------------------------------------
# R4 needs I3a_16 (employment status: 1=employee).  Only 2014/2016/2018 have it
# (2012 CLDS does not include this variable).  We attach it via IID merge.
def _attach_emp_status(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["emp_status"] = np.nan
    for yr, path, iidcol in [
        (2014, DTA14, "IID2014"),
        (2016, DTA16, "IID2016"),
        (2018, DTA18, "IID2018"),
    ]:
        try:
            aux = pd.read_stata(path, convert_categoricals=False,
                                columns=[iidcol, "I3a_16"])
        except Exception as e:
            print(f"  emp_status {yr} skipped: {e}")
            continue
        aux = aux.rename(columns={iidcol: "iid", "I3a_16": "emp_status_raw"})
        aux["iid"] = pd.to_numeric(aux["iid"], errors="coerce").astype("Int64")
        aux["emp_status_raw"] = clean_missing(aux["emp_status_raw"])
        mask = df["year"] == yr
        merged = df.loc[mask, ["iid"]].merge(aux, on="iid", how="left")
        df.loc[mask, "emp_status"] = merged["emp_status_raw"].values
    return df


df = _attach_emp_status(df)
print("  emp_status attached (non-null share):",
      float(df["emp_status"].notna().mean()))

# income already cleaned in the baseline (>0 & non-missing), but we still need raw income
# for winsorisation, so re-derive it from the wave files (the baseline already exposes df
# with income; but the baseline kept the raw values in 'income' column pre-log).  We work
# off df['income'] and df['work_hours'] which are already available.


# ---------------------------------------------------------------------------
# 3. Common regression setup
# ---------------------------------------------------------------------------
YEAR_DUM_TERMS = [f"year_{y}" for y in frames_years if y != 2014]
CONTROLS = ("age + age2 + female + rural_hukou + "
            + " + ".join(YEAR_DUM_TERMS)
            + " + C(province)")


def extract_row(res, label: str) -> dict:
    """Compact summary for the main regressors of interest."""
    out = {"spec": label,
           "N": int(res.nobs),
           "R2": float(res.rsquared)}
    for k in ["manufacturing", "low_skill", "manufacturing:low_skill"]:
        b = float(res.params.get(k, np.nan))
        se = float(res.bse.get(k, np.nan))
        p = float(res.pvalues.get(k, np.nan))
        out[f"{k}_coef"] = b
        out[f"{k}_se"] = se
        out[f"{k}_p"] = p
        out[f"{k}_cell"] = ("" if np.isnan(b)
                            else f"{b:.4f}{stars(p)} ({se:.4f})")
    return out


# ---------------------------------------------------------------------------
# 4. Deliverable A – Robustness (5 specifications)
# ---------------------------------------------------------------------------
print("\n=== Deliverable A: Robustness ===")
robust_rows = []

# ---- R1: alternative low-skill definition (add senior-high) --------------
d1 = df.copy()
# In the baseline script the raw edu_level in 2012 was recoded so that "never schooled" -> 0
# and I_edu 1..3 map to primary/junior/senior-high; therefore edu<=3 in 2012
# already covers "up to senior high" which is what edu<=4 covers in the other
# waves.  Mirror that convention.
low_alt = pd.Series(0, index=d1.index, dtype="int8")
mask12 = d1["year"] == 2012
low_alt[mask12] = (d1.loc[mask12, "edu_level"] <= 3).astype("int8")
low_alt[~mask12] = (d1.loc[~mask12, "edu_level"] <= 4).astype("int8")
d1["low_skill"] = low_alt.astype("Int64")   # overwrite for this spec only
r1 = run_ols("ln_income ~ manufacturing * low_skill + " + CONTROLS, d1)
robust_rows.append(extract_row(r1, "R1_alt_low_skill(<=4)"))

# ---- R2: broader exposed sector (manufacturing OR mining) ----------------
d2 = df.copy()
d2["manufacturing"] = d2["industry"].isin([3, 4]).astype("Int64")
# rebuild manuf shares for consistency (not required since not in FEs list)
r2 = run_ols("ln_income ~ manufacturing * low_skill + " + CONTROLS, d2)
robust_rows.append(extract_row(r2, "R2_exposed(manuf+mining)"))

# ---- R3: winsorise income at 1st/99th percentiles ------------------------
d3 = df.copy()
inc = d3["income"].astype(float)
lo, hi = inc.quantile([0.01, 0.99])
d3["income_w"] = inc.clip(lower=lo, upper=hi)
d3["ln_income"] = np.log(d3["income_w"].where(d3["income_w"] > 0))
r3 = run_ols("ln_income ~ manufacturing * low_skill + " + CONTROLS, d3)
robust_rows.append(extract_row(r3, "R3_income_winsor_1_99"))

# ---- R4: wage employees only (I3a_16 == 1) -------------------------------
d4 = df[df["emp_status"] == 1].copy()
r4 = run_ols("ln_income ~ manufacturing * low_skill + " + CONTROLS, d4)
robust_rows.append(extract_row(r4, "R4_wage_employees_only"))

# ---- R5: hourly wage instead of annual income ----------------------------
d5 = df.copy()
wh = d5["work_hours"].astype(float)
# I3a_1 is "weekly work hours" so annual hours = 52 * weekly.  Keep positives.
hourly = d5["income"].astype(float) / (52.0 * wh.where(wh > 0))
d5["ln_income"] = np.log(hourly.where(hourly > 0))
r5 = run_ols("ln_income ~ manufacturing * low_skill + " + CONTROLS, d5)
robust_rows.append(extract_row(r5, "R5_ln_hourly_wage"))

robust_df = pd.DataFrame(robust_rows)
robust_df.to_csv(os.path.join(OUT_TABLES, "robustness_results.csv"),
                 index=False, float_format="%.4f")
print(robust_df[["spec", "N", "manufacturing_cell", "low_skill_cell",
                 "manufacturing:low_skill_cell", "R2"]].to_string(index=False))


# ---------------------------------------------------------------------------
# 5. Deliverable B – Heterogeneity (4 subsamples)
# ---------------------------------------------------------------------------
print("\n=== Deliverable B: Heterogeneity ===")

# Coastal province numeric codes (2-digit GB): 北京 11, 天津 12, 河北 13,
# 辽宁 21, 上海 31, 江苏 32, 浙江 33, 福建 35, 山东 37, 广东 44, 海南 46.
COASTAL = {"11", "12", "13", "21", "31", "32", "33", "35", "37", "44", "46"}

hetero_rows = []


def run_hetero(label: str, subdf: pd.DataFrame):
    if len(subdf) < 200:
        return {"spec": label, "N": len(subdf),
                "manufacturing:low_skill_coef": np.nan,
                "manufacturing:low_skill_se": np.nan,
                "manufacturing:low_skill_p": np.nan,
                "manufacturing:low_skill_cell": "",
                "R2": np.nan}
    res = run_ols("ln_income ~ manufacturing * low_skill + " + CONTROLS, subdf)
    k = "manufacturing:low_skill"
    b, se, p = (float(res.params.get(k, np.nan)),
                float(res.bse.get(k, np.nan)),
                float(res.pvalues.get(k, np.nan)))
    return {"spec": label,
            "N": int(res.nobs),
            "manufacturing:low_skill_coef": b,
            "manufacturing:low_skill_se": se,
            "manufacturing:low_skill_p": p,
            "manufacturing:low_skill_cell":
                ("" if np.isnan(b) else f"{b:.4f}{stars(p)} ({se:.4f})"),
            "R2": float(res.rsquared)}


# H1 – hukou
mask_rural = df["hukou"].isin([1, 3])
mask_urban = df["hukou"].isin([2, 4])
hetero_rows.append(run_hetero("H1_rural_hukou",  df[mask_rural]))
hetero_rows.append(run_hetero("H1_urban_hukou",  df[mask_urban]))

# H2 – gender
hetero_rows.append(run_hetero("H2_female", df[df["gender"] == 2]))
hetero_rows.append(run_hetero("H2_male",   df[df["gender"] == 1]))

# H3 – age cohort
hetero_rows.append(run_hetero("H3_age_16_35",
                              df[df["age"].between(16, 35)]))
hetero_rows.append(run_hetero("H3_age_36_65",
                              df[df["age"].between(36, 65)]))

# H4 – coastal vs inland
hetero_rows.append(run_hetero("H4_coastal", df[df["province"].isin(COASTAL)]))
hetero_rows.append(run_hetero("H4_inland",  df[~df["province"].isin(COASTAL)]))

hetero_df = pd.DataFrame(hetero_rows)
hetero_df.to_csv(os.path.join(OUT_TABLES, "heterogeneity_results.csv"),
                 index=False, float_format="%.4f")
print(hetero_df[["spec", "N", "manufacturing:low_skill_cell", "R2"]]
      .to_string(index=False))


# ---------------------------------------------------------------------------
# 6. Deliverable C – Time-trend visualisation
# ---------------------------------------------------------------------------
print("\n=== Deliverable C: Time-trend figure ===")
trend_df = pd.read_csv(os.path.join(OUT_TABLES, "time_trend_coefficients.csv"))
trend_df = trend_df.sort_values("year").reset_index(drop=True)
trend_df["ci_lo"] = trend_df["manuf_x_lowskill"] - 1.96 * trend_df["se"]
trend_df["ci_hi"] = trend_df["manuf_x_lowskill"] + 1.96 * trend_df["se"]

fig, ax = plt.subplots(figsize=(7.2, 4.5))
years = trend_df["year"].astype(int).values
coef = trend_df["manuf_x_lowskill"].values
lo = coef - trend_df["ci_lo"].values * 0 + (coef - trend_df["ci_lo"].values)
# Compute error bar magnitudes explicitly
err_lower = coef - trend_df["ci_lo"].values
err_upper = trend_df["ci_hi"].values - coef

ax.errorbar(years, coef,
            yerr=[err_lower, err_upper],
            fmt="o-", color="#1f4e79", ecolor="#1f4e79",
            elinewidth=1.4, capsize=6, capthick=1.4, markersize=8,
            markerfacecolor="#1f4e79", linewidth=1.8,
            label="Manufacturing × Low-skill (95% CI)")

# Annotate coefficients
for x, y, se in zip(years, coef, trend_df["se"].values):
    ax.annotate(f"{y:+.3f}", xy=(x, y),
                xytext=(0, 12), textcoords="offset points",
                ha="center", va="bottom", fontsize=9, color="#1f4e79")

ax.axhline(0, color="#888888", linewidth=1.0, linestyle="--")
ax.set_xticks(years)
ax.set_xlabel("Year (CLDS wave)")
ax.set_ylabel(r"Coefficient on $\mathrm{Manufacturing}\times\mathrm{Low\ skill}$")
ax.set_title("Time trend of the manufacturing × low-skill wage premium\n"
             "(CLDS pooled, province & year FE, cluster-robust SE)")
ax.legend(loc="lower right", frameon=False)
ax.grid(alpha=0.25, linestyle=":")
fig.tight_layout()
fig_path = os.path.join(OUT_FIGS, "time_trend_interaction.png")
fig.savefig(fig_path, dpi=300)
print(f"  saved: {fig_path}")


# ---------------------------------------------------------------------------
# 7. Console summary
# ---------------------------------------------------------------------------
print("\n" + "=" * 78)
print("ROBUSTNESS & HETEROGENEITY SUMMARY")
print("=" * 78)
print("\nRobustness (manufacturing × low_skill):")
for r in robust_rows:
    print(f"  {r['spec']:<32s}  {r['manufacturing:low_skill_cell']:<28s}  "
          f"N={r['N']:>6d}  R²={r['R2']:.4f}")

print("\nHeterogeneity (manufacturing × low_skill):")
for r in hetero_rows:
    print(f"  {r['spec']:<32s}  {r['manufacturing:low_skill_cell']:<28s}  "
          f"N={r['N']:>6d}  R²={r['R2']:.4f}")

print(f"\nTime-trend figure : {fig_path}")
print("Robustness CSV    :", os.path.join(OUT_TABLES, "robustness_results.csv"))
print("Heterogeneity CSV :", os.path.join(OUT_TABLES, "heterogeneity_results.csv"))
print("Done.")
