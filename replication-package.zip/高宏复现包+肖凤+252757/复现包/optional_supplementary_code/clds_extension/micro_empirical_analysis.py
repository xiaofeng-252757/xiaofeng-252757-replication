"""
Micro-empirical analysis:
CLDS pooled panel (2012, 2014, 2016, 2018) with IV regression
==========================================================================

This script produces the CLDS micro-empirical extension results reported in
Appendix B of the replication report.  Design choices worth flagging:
    1. Pooled panel covers CLDS 2012 + 2014 + 2016 + 2018.
    2. IV / 2SLS handles endogenous manufacturing status via a Bartik-style
       instrument built from CLDS 2012 province-level manufacturing employment
       shares.
    3. Time-trend event-study coefficients on manufacturing x low_skill are
       exported for the time-trend figure.
    4. Industry coding: CLDS value labels show
           1 = 农、林、牧、渔业 (agriculture)
           3 = 制造业        (manufacturing)
       so the manufacturing indicator is `industry == 3`, not `== 1`.
       Both codings are reported in the descriptives for transparency;
       regressions use the manufacturing = 3 convention.
    5. Province harmonisation: CLDS 2014 encodes province as 6-digit GB codes
       (110000 ...); 2016 and 2018 use 2-digit codes (11 ...).  All are
       divided down to the 2-digit level.
    6. CLDS 2012 questionnaire uses different section numbering:
           education level : I_edu    (I2_1 in 2012 is only a Y/N flag)
           industry        : I3a_11   (I3a_8 is a fixed-workplace dummy)
           hukou           : I1_9_6   (no I1_14 in 2012)
           age             : I1_1     (no `birthyear` in 2012)
           gender          : I1_2
           income units    : 10 000 CNY (万元)  -> multiplied by 10 000
       For 2018, `Ibirthyear` / `Igender` are the loaded/filtered versions.

Author:  肖凤
Date:    2026-08
"""
from __future__ import annotations

import glob
import os
import warnings

import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf
from linearmodels.iv import IV2SLS

warnings.filterwarnings("ignore", category=UserWarning)
warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=UnicodeWarning)

# ---------------------------------------------------------------------------
# 0. Paths
# ---------------------------------------------------------------------------
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
OUTDIR = os.path.join(ROOT, "gaohong_replication_package", "output", "tables")
os.makedirs(OUTDIR, exist_ok=True)


def _locate_2012() -> str:
    cands = [p for p in glob.glob(
        os.path.join(ROOT, "clds_raw/clds2012_transcoded/**/*.dta"), recursive=True)
        if "bak.stunicode" not in p and os.path.getsize(p) > 50 * 1024 * 1024]
    cands.sort(key=lambda p: -os.path.getsize(p))
    # The individual file is the ~53MB one containing IID+I_edu+I3a_11
    for p in cands:
        try:
            it = pd.read_stata(p, convert_categoricals=False, chunksize=100)
            cols = list(next(iter(it)).columns)
            if "IID" in cols and "I_edu" in cols and "I3a_11" in cols:
                return p
        except Exception:
            continue
    raise FileNotFoundError("Could not locate CLDS 2012 individual file")


def _locate_2018() -> str:
    cands = glob.glob(
        os.path.join(ROOT,
                     "clds_raw/clds2018_transcoded/2018/CLDS2018Stata13/*.dta"))
    cands.sort(key=lambda p: -os.path.getsize(p))
    for p in cands:
        try:
            it = pd.read_stata(p, convert_categoricals=False, chunksize=100)
            cols = list(next(iter(it)).columns)
            if "IID2018" in cols and "I2_1" in cols and "I3a_8" in cols:
                return p
        except Exception:
            continue
    raise FileNotFoundError("Could not locate CLDS 2018 individual file")


DTA12 = _locate_2012()
DTA14 = os.path.join(ROOT, "clds_raw", "clds2014_transcoded", "individual2014.dta")
DTA16 = os.path.join(ROOT, "clds_raw", "clds2016_clean", "individual2016.dta")
DTA18 = _locate_2018()

print("Data files:")
for tag, p in [("2012", DTA12), ("2014", DTA14),
               ("2016", DTA16), ("2018", DTA18)]:
    print(f"  {tag}: {os.path.basename(p).encode('ascii','replace').decode():<60s}"
          f"  {os.path.getsize(p)//1024//1024:>4d} MB")

MISSING_CODES = {-1, -2, -3, -8, -9, 99, 98,
                 99997, 99998, 99999, 999997, 999998, 999999}


def clean_missing(s: pd.Series) -> pd.Series:
    """Set CLDS missing / DK / refuse codes to NaN."""
    s = pd.to_numeric(s, errors="coerce")
    return s.where(~s.isin(MISSING_CODES))


def harmonize_province(s: pd.Series) -> pd.Series:
    """Reduce 6-digit provincial GB codes (e.g. 440000) to 2-digit (44)."""
    v = pd.to_numeric(s, errors="coerce")
    v = v.where(v < 999900)                     # drop refuse/DK
    v = np.where(v >= 1000, v // 10000, v)      # collapse 6-digit -> 2-digit
    return pd.Series(v, index=s.index).astype("Int64")


# ---------------------------------------------------------------------------
# 1. Loaders (one per wave) - all return the same schema
# ---------------------------------------------------------------------------
COMMON = ["iid", "province", "year",
          "birthyear", "gender", "edu_level",
          "industry", "income", "work_hours", "training", "hukou"]


def load_2012() -> pd.DataFrame:
    df = pd.read_stata(DTA12, convert_categoricals=False, columns=[
        "IID", "PROVINCE",
        "I1_1", "I1_2", "I_edu", "I2_1",
        "I3a_11", "I3a_6", "I3a_1", "I2_9", "I1_9_6"])
    out = pd.DataFrame(index=df.index)
    out["iid"] = df["IID"].astype("Int64")
    out["province"] = harmonize_province(df["PROVINCE"])
    out["year"] = 2012
    age = clean_missing(df["I1_1"])
    out["birthyear"] = 2012 - age
    out["gender"] = clean_missing(df["I1_2"])
    edu = clean_missing(df["I_edu"])
    ever = clean_missing(df["I2_1"])          # 1=ever schooled, 2=never
    # 2012 I_edu is only populated for ever-schooled.  Encode "never" as 0
    # so that never-schooled counts as "low skill" but does not artificially
    # inflate the middle range.
    edu = edu.where(edu.notna(), other=np.where(ever == 2, 0, np.nan))
    out["edu_level"] = edu
    out["industry"] = clean_missing(df["I3a_11"])
    out["income"] = clean_missing(df["I3a_6"]) * 10_000.0     # 万元 -> 元
    out["work_hours"] = clean_missing(df["I3a_1"])
    out["training"] = clean_missing(df["I2_9"])
    hk = clean_missing(df["I1_9_6"])
    # 2012 only has 1=农业, 2=非农; keep same numeric convention as later waves
    out["hukou"] = hk
    return out


def load_2014() -> pd.DataFrame:
    df = pd.read_stata(DTA14, convert_categoricals=False, columns=[
        "IID2014", "PROVINCE",
        "birthyear", "gender", "I2_1",
        "I3a_8", "I3a_6", "I3a_1", "I2_9", "I1_14"])
    out = pd.DataFrame(index=df.index)
    out["iid"] = df["IID2014"].astype("Int64")
    out["province"] = harmonize_province(df["PROVINCE"])
    out["year"] = 2014
    out["birthyear"] = clean_missing(df["birthyear"])
    out["gender"] = clean_missing(df["gender"])
    out["edu_level"] = clean_missing(df["I2_1"])
    out["industry"] = clean_missing(df["I3a_8"])
    out["income"] = clean_missing(df["I3a_6"])
    out["work_hours"] = clean_missing(df["I3a_1"])
    out["training"] = clean_missing(df["I2_9"])
    out["hukou"] = clean_missing(df["I1_14"])
    return out


def load_2016() -> pd.DataFrame:
    df = pd.read_stata(DTA16, convert_categoricals=False, columns=[
        "IID2016", "PROV2016",
        "birthyear", "gender", "I2_1",
        "I3a_8", "I3a_6", "I3a_1", "I2_9", "I1_14"])
    out = pd.DataFrame(index=df.index)
    out["iid"] = df["IID2016"].astype("Int64")
    out["province"] = harmonize_province(df["PROV2016"])
    out["year"] = 2016
    out["birthyear"] = clean_missing(df["birthyear"])
    out["gender"] = clean_missing(df["gender"])
    out["edu_level"] = clean_missing(df["I2_1"])
    out["industry"] = clean_missing(df["I3a_8"])
    out["income"] = clean_missing(df["I3a_6"])
    out["work_hours"] = clean_missing(df["I3a_1"])
    out["training"] = clean_missing(df["I2_9"])
    out["hukou"] = clean_missing(df["I1_14"])
    return out


def load_2018() -> pd.DataFrame:
    df = pd.read_stata(DTA18, convert_categoricals=False, columns=[
        "IID2018", "PROV2018",
        "Ibirthyear", "Igender", "I2_1",
        "I3a_8", "I3a_6", "I3a_1", "I2_9", "I1_14"])
    out = pd.DataFrame(index=df.index)
    out["iid"] = df["IID2018"].astype("Int64")
    out["province"] = harmonize_province(df["PROV2018"])
    out["year"] = 2018
    out["birthyear"] = clean_missing(df["Ibirthyear"])
    out["gender"] = clean_missing(df["Igender"])
    out["edu_level"] = clean_missing(df["I2_1"])
    out["industry"] = clean_missing(df["I3a_8"])
    out["income"] = clean_missing(df["I3a_6"])
    out["work_hours"] = clean_missing(df["I3a_1"])
    out["training"] = clean_missing(df["I2_9"])
    out["hukou"] = clean_missing(df["I1_14"])
    return out


# ---------------------------------------------------------------------------
# 2. Pool
# ---------------------------------------------------------------------------
print("\nLoading waves ...")
loaders = {2012: load_2012, 2014: load_2014,
           2016: load_2016, 2018: load_2018}
frames = {}
for y, fn in loaders.items():
    try:
        d = fn()
        frames[y] = d
        print(f"  {y}: {len(d):>6,d} obs, cols OK")
    except Exception as e:
        print(f"  {y}: ERROR - {e}")

df = pd.concat([frames[y][COMMON] for y in sorted(frames)],
               ignore_index=True, sort=False)
print(f"Pooled raw: {len(df):,} obs across {sorted(frames)}")


# ---------------------------------------------------------------------------
# 3. Analysis variables
# ---------------------------------------------------------------------------
df["age"] = df["year"] - df["birthyear"]
df["age2"] = df["age"] ** 2

df["female"] = (df["gender"] == 2).astype("Int64")
df["rural_hukou"] = df["hukou"].isin([1, 3]).astype("Int64")
df["training_bin"] = np.where(df["training"] == 1, 1,
                              np.where(df["training"] == 2, 0, np.nan))

# Low-skill: <=3 for 2014/2016/2018 (未上过学 / 小学 / 初中).
# For 2012 the edu variable is I_edu with a slightly different scale
# (1=小学, 2=初中, 3=高中).  We recoded never-schooled to 0 in load_2012,
# so low-skill in 2012 = edu_level <= 2, matching primary + junior high.
low = pd.Series(0, index=df.index, dtype="int8")
mask12 = df["year"] == 2012
low[mask12] = (df.loc[mask12, "edu_level"] <= 2).astype("int8")
low[~mask12] = (df.loc[~mask12, "edu_level"] <= 3).astype("int8")
df["low_skill"] = low.astype("Int64")

# CORRECTED manufacturing indicator (v1 used industry==1 which is agriculture)
df["manufacturing"] = (df["industry"] == 3).astype("Int64")
df["manufacturing_v1code"] = (df["industry"] == 1).astype("Int64")

df["income"] = df["income"].where(df["income"] > 0)
df["ln_income"] = np.log(df["income"])
df["ln_work_hours"] = np.log(df["work_hours"].where(df["work_hours"].between(1, 100)))

# Year dummies
for y in sorted(frames):
    df[f"year_{y}"] = (df["year"] == y).astype("Int64")

# Working age
df = df[df["age"].between(16, 65)].copy()

# Province numeric -> string for FE / cluster
df["province"] = df["province"].astype("Int64").astype(str)
df = df[df["province"] != "<NA>"]


# ---------------------------------------------------------------------------
# 4. Build province-level 2012 baseline manufacturing share  (Bartik-style IV)
# ---------------------------------------------------------------------------
d12 = df[df["year"] == 2012].copy()
prov_manuf_share = (d12.groupby("province")["manufacturing"]
                       .mean().rename("prov_manuf_share_2012"))
prov_manuf_share_v1 = (d12.groupby("province")["manufacturing_v1code"]
                          .mean().rename("prov_manuf_share_2012_v1"))
df = df.merge(prov_manuf_share, on="province", how="left")
df = df.merge(prov_manuf_share_v1, on="province", how="left")

# Bartik-lite: interact baseline share with a linear time index
df["yr_idx"] = (df["year"] - 2012) / 6.0
df["Z_bartik"] = df["prov_manuf_share_2012"] * df["yr_idx"]


# ---------------------------------------------------------------------------
# 5. Descriptives
# ---------------------------------------------------------------------------
desc_vars = ["ln_income", "income", "manufacturing", "manufacturing_v1code",
             "low_skill", "age", "female", "rural_hukou",
             "training_bin", "work_hours"]
desc_all = df[desc_vars].describe().T[["count", "mean", "std", "min", "50%", "max"]]
desc_all.columns = ["N", "mean", "sd", "min", "median", "max"]
desc_all.to_csv(os.path.join(OUTDIR, "descriptive_stats.csv"),
                float_format="%.4f")

by_year = (df.groupby("year")
             .agg(N=("iid", "size"),
                  ln_income_mean=("ln_income", "mean"),
                  income_mean=("income", "mean"),
                  manuf_share=("manufacturing", "mean"),
                  low_skill_share=("low_skill", "mean"),
                  female_share=("female", "mean"),
                  rural_hukou_share=("rural_hukou", "mean"),
                  age_mean=("age", "mean")))
by_year.to_csv(os.path.join(OUTDIR, "descriptive_by_year.csv"),
               float_format="%.4f")


# ---------------------------------------------------------------------------
# 6. Regression helpers
# ---------------------------------------------------------------------------
def stars(p: float) -> str:
    if pd.isna(p):
        return ""
    if p < 0.01:
        return "***"
    if p < 0.05:
        return "**"
    if p < 0.10:
        return "*"
    return ""


def run_ols(formula: str, data: pd.DataFrame, cluster: str = "province"):
    d = data.dropna(subset=[cluster]).copy()
    mod = smf.ols(formula, data=d)
    used = mod.data.row_labels
    groups = d.loc[used, cluster].astype(str).values
    return mod.fit(cov_type="cluster", cov_kwds={"groups": groups})


# ---------------------------------------------------------------------------
# 7. Main pooled regressions
# ---------------------------------------------------------------------------
year_dum = " + ".join([f"year_{y}"
                       for y in sorted(frames) if y != 2014])   # 2014 = base
controls = f"age + age2 + female + rural_hukou + {year_dum} + C(province)"

f_main = ("ln_income ~ manufacturing * low_skill + " + controls)
f_triple = ("ln_income ~ manufacturing * low_skill * yr_idx + "
            f"age + age2 + female + rural_hukou + C(province)")
f_train = ("training_bin ~ manufacturing * low_skill + " + controls)
f_hours = ("ln_work_hours ~ manufacturing * low_skill + " + controls)

print("\nRunning main OLS models ...")
r_main = run_ols(f_main, df)
r_triple = run_ols(f_triple, df)
r_train = run_ols(f_train, df)
r_hours = run_ols(f_hours, df)


def coef_cell(res, name: str) -> str:
    if name not in res.params.index:
        return ""
    b, se, p = res.params[name], res.bse[name], res.pvalues[name]
    return f"{b:.4f}{stars(p)} ({se:.4f})"


KEEP = ["Intercept", "manufacturing", "low_skill",
        "manufacturing:low_skill",
        *[f"year_{y}" for y in sorted(frames) if y != 2014],
        "yr_idx",
        "manufacturing:yr_idx", "low_skill:yr_idx",
        "manufacturing:low_skill:yr_idx",
        "age", "age2", "female", "rural_hukou"]

results = {"M1_lnIncome": r_main, "M2_triple_yr": r_triple,
           "M3_training": r_train, "M4_lnHours": r_hours}
rows = [[v] + [coef_cell(res, v) for res in results.values()] for v in KEEP]
meta = [
    ["N",       *[f"{int(res.nobs)}"        for res in results.values()]],
    ["R2",      *[f"{res.rsquared:.4f}"     for res in results.values()]],
    ["R2 adj",  *[f"{res.rsquared_adj:.4f}" for res in results.values()]],
    ["Prov FE", *["Yes"                     for _   in results.values()]],
]
coef_df = pd.DataFrame(rows + meta,
                       columns=["variable"] + list(results.keys()))
coef_df.to_csv(os.path.join(OUTDIR, "regression_coefficients.csv"),
               index=False)

with open(os.path.join(OUTDIR, "regression_full_results.txt"), "w") as fh:
    for name, res in results.items():
        fh.write("=" * 78 + "\n")
        fh.write(f"Model: {name}\n")
        fh.write("=" * 78 + "\n")
        fh.write(res.summary().as_text())
        fh.write("\n\n")


# ---------------------------------------------------------------------------
# 8. Time trend: year-by-year manufacturing x low_skill coefficient
# ---------------------------------------------------------------------------
print("\nEstimating year-by-year manuf x low_skill ...")
trend_rows = []
f_by_year = ("ln_income ~ manufacturing * low_skill + age + age2 + "
             "female + rural_hukou + C(province)")
for y in sorted(frames):
    sub = df[df["year"] == y]
    if len(sub) < 200:
        trend_rows.append({"year": y, "N": len(sub),
                           "manuf_x_lowskill": np.nan,
                           "se": np.nan, "p": np.nan,
                           "manuf": np.nan, "low_skill": np.nan})
        continue
    r_y = run_ols(f_by_year, sub)
    kk = "manufacturing:low_skill"
    trend_rows.append({
        "year": y, "N": int(r_y.nobs),
        "manuf_x_lowskill": float(r_y.params.get(kk, np.nan)),
        "se":               float(r_y.bse.get(kk, np.nan)),
        "p":                float(r_y.pvalues.get(kk, np.nan)),
        "manuf":            float(r_y.params.get("manufacturing", np.nan)),
        "low_skill":        float(r_y.params.get("low_skill", np.nan)),
    })
trend_df = pd.DataFrame(trend_rows)
trend_df.to_csv(os.path.join(OUTDIR, "time_trend_coefficients.csv"),
                index=False)


# ---------------------------------------------------------------------------
# 9. IV: manufacturing endogenous, Bartik-style instrument
# ---------------------------------------------------------------------------
print("\nEstimating IV models ...")

iv_vars = ["ln_income", "manufacturing", "low_skill",
           "age", "age2", "female", "rural_hukou",
           "prov_manuf_share_2012", "Z_bartik",
           "yr_idx", "province", "year"]
d_iv = df[iv_vars + [f"year_{y}" for y in sorted(frames) if y != 2014]].dropna()
d_iv = d_iv.copy()
# Cast nullable Int64 columns to float for statsmodels / linearmodels
for c in d_iv.columns:
    if d_iv[c].dtype.name in ("Int64", "Int32", "Int16", "Int8", "boolean"):
        d_iv[c] = d_iv[c].astype(float)
d_iv["manuf_x_low"] = d_iv["manufacturing"] * d_iv["low_skill"]

# ---- 8a. OLS benchmark (with province FE via dummies) -------------------
year_terms = [f"year_{y}" for y in sorted(frames) if y != 2014]
X_exog_names = ["low_skill", "age", "age2", "female", "rural_hukou",
                *year_terms]
prov_dum = pd.get_dummies(d_iv["province"], prefix="prov",
                          drop_first=True).astype(float)
prov_cols = list(prov_dum.columns)
d_iv = pd.concat([d_iv, prov_dum], axis=1)

# Build design matrices
exog = sm.add_constant(d_iv[X_exog_names + prov_cols].astype(float))
endog = d_iv[["manufacturing", "manuf_x_low"]].astype(float)
instr = d_iv[["prov_manuf_share_2012", "Z_bartik"]].astype(float).copy()
# `prov_manuf_share_2012` is province-constant so absorbed by province FE.
# The excluded instrument is Z_bartik = share * yr_idx.  To also instrument
# `manuf_x_low`, we use Z_bartik * low_skill.
instr["Z_bartik_x_low"] = instr["Z_bartik"] * d_iv["low_skill"]
instr = instr[["Z_bartik", "Z_bartik_x_low"]]

y = d_iv["ln_income"].astype(float)

# OLS with same controls (no endogenous treatment) --------------
ols_bench = sm.OLS(y, sm.add_constant(pd.concat(
    [endog, d_iv[X_exog_names + prov_cols].astype(float)], axis=1))).fit(
    cov_type="cluster",
    cov_kwds={"groups": d_iv["province"].astype(str).values})

# 2SLS ---------------------------------------------------------
iv_model = IV2SLS(dependent=y, exog=exog, endog=endog, instruments=instr)
iv_res = iv_model.fit(cov_type="clustered", clusters=d_iv["province"].values)

# First-stage manually to get F stat
fs_manuf = sm.OLS(
    d_iv["manufacturing"].astype(float),
    sm.add_constant(pd.concat([instr, d_iv[X_exog_names + prov_cols].astype(float)],
                              axis=1))).fit(
    cov_type="cluster",
    cov_kwds={"groups": d_iv["province"].astype(str).values})
fs_int = sm.OLS(
    d_iv["manuf_x_low"].astype(float),
    sm.add_constant(pd.concat([instr, d_iv[X_exog_names + prov_cols].astype(float)],
                              axis=1))).fit(
    cov_type="cluster",
    cov_kwds={"groups": d_iv["province"].astype(str).values})

# Joint F on excluded instruments (Wald test)
inst_names = list(instr.columns)
try:
    fstat_manuf = float(fs_manuf.f_test(
        " = 0, ".join(inst_names) + " = 0").fvalue)
except Exception:
    fstat_manuf = np.nan
try:
    fstat_int = float(fs_int.f_test(
        " = 0, ".join(inst_names) + " = 0").fvalue)
except Exception:
    fstat_int = np.nan

# First-stage table (just excluded instruments and their p-values) ----
fs_rows = []
for stg_name, stg_res, fstat in [("manufacturing", fs_manuf, fstat_manuf),
                                  ("manuf_x_low",   fs_int,  fstat_int)]:
    for inm in inst_names:
        fs_rows.append({
            "stage":     stg_name,
            "regressor": inm,
            "coef":      float(stg_res.params.get(inm, np.nan)),
            "se":        float(stg_res.bse.get(inm, np.nan)),
            "p":         float(stg_res.pvalues.get(inm, np.nan)),
        })
    fs_rows.append({"stage": stg_name, "regressor": "F(excluded)",
                    "coef": fstat, "se": np.nan, "p": np.nan})
    fs_rows.append({"stage": stg_name, "regressor": "N",
                    "coef": int(stg_res.nobs), "se": np.nan, "p": np.nan})
pd.DataFrame(fs_rows).to_csv(os.path.join(OUTDIR, "first_stage.csv"),
                             index=False, float_format="%.4f")

# IV vs OLS side-by-side ----------------------------------------
def get_coef(res, name):
    if hasattr(res, "params") and name in res.params.index:
        return float(res.params[name]), float(res.bse[name]), float(res.pvalues[name])
    return np.nan, np.nan, np.nan


keys_iv = ["manufacturing", "manuf_x_low", "low_skill",
           "age", "age2", "female", "rural_hukou"]
iv_rows = []
for k in keys_iv:
    b_ols, se_ols, p_ols = get_coef(ols_bench, k)
    b_iv,  se_iv,  p_iv  = (float(iv_res.params[k]),
                            float(iv_res.std_errors[k]),
                            float(iv_res.pvalues[k])) if k in iv_res.params.index \
                            else (np.nan, np.nan, np.nan)
    iv_rows.append({"variable": k,
                    "OLS_coef": b_ols, "OLS_se": se_ols, "OLS_p": p_ols,
                    "IV_coef":  b_iv,  "IV_se":  se_iv,  "IV_p":  p_iv})
iv_rows.append({"variable": "N",
                "OLS_coef": int(ols_bench.nobs), "OLS_se": np.nan, "OLS_p": np.nan,
                "IV_coef":  int(iv_res.nobs),   "IV_se":  np.nan, "IV_p":  np.nan})
iv_rows.append({"variable": "First-stage F (manufacturing)",
                "OLS_coef": np.nan, "OLS_se": np.nan, "OLS_p": np.nan,
                "IV_coef":  fstat_manuf, "IV_se": np.nan, "IV_p": np.nan})
iv_rows.append({"variable": "First-stage F (manuf x low)",
                "OLS_coef": np.nan, "OLS_se": np.nan, "OLS_p": np.nan,
                "IV_coef":  fstat_int, "IV_se": np.nan, "IV_p": np.nan})
# Over-identification test
try:
    oid = iv_res.wooldridge_overid          # Wooldridge robust J
    iv_rows.append({"variable": "Overid (Wooldridge stat)",
                    "OLS_coef": np.nan, "OLS_se": np.nan, "OLS_p": np.nan,
                    "IV_coef": float(oid.stat), "IV_se": np.nan,
                    "IV_p": float(oid.pval)})
except Exception:
    pass

pd.DataFrame(iv_rows).to_csv(os.path.join(OUTDIR, "iv_regression_results.csv"),
                             index=False, float_format="%.4f")


# ---------------------------------------------------------------------------
# 9b. Alternative IV: drop province FE (Bartik share varies at province level;
#     under province FE much of its identifying variation is absorbed)
# ---------------------------------------------------------------------------
X_alt_names = ["low_skill", "age", "age2", "female", "rural_hukou",
               *year_terms]                             # no prov FE

exog_alt = sm.add_constant(d_iv[X_alt_names].astype(float))
endog_alt = d_iv[["manufacturing", "manuf_x_low"]].astype(float)
# In this spec the *level* of prov_manuf_share_2012 is a valid excluded
# instrument (no longer collinear with province FE).
instr_alt = pd.DataFrame({
    "prov_share": d_iv["prov_manuf_share_2012"].astype(float),
    "prov_share_x_low": (d_iv["prov_manuf_share_2012"]
                         * d_iv["low_skill"]).astype(float),
})

iv_alt = IV2SLS(dependent=y, exog=exog_alt,
                endog=endog_alt, instruments=instr_alt).fit(
    cov_type="clustered", clusters=d_iv["province"].values)

fs_manuf_alt = sm.OLS(
    d_iv["manufacturing"].astype(float),
    sm.add_constant(pd.concat([instr_alt,
                               d_iv[X_alt_names].astype(float)], axis=1))).fit(
    cov_type="cluster",
    cov_kwds={"groups": d_iv["province"].astype(str).values})
fs_int_alt = sm.OLS(
    d_iv["manuf_x_low"].astype(float),
    sm.add_constant(pd.concat([instr_alt,
                               d_iv[X_alt_names].astype(float)], axis=1))).fit(
    cov_type="cluster",
    cov_kwds={"groups": d_iv["province"].astype(str).values})
try:
    fstat_manuf_alt = float(fs_manuf_alt.f_test(
        "prov_share = 0, prov_share_x_low = 0").fvalue)
    fstat_int_alt = float(fs_int_alt.f_test(
        "prov_share = 0, prov_share_x_low = 0").fvalue)
except Exception:
    fstat_manuf_alt, fstat_int_alt = np.nan, np.nan

alt_rows = []
for k in keys_iv:
    if k in iv_alt.params.index:
        alt_rows.append({"variable": k,
                         "IV_alt_coef": float(iv_alt.params[k]),
                         "IV_alt_se":   float(iv_alt.std_errors[k]),
                         "IV_alt_p":    float(iv_alt.pvalues[k])})
alt_rows.append({"variable": "First-stage F (manufacturing)",
                 "IV_alt_coef": fstat_manuf_alt,
                 "IV_alt_se": np.nan, "IV_alt_p": np.nan})
alt_rows.append({"variable": "First-stage F (manuf x low)",
                 "IV_alt_coef": fstat_int_alt,
                 "IV_alt_se": np.nan, "IV_alt_p": np.nan})
alt_rows.append({"variable": "N",
                 "IV_alt_coef": int(iv_alt.nobs),
                 "IV_alt_se": np.nan, "IV_alt_p": np.nan})
pd.DataFrame(alt_rows).to_csv(
    os.path.join(OUTDIR, "iv_regression_results_no_provFE.csv"),
    index=False, float_format="%.4f")


# ---------------------------------------------------------------------------
# 10. Console summary
# ---------------------------------------------------------------------------
print("\n" + "=" * 78)
print("SUMMARY - CLDS pooled")
print("=" * 78)

print("\n(1) Sample composition after cleaning:")
print(by_year.to_string(float_format=lambda x: f"{x:.4f}"))
print(f"\nTotal pooled sample: {len(df):,}")

print("\n(2) Main pooled regression (M1: ln_income ~ manuf * low_skill + ctrls + prov FE)")
print(coef_df.to_string(index=False))

print("\n(3) Time trend (year-by-year manuf x low_skill coefficient):")
print(trend_df.to_string(index=False, float_format=lambda x: f"{x:.4f}"))
delta_trend = float(trend_df["manuf_x_lowskill"].iloc[-1]
                    - trend_df["manuf_x_lowskill"].iloc[0])
print(f"\nChange in manuf x low_skill from {trend_df['year'].iloc[0]} "
      f"to {trend_df['year'].iloc[-1]}: {delta_trend:+.4f}")
if delta_trend < 0:
    print("  -> Effect became MORE negative over time (consistent with a widening "
          "automation-driven gap for low-skill manufacturing workers).")
else:
    print("  -> Effect did NOT become more negative over time (does NOT clearly "
          "support the widening-gap hypothesis).")

print("\n(4) IV first-stage strength (Bartik-style instrument):")
print(f"    With province FE  - F(manufacturing)     : {fstat_manuf:.2f}")
print(f"                       F(manuf x low_skill)  : {fstat_int:.2f}")
print(f"    Without prov FE   - F(manufacturing)     : {fstat_manuf_alt:.2f}")
print(f"                       F(manuf x low_skill)  : {fstat_int_alt:.2f}")
if min(fstat_manuf, fstat_manuf_alt) < 10:
    print("  -> Instrument for manufacturing is WEAK under the province-FE spec")
    print("     (baseline share absorbs into FE).  The alternative spec drops FE")
    print("     to recover cross-province variation for identification.")

print("\n(5) IV vs OLS coefficients on manufacturing (endogenous):")
b_ols_m, _, _ = get_coef(ols_bench, "manufacturing")
b_iv_m,  _, _ = (float(iv_res.params["manufacturing"]), None, None)
b_iv_m_alt   = float(iv_alt.params.get("manufacturing", np.nan))
print(f"    OLS        : {b_ols_m:+.4f}")
print(f"    IV (w/ FE) : {b_iv_m:+.4f}")
print(f"    IV (no FE) : {b_iv_m_alt:+.4f}")
print("    Interaction (manuf x low_skill):")
b_ols_i, _, _ = get_coef(ols_bench, "manuf_x_low")
b_iv_i        = float(iv_res.params.get("manuf_x_low", np.nan))
b_iv_i_alt    = float(iv_alt.params.get("manuf_x_low", np.nan))
print(f"    OLS        : {b_ols_i:+.4f}")
print(f"    IV (w/ FE) : {b_iv_i:+.4f}")
print(f"    IV (no FE) : {b_iv_i_alt:+.4f}")

print("\n(6) DSGE prediction vs data:")
print("    DSGE (Section 4-6 of the paper): rising manufacturing automation")
print("    should push down low-skill wages RELATIVE to high-skill wages,")
print("    yielding a NEGATIVE and WIDENING manufacturing x low_skill effect on")
print("    log income over 2012-2018.  Empirical results:")
kk = "manufacturing:low_skill"
if kk in r_main.params.index:
    print(f"      * Pooled coefficient : {r_main.params[kk]:+.4f} "
          f"(p={r_main.pvalues[kk]:.3f})")
print(f"      * 2012->2018 change   : {delta_trend:+.4f}")
if kk in r_triple.params.index:
    kk3 = "manufacturing:low_skill:yr_idx"
    if kk3 in r_triple.params.index:
        print(f"      * Triple-interaction  : {r_triple.params[kk3]:+.4f} "
              f"(p={r_triple.pvalues[kk3]:.3f})")

print("\nOutputs written to:", OUTDIR)
for f in [
    "regression_coefficients.csv", "regression_full_results.txt",
    "time_trend_coefficients.csv", "iv_regression_results.csv",
    "first_stage.csv", "descriptive_stats.csv",
    "descriptive_by_year.csv",
]:
    print("  -", f)

print("\nDone.")
