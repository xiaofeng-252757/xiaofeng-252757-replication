*******************************************************
* 项目：高级宏观经济学期末作业——微观数据拓展
* 文件：stata_micro_extension.do
* 目的：基于 CLDS 2014 + 2016 池化数据，检验工业智能化
*      对制造业低技能劳动者收入的异质性影响。
*
* 数据来源：中国劳动力动态调查（CLDS）2014、2016
* 数据下载：中山大学社会科学调查中心（需注册申请）
*
* 注意：本 do-file 变量映射已基于 CLDS 真实数据字典校准。
*      对应 Python 分析脚本 micro_empirical_analysis.py 可
*      产生相同结果（Python 版本已在当前工作区实际运行通过）。
*******************************************************

clear all
set more off
version 17.0

cap log close
log using "output/logs/stata_micro_extension.log", replace text

*******************************************************
* 一、路径设定（使用相对路径）
*******************************************************
global DATA2014    "data/micro/individual2014.dta"
global DATA2016    "data/micro/individual2016.dta"
global OUT_TABLE   "output/tables"
global OUT_DATA    "output/data"
global OUT_LOG     "output/logs"

cap mkdir "output"
cap mkdir "$OUT_TABLE"
cap mkdir "$OUT_DATA"
cap mkdir "$OUT_LOG"

* 安装所需外部命令（如已安装会跳过）
cap which reghdfe
if _rc ssc install reghdfe, replace
cap which esttab
if _rc ssc install estout, replace
cap which ftools
if _rc ssc install ftools, replace

*******************************************************
* 二、读取并池化 2014 + 2016 数据
*******************************************************

* --- 2014 ---
use "$DATA2014", clear
gen year = 2014
rename PROVINCE province
* 保留关键变量
keep year province CITY birthyear gender I2_1 I3a_8 I3a_6 I3a_6_1 ///
     I3a_1 I3a_16 I2_9 I1_14 work
tempfile data2014
save `data2014', replace

* --- 2016 ---
use "$DATA2016", clear
gen year = 2016
rename PROV2016 province
keep year province CITY birthyear gender I2_1 I3a_8 I3a_6 I3a_6_1 ///
     I3a_1 I3a_16 I2_9 I1_14 work
tempfile data2016
save `data2016', replace

* --- 池化 ---
use `data2014', clear
append using `data2016'

*******************************************************
* 三、变量清洗与构造
*******************************************************

* 1. 年龄
gen age = year - birthyear
keep if age >= 16 & age <= 65 & age < .
gen age2 = age^2

* 2. 性别
gen female = (gender == 2) if gender < .

* 3. 教育与低技能识别
* I2_1: 1=未上过学, 2=小学/私塾, 3=初中, 4=普通高中, ...11=博士
* 低技能 = 初中及以下（I2_1 <= 3）
replace I2_1 = . if I2_1 < 0 | I2_1 > 11
gen low_skill = (I2_1 <= 3) if I2_1 < .
label define low_skill_lbl 0 "高技能(高中及以上)" 1 "低技能(初中及以下)"
label values low_skill low_skill_lbl

* 4. 行业：制造业
* I3a_8: 行业分类，1=制造业
replace I3a_8 = . if I3a_8 < 0
gen manufacturing = (I3a_8 == 1) if I3a_8 < .
label define mfg_lbl 0 "非制造业" 1 "制造业"
label values manufacturing mfg_lbl

* 5. 户籍
* I1_14: 1=农业, 2=非农, 3=居民(原农), 4=居民(原非农)
replace I1_14 = . if I1_14 < 0
gen rural_hukou = (I1_14 == 1 | I1_14 == 3) if I1_14 < .

* 6. 收入变量：年工作收入
* I3a_6: 年工作总收入（元），负值为缺失编码
replace I3a_6 = . if I3a_6 < 0
gen ln_income = ln(I3a_6) if I3a_6 > 0 & I3a_6 < .

* 7. 工作时长
replace I3a_1 = . if I3a_1 < 0 | I3a_1 > 100
gen ln_hours = ln(I3a_1) if I3a_1 > 0 & I3a_1 < .

* 8. 培训
* I2_9: 1=是, 2=否
replace I2_9 = . if I2_9 < 0
gen training = (I2_9 == 1) if I2_9 < .

* 9. 年份虚拟变量
gen year2016 = (year == 2016)

*******************************************************
* 四、描述性统计
*******************************************************
estpost summarize ln_income manufacturing low_skill age female ///
    rural_hukou training ln_hours year2016 if ln_income < .
esttab using "$OUT_TABLE/stata_desc_stats.rtf", ///
    cells("count mean sd min max") replace ///
    title("CLDS 2014+2016 池化样本描述性统计")

* 分组均值：低技能 × 制造业
table low_skill manufacturing if ln_income < ., ///
    stat(mean ln_income) stat(mean training) stat(count ln_income)

*******************************************************
* 五、基准回归
* Model 1: ln_income ~ manufacturing + low_skill +
*          manufacturing×low_skill + controls + 省份FE
*******************************************************
reghdfe ln_income c.manufacturing##c.low_skill ///
    age age2 female rural_hukou year2016, ///
    absorb(province) vce(cluster province)
est store m1

*******************************************************
* 六、时间趋势模型
* Model 2: 加入三重交互项 manufacturing×low_skill×year2016
*******************************************************
reghdfe ln_income c.manufacturing##c.low_skill##c.year2016 ///
    age age2 female rural_hukou, ///
    absorb(province) vce(cluster province)
est store m2

*******************************************************
* 七、机制检验——培训
* Model 3: training ~ manufacturing×low_skill + controls + 省份FE
*******************************************************
reghdfe training c.manufacturing##c.low_skill ///
    age age2 female rural_hukou year2016, ///
    absorb(province) vce(cluster province)
est store m3

*******************************************************
* 八、机制检验——工时
* Model 4: ln_hours ~ manufacturing×low_skill + controls + 省份FE
*******************************************************
reghdfe ln_hours c.manufacturing##c.low_skill ///
    age age2 female rural_hukou year2016, ///
    absorb(province) vce(cluster province)
est store m4

*******************************************************
* 九、导出回归表
*******************************************************
esttab m1 m2 m3 m4 using "$OUT_TABLE/stata_regression_results.rtf", ///
    replace se star(* 0.10 ** 0.05 *** 0.01) ///
    mtitles("收入(基准)" "收入(时间趋势)" "培训(机制)" "工时(机制)") ///
    title("CLDS微观拓展：制造业自动化暴露与低技能劳动者收入") ///
    note("省份固定效应已控制；标准误聚类到省份。")

* 同时导出 CSV 格式（方便课程报告引用）
esttab m1 m2 m3 m4 using "$OUT_TABLE/stata_regression_results.csv", ///
    replace se star(* 0.10 ** 0.05 *** 0.01) csv

save "$OUT_DATA/micro_extension_workfile.dta", replace

log close

di "============================================="
di "Stata 微观拓展分析完成。"
di "回归结果表见 $OUT_TABLE/stata_regression_results.rtf"
di "============================================="
