% ============================================================
% [EXTENSION — 学生拓展代码，非原文附件]
% Author : 肖凤（本报告作者），基于原文附件二次开发
% Role   : DSGE 参数拓展或政策组合实验批处理脚本，用于附录 A 边界检验.
% Note   : 不属于原文的复现证据链，仅作为方向性拓展工作，与核心复现物理隔离.
%          任何修改不影响 code/original/ 下的作者原始程序.
% ============================================================

% 批处理：拓展 B（政策组合：转移支付 + 劳动补贴 50/50 线性叠加）
% 直接读取 run_fig3_batch.m 已保存的 IRF 数据，无需重跑 Dynare
1;

code_dir = fileparts(mfilename('fullpath'));
supp_dir = fileparts(code_dir);
root_dir = fileparts(supp_dir);
out_fig_dir = fullfile(root_dir, 'output', 'figures');
out_data_dir = fullfile(root_dir, 'output', 'data');
out_table_dir = fullfile(root_dir, 'output', 'tables');

graphics_toolkit('gnuplot');
set(0, 'defaultfigurevisible', 'off');

% 载入 run_fig3_batch.m 保存的 IRF 工作区
fig3_mat = fullfile(out_data_dir, 'fig3_workspace.mat');
if ~exist(fig3_mat, 'file')
    error('fig3_workspace.mat 不存在，请先运行 run_fig3_batch.m');
end
load(fig3_mat);

T = (0:20)';

% 三种单一政策 IRF：
%   xi_e : 一次性转移支付
%   xi_l : 劳动补贴
%   xi_c : 消费补贴
% 组合政策：50%*转移支付 + 50%*劳动补贴
C1_mix = 0.5*C1_ee_xi_e + 0.5*C1_ee_xi_l;
Y_mix  = 0.5*Y_ee_xi_e  + 0.5*Y_ee_xi_l;
INDX_mix = 0.5*INDX_ee_xi_e + 0.5*INDX_ee_xi_l;

zero_line = zeros(size(T));

figure;

subplot(3,1,1);
plot(T, C1_ee_xi_e, '--k', T, C1_ee_xi_l, '-k', ...
     T, C1_ee_xi_c, '-.k', T, C1_mix, ':k', ...
     T, zero_line, '-', 'LineWidth', 1.4);
title('低技能家庭实际收入 IRF', 'Fontsize', 12);
legend('一次性转移支付','劳动补贴','消费补贴','组合政策 50/50', ...
       'Location', 'southeast');
xlabel('季度');

subplot(3,1,2);
plot(T, Y_ee_xi_e, '--k', T, Y_ee_xi_l, '-k', ...
     T, Y_ee_xi_c, '-.k', T, Y_mix, ':k', ...
     T, zero_line, '-', 'LineWidth', 1.4);
title('经济总产出 IRF', 'Fontsize', 12);
xlabel('季度');

subplot(3,1,3);
plot(T, INDX_ee_xi_e, '--k', T, INDX_ee_xi_l, '-k', ...
     T, INDX_ee_xi_c, '-.k', T, INDX_mix, ':k', ...
     T, zero_line, '-', 'LineWidth', 1.4);
title('收入差距指数 IRF', 'Fontsize', 12);
xlabel('季度');

set(gcf, 'PaperPositionMode', 'auto');
print(gcf, fullfile(out_fig_dir, 'ext_policy_mix.png'), '-dpng', '-r150');

save('-v7', fullfile(out_data_dir, 'ext_policy_mix.mat'), ...
    'T', 'C1_ee_xi_e', 'C1_ee_xi_l', 'C1_ee_xi_c', 'C1_mix', ...
    'Y_ee_xi_e', 'Y_ee_xi_l', 'Y_ee_xi_c', 'Y_mix', ...
    'INDX_ee_xi_e', 'INDX_ee_xi_l', 'INDX_ee_xi_c', 'INDX_mix');

% 导出 CSV：t=0 时四种政策下三个变量的响应值
fid = fopen(fullfile(out_table_dir, 'ext_policy_mix_summary.csv'), 'w');
fprintf(fid, 'policy,C1_t0,Y_t0,INDX_t0\n');
fprintf(fid, 'transfer,%.6f,%.6f,%.6f\n', ...
    C1_ee_xi_e(1), Y_ee_xi_e(1), INDX_ee_xi_e(1));
fprintf(fid, 'labor_subsidy,%.6f,%.6f,%.6f\n', ...
    C1_ee_xi_l(1), Y_ee_xi_l(1), INDX_ee_xi_l(1));
fprintf(fid, 'consumption_subsidy,%.6f,%.6f,%.6f\n', ...
    C1_ee_xi_c(1), Y_ee_xi_c(1), INDX_ee_xi_c(1));
fprintf(fid, 'mix_transfer_labor_50_50,%.6f,%.6f,%.6f\n', ...
    C1_mix(1), Y_mix(1), INDX_mix(1));
fclose(fid);

fprintf('Extension B (policy mix) finished successfully.\n');
