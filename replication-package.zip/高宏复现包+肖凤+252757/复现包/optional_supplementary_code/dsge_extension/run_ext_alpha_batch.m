% ============================================================
% [EXTENSION — 学生拓展代码，非原文附件]
% Author : 肖凤（本报告作者），基于原文附件二次开发
% Role   : DSGE 参数拓展或政策组合实验批处理脚本，用于附录 A 边界检验.
% Note   : 不属于原文的复现证据链，仅作为方向性拓展工作，与核心复现物理隔离.
%          任何修改不影响 code/original/ 下的作者原始程序.
% ============================================================

% 批处理：运行拓展 A（更宽 α 网格）脚本并保存图像与关键变量
1;

code_dir = fileparts(mfilename('fullpath'));
supp_dir = fileparts(code_dir);
root_dir = fileparts(supp_dir);
orig_dir = fullfile(root_dir, 'code', 'original');
out_fig_dir = fullfile(root_dir, 'output', 'figures');
out_data_dir = fullfile(root_dir, 'output', 'data');
out_table_dir = fullfile(root_dir, 'output', 'tables');

graphics_toolkit('gnuplot');
set(0, 'defaultfigurevisible', 'off');
addpath(orig_dir);

old_dir = pwd();
cleanup = onCleanup(@() cd(old_dir));
cd(orig_dir);

run(fullfile(code_dir, 'fig_ext_alpha_wide.m'));

cd(orig_dir);

set(gcf, 'PaperPositionMode', 'auto');
print(gcf, fullfile(out_fig_dir, 'ext_alpha_wide.png'), '-dpng', '-r150');

save('-v7', fullfile(out_data_dir, 'ext_alpha_wide.mat'), ...
    'xx', 'Y', 'ROB', 'income1', 'income2', 'income3', 'INDX', ...
    'wu', 'ws', 'wu_Y', 'ws_Y', 'we_Y', 'ROB_Y');

%% 导出 CSV 摘要：α ∈ {0.15, 0.25, 0.35, 0.50, 0.65, 0.75}
target_alphas = [0.15, 0.25, 0.35, 0.50, 0.65, 0.75];
n_targets = length(target_alphas);

fid = fopen(fullfile(out_table_dir, 'ext_alpha_wide_summary.csv'), 'w');
fprintf(fid, 'alpha,income_low_skill,income_high_skill,income_capital,share_low_skill,share_high_skill,share_capital\n');
for k = 1:n_targets
    a = target_alphas(k);
    [~, idx] = min(abs(xx - a));
    fprintf(fid, '%.2f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f\n', ...
        xx(idx), income1(idx), income2(idx), income3(idx), ...
        wu_Y(idx), ws_Y(idx), we_Y(idx));
end
fclose(fid);

fprintf('Extension A (wide alpha scan) finished successfully.\n');
