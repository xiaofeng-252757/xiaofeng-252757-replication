% ============================================================
% [EXTENSION — 学生拓展代码，非原文附件]
% Author : 肖凤（本报告作者），基于原文附件二次开发
% Role   : DSGE 参数拓展或政策组合实验批处理脚本，用于附录 A 边界检验.
% Note   : 不属于原文的复现证据链，仅作为方向性拓展工作，与核心复现物理隔离.
%          任何修改不影响 code/original/ 下的作者原始程序.
% ============================================================

%% 拓展 A：更宽范围的智能投入要素密集度 α 敏感性
%% 复制 fig_2.m 结构，仅修改 α 网格从 [0.25, 0.5] 扩展到 [0.15, 0.75]
clc
clear
sigma1 = 0.8;
sigma2 = 0.8;
sigma3 = 0.8;
mu = 1.2;
%alpha = 0.25;
eta = 0.5;
theta = 0.7;
beta = 0.995;
delta = 0.025;
delta_R = 0.05;
OMEGA_K = 4;
OMEGA_R = 2;
g_ss = 0.18;
phi = 0.967;
rho_lambda = 0.925;
rho_L = 0.37;
rho_zz = 0.3;
theta_A = 1.35;
kappa = 0.95;

%% 趋势计算
gamma_y = 0.02708;
gamma_lambdau = (1+gamma_y)^(-sigma1)-1;
gamma_a = (1+gamma_y)^((1-theta)/(theta*(theta_A-1)))-1;
gamma_rob = (1+gamma_y)^(1/theta)-1;

%% 长期趋势实验（拓展 A：α 网格 [0.15, 0.75]）
xx = 0.15:0.01:0.75;
ht = linspace(1,2,length(xx));
Y = zeros(length(xx),1);
ROB = zeros(length(xx),1);
income1 = zeros(length(xx),1);
income2 = zeros(length(xx),1);
income3 = zeros(length(xx),1);
INDX = zeros(length(xx),1);
wu = zeros(length(xx),1);
ws = zeros(length(xx),1);
we = zeros(length(xx),1);
wu_Y = zeros(length(xx),1);
ws_Y = zeros(length(xx),1);
we_Y = zeros(length(xx),1);
ROB_Y = zeros(length(xx),1);
i = 1;


for alpha = xx
MC_ss = 1/mu;
LAMBDA_ss = beta*(1+gamma_lambdau);
R_ss = 1/(beta*(1+gamma_lambdau));
qk_ss = 1/(1-OMEGA_K*gamma_y^2/2-OMEGA_K*gamma_y*(1+gamma_y)+LAMBDA_ss*OMEGA_K*gamma_y*(1+gamma_y)^2);
qR_ss = 1/(  1-OMEGA_R*((1+gamma_y)/(1+gamma_a)-1)^2/2 -OMEGA_R*((1+gamma_y)/(1+gamma_a)-1)*(1+gamma_y)/(1+gamma_a)+...
        LAMBDA_ss*(1+gamma_a)*OMEGA_R*((1+gamma_y)/(1+gamma_a)-1)*((1+gamma_y)/(1+gamma_a))^2 );
RK_ss = qk_ss/LAMBDA_ss-(1-delta)*qk_ss;
zeta_R = 1.15;
RR_ss = (qR_ss/LAMBDA_ss-(1-delta_R)*(1+gamma_a)*qR_ss)*zeta_R;
RF_ss = RR_ss;
% fslove求解稳态
myfun = @(x)[x(3)-(x(1)/(1+gamma_y)) ^eta
x(5) - (RK_ss*x(1)/(eta*(1-alpha)*MC_ss*(1+gamma_y)*x(3)))^(1/(1-kappa))*x(3)
x(4) - ((x(5)^kappa-(1-alpha)*x(3)^kappa)/alpha)^(1/kappa)
x(2) - x(4)^(1/theta)*(1+gamma_rob)
RF_ss - alpha*theta*MC_ss*(x(5)/x(4))^(1-kappa)*x(4)/(x(2)/(1+gamma_rob))];
if i == 1
    x0 = [30,20,4,6,8];
else
    x0 = x_prev;
end
x = fsolve(myfun, x0);
x_prev = x;
K_ss = x(1);
ROBF_ss = x(2);
HT_ss = x(3);
HR_ss = x(4);
Y_ss = x(5);

rob_ss = ROBF_ss;
I_ss = (1-(1-delta)/(1+gamma_y))*K_ss/(1-OMEGA_K*gamma_y^2/2);
IR_ss = (1-(1-delta_R)*(1+gamma_a)/(1+gamma_y))*ROBF_ss/(1-OMEGA_R*((1+gamma_y)/(1+gamma_a)-1)^2/2);
G_ss = g_ss*Y_ss;
w_ss = (1-eta)*(1-alpha)*MC_ss*(Y_ss/HT_ss)^(1-kappa)*HT_ss;
T1_ss = G_ss*w_ss/Y_ss;
C1_ss = w_ss-T1_ss;
lambda1_ss = C1_ss^(-sigma1);
nu = lambda1_ss*w_ss;
lambdaA_ss = 0.5/4;
Z_ss = (1+gamma_a-phi)/(lambdaA_ss*phi)+1;
V_ss = (zeta_R-1)*RF_ss*ROBF_ss/((1-phi*LAMBDA_ss*(1+gamma_y)/(1+gamma_a))*zeta_R);
J_ss = phi*LAMBDA_ss*(1+gamma_y)/(1+gamma_a)*(1-rho_lambda)*lambdaA_ss*V_ss/(1+phi*LAMBDA_ss*(1+gamma_y)/(1+gamma_a)*(lambdaA_ss-rho_lambda*lambdaA_ss-1));
wsLsa = lambdaA_ss*rho_lambda*phi*LAMBDA_ss*(1+gamma_y)/(1+gamma_a)*(V_ss-J_ss);
wsLsr = LAMBDA_ss*(1+gamma_y)/(1+gamma_a)*J_ss*Z_ss*(1+gamma_a-phi);
ws_ss = (Z_ss-1)*wsLsa+wsLsr;
Lsa_ss = wsLsa/ws_ss;
Lsr_ss = wsLsr/ws_ss;
T2_ss = G_ss*ws_ss/Y_ss;
C2_ss = ws_ss-T2_ss;
lambda2_ss = C2_ss^(-sigma2);
nu_S = lambda2_ss*ws_ss;
kappa_lambda = lambdaA_ss/(Z_ss*Lsa_ss)^rho_lambda;
chiZ_ss = (1+gamma_a-phi)/(Z_ss^(-rho_zz)*Lsr_ss^rho_L);


Y(i) = Y_ss;
ROB(i) = ROBF_ss;
income1(i) = w_ss;
income2(i) = ws_ss;
income3(i) = Y_ss-C1_ss-C2_ss-G_ss;
INDX(i) = income3(i)-income1(i);
wu(i) = w_ss;
ws(i) = ws_ss;
ROB_Y(i) = RR_ss*ROBF_ss/(MC_ss*Y_ss);
wu_Y(i) = income1(i)/Y(i);
ws_Y(i) = income2(i)/Y(i);
we_Y(i) = income3(i)/Y(i);

i = 1+i;
end

%% 画图（拓展 A：六个关键变量，2x3 面板）
figure;
subplot(2,3,1)
plot(xx, income1, '-k', 'LineWidth', 1.3);
xlabel('\alpha'); title('低技能家庭实际收入', 'Fontsize', 12);

subplot(2,3,2)
plot(xx, income2, '-k', 'LineWidth', 1.3);
xlabel('\alpha'); title('高技能家庭实际收入', 'Fontsize', 12);

subplot(2,3,3)
plot(xx, income3, '-k', 'LineWidth', 1.3);
xlabel('\alpha'); title('资本型家庭实际收入', 'Fontsize', 12);

subplot(2,3,4)
plot(xx, wu_Y, '-k', 'LineWidth', 1.3);
xlabel('\alpha'); title('低技能收入份额', 'Fontsize', 12);

subplot(2,3,5)
plot(xx, ws_Y, '-k', 'LineWidth', 1.3);
xlabel('\alpha'); title('高技能收入份额', 'Fontsize', 12);

subplot(2,3,6)
plot(xx, we_Y, '-k', 'LineWidth', 1.3);
xlabel('\alpha'); title('资本型收入份额', 'Fontsize', 12);
