"""将附录 A / 附录 B 的两张拓展表格渲染为 PNG（三线表），并与主报告表编号对齐。

注意：本脚本只做“呈现层（presentation layer）”渲染，不改变任何模型/数据。
表格数据读取自 output/tables 下已导出的 CSV（真实复现输出）。

输出（与主报告表编号一致）：
  output/figures/reproduced/table_A-1_拓展A_α敏感性稳态摘要.png
  output/figures/reproduced/table_A-2_拓展B_四种政策冲击响应.png
"""

import csv
import os

import matplotlib as mpl
import matplotlib.pyplot as plt

mpl.rcParams["font.family"] = "Noto Serif CJK SC"
mpl.rcParams["axes.unicode_minus"] = False

BASE = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
out_dir = os.path.join(BASE, "output", "figures", "reproduced")
tab_dir = os.path.join(BASE, "output", "tables")
os.makedirs(out_dir, exist_ok=True)


def three_line_table(fig_path, title, columns, cell_text, col_widths):
    fig, ax = plt.subplots(
        figsize=(sum(col_widths) / 96 * 1.2, (len(cell_text) + 2) * 0.42),
        dpi=200,
    )
    ax.axis("off")
    ax.set_title(title, fontsize=14, fontweight="bold", pad=14)

    tbl = ax.table(
        cellText=cell_text,
        colLabels=columns,
        cellLoc="center",
        colLoc="center",
        loc="center",
        colWidths=[w / sum(col_widths) for w in col_widths],
    )
    tbl.auto_set_font_size(False)
    tbl.set_fontsize(11)
    tbl.scale(1, 1.6)

    n_rows = len(cell_text) + 1
    n_cols = len(columns)
    for (r, c), cell in tbl.get_celld().items():
        cell.set_linewidth(0)
        cell.set_edgecolor("none")

    for c in range(n_cols):
        cell = tbl[(0, c)]
        cell.visible_edges = "TB"
        cell.set_linewidth(1.4)
        cell.set_edgecolor("black")
        cell.set_text_props(fontweight="bold")

    for c in range(n_cols):
        cell = tbl[(n_rows - 1, c)]
        cell.visible_edges = "B"
        cell.set_linewidth(1.4)
        cell.set_edgecolor("black")

    plt.savefig(fig_path, bbox_inches="tight", dpi=200, facecolor="white")
    plt.close(fig)
    print("saved", fig_path)


def fmt(x, k=4):
    return f"{x:.{k}f}"


# --------- 表 A-1：拓展 A：α 网格稳态数值摘要 ----------
with open(os.path.join(tab_dir, "ext_alpha_wide_summary.csv"), "r", encoding="utf-8-sig") as f:
    rows = list(csv.DictReader(f))

alpha_title = "表 A-1  拓展 A：α ∈ {0.15, 0.25, 0.35, 0.50, 0.65, 0.75} 处的稳态数值摘要"
alpha_cols = [
    "α",
    "低技能实际收入",
    "高技能实际收入",
    "资本型实际收入",
    "低技能份额",
    "高技能份额",
    "资本型份额",
]

alpha_body = []
for r in rows:
    alpha_body.append(
        [
            fmt(float(r["alpha"]), 2),
            fmt(float(r["income_low_skill"]), 4),
            fmt(float(r["income_high_skill"]), 4),
            fmt(float(r["income_capital"]), 4),
            fmt(float(r["share_low_skill"]), 4),
            fmt(float(r["share_high_skill"]), 4),
            fmt(float(r["share_capital"]), 4),
        ]
    )

three_line_table(
    os.path.join(out_dir, "table_A-1_拓展A_α敏感性稳态摘要.png"),
    alpha_title,
    alpha_cols,
    alpha_body,
    col_widths=[70, 165, 165, 165, 135, 135, 135],
)


# --------- 表 A-2：拓展 B：四政策 t=0 冲击响应 ----------
with open(os.path.join(tab_dir, "ext_policy_mix_summary.csv"), "r", encoding="utf-8-sig") as f:
    prows = list(csv.DictReader(f))

policy_labels = {
    "transfer": "一次性转移支付",
    "labor_subsidy": "劳动补贴",
    "consumption_subsidy": "消费补贴",
    "mix_transfer_labor_50_50": "组合政策（转移支付 + 劳动补贴 50/50）",
}

policy_title = "表 A-2  拓展 B：四种政策下三个关键变量的 t=0 冲击响应"
policy_cols = [
    "政策工具",
    "低技能家庭实际收入 IRF (t=0)",
    "经济总产出 IRF (t=0)",
    "收入差距指数 IRF (t=0)",
]

policy_body = []
for r in prows:
    policy_body.append(
        [
            policy_labels[r["policy"]],
            fmt(float(r["C1_t0"]), 6),
            fmt(float(r["Y_t0"]), 6),
            fmt(float(r["INDX_t0"]), 6),
        ]
    )

three_line_table(
    os.path.join(out_dir, "table_A-2_拓展B_四种政策冲击响应.png"),
    policy_title,
    policy_cols,
    policy_body,
    col_widths=[360, 220, 200, 220],
)
