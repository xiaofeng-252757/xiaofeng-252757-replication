"""Regenerate the two extension figures (line plots) via matplotlib
so that Chinese labels render correctly.
Uses the .mat files saved by the Octave batch scripts.
"""

import os
import numpy as np
import scipy.io as sio
import matplotlib.pyplot as plt
import matplotlib as mpl

mpl.rcParams["font.family"] = "Noto Serif CJK SC"
mpl.rcParams["axes.unicode_minus"] = False

BASE = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
data_dir = os.path.join(BASE, "output", "data")
fig_dir = os.path.join(BASE, "output", "figures")

# ============ Extension A: wide alpha scan ============
mat = sio.loadmat(os.path.join(data_dir, "ext_alpha_wide.mat"))
xx = mat["xx"].flatten()
income1 = mat["income1"].flatten()
income2 = mat["income2"].flatten()
income3 = mat["income3"].flatten()
wu_Y = mat["wu_Y"].flatten()
ws_Y = mat["ws_Y"].flatten()
we_Y = mat["we_Y"].flatten()

fig, axes = plt.subplots(2, 3, figsize=(12.5, 6.8), dpi=140)
panels = [
    (income1, "低技能家庭实际收入"),
    (income2, "高技能家庭实际收入"),
    (income3, "资本型家庭实际收入"),
    (wu_Y, "低技能收入份额"),
    (ws_Y, "高技能收入份额"),
    (we_Y, "资本型收入份额"),
]
for ax, (y, ttl) in zip(axes.flat, panels):
    ax.plot(xx, y, "-k", linewidth=1.3)
    ax.set_xlabel(r"$\alpha$")
    ax.set_title(ttl, fontsize=12)
    ax.grid(True, alpha=0.25, linestyle=":")
    ax.axvline(0.25, color="0.6", linestyle=":", linewidth=0.9)
    ax.axvline(0.50, color="0.6", linestyle=":", linewidth=0.9)

plt.tight_layout()
plt.savefig(os.path.join(fig_dir, "ext_alpha_wide.png"),
            bbox_inches="tight", facecolor="white")
plt.close(fig)
print("saved ext_alpha_wide.png")

# ============ Extension B: policy mix ============
mat = sio.loadmat(os.path.join(data_dir, "ext_policy_mix.mat"))
T = mat["T"].flatten()
c1e = mat["C1_ee_xi_e"].flatten()
c1l = mat["C1_ee_xi_l"].flatten()
c1c = mat["C1_ee_xi_c"].flatten()
c1m = mat["C1_mix"].flatten()
ye = mat["Y_ee_xi_e"].flatten()
yl = mat["Y_ee_xi_l"].flatten()
yc = mat["Y_ee_xi_c"].flatten()
ym = mat["Y_mix"].flatten()
ie = mat["INDX_ee_xi_e"].flatten()
il = mat["INDX_ee_xi_l"].flatten()
ic = mat["INDX_ee_xi_c"].flatten()
im = mat["INDX_mix"].flatten()

fig, axes = plt.subplots(3, 1, figsize=(10.5, 9.5), dpi=140)

def _panel(ax, data_set, ttl):
    ax.axhline(0, color="0.65", linewidth=0.9)
    for y, style, lbl in data_set:
        ax.plot(T, y, style, linewidth=1.5, label=lbl)
    ax.set_title(ttl, fontsize=12)
    ax.set_xlabel("季度")
    ax.grid(True, alpha=0.25, linestyle=":")

_panel(axes[0], [
    (c1e, "--k", "一次性转移支付"),
    (c1l, "-k",  "劳动补贴"),
    (c1c, "-.k", "消费补贴"),
    (c1m, ":",   "组合政策 (转移支付 + 劳动补贴 50/50)"),
], "低技能家庭实际收入 IRF")
axes[0].lines[-1].set_color("C3")
axes[0].lines[-1].set_linewidth(1.9)
axes[0].legend(loc="lower right", fontsize=10, ncol=2)

_panel(axes[1], [
    (ye, "--k", "一次性转移支付"),
    (yl, "-k",  "劳动补贴"),
    (yc, "-.k", "消费补贴"),
    (ym, ":",   "组合政策 (转移支付 + 劳动补贴 50/50)"),
], "经济总产出 IRF")
axes[1].lines[-1].set_color("C3")
axes[1].lines[-1].set_linewidth(1.9)

_panel(axes[2], [
    (ie, "--k", "一次性转移支付"),
    (il, "-k",  "劳动补贴"),
    (ic, "-.k", "消费补贴"),
    (im, ":",   "组合政策 (转移支付 + 劳动补贴 50/50)"),
], "收入差距指数 IRF")
axes[2].lines[-1].set_color("C3")
axes[2].lines[-1].set_linewidth(1.9)

plt.tight_layout()
plt.savefig(os.path.join(fig_dir, "ext_policy_mix.png"),
            bbox_inches="tight", facecolor="white")
plt.close(fig)
print("saved ext_policy_mix.png")
