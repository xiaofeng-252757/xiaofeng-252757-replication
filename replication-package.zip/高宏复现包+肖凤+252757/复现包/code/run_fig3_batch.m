% 批处理：兼容 Octave 的图3运行脚本
% 原作者 fig_3.m 在 Octave 下连续调用 dynare 时会清空前次变量，
% 因此这里采用 noclearall 方式重写一个兼容版本。
1;

code_dir = fileparts(mfilename('fullpath'));
root_dir = fileparts(code_dir);
orig_dir = fullfile(code_dir, 'original');
out_fig_dir = fullfile(root_dir, 'output', 'figures');
out_data_dir = fullfile(root_dir, 'output', 'data');
out_log_dir = fullfile(root_dir, 'output', 'logs');

% Dynare should be available in Octave/MATLAB path.
% (Course requirement: avoid absolute paths; please configure Dynare in your environment.)
if exist('dynare', 'file') ~= 2
    error('Dynare not found in path. Please install Dynare and add it to Octave path before running.');
end

graphics_toolkit('gnuplot');
set(0, 'defaultfigurevisible', 'off');
addpath(orig_dir);

old_dir = pwd();
cleanup = onCleanup(@() cd(old_dir));
cd(orig_dir);

robot_c_ss;
robot_e_ss;
robot_l_ss;

code_dir = fileparts(mfilename('fullpath'));
root_dir = fileparts(code_dir);
orig_dir = fullfile(code_dir, 'original');
out_fig_dir = fullfile(root_dir, 'output', 'figures');
out_data_dir = fullfile(root_dir, 'output', 'data');
out_log_dir = fullfile(root_dir, 'output', 'logs');
cd(orig_dir);
if exist(fullfile(root_dir, 'var_c_ss'), 'file')
    copyfile(fullfile(root_dir, 'var_c_ss'), fullfile(orig_dir, 'var_c_ss'));
end
if exist(fullfile(root_dir, 'var_e_ss'), 'file')
    copyfile(fullfile(root_dir, 'var_e_ss'), fullfile(orig_dir, 'var_e_ss'));
end
if exist(fullfile(root_dir, 'var_l_ss'), 'file')
    copyfile(fullfile(root_dir, 'var_l_ss'), fullfile(orig_dir, 'var_l_ss'));
end
dynare robot_tau_c noclearall;
dynare robot_tau_e noclearall;
dynare robot_tau_l noclearall;

code_dir = fileparts(mfilename('fullpath'));
root_dir = fileparts(code_dir);
orig_dir = fullfile(code_dir, 'original');
out_fig_dir = fullfile(root_dir, 'output', 'figures');
out_data_dir = fullfile(root_dir, 'output', 'data');
out_log_dir = fullfile(root_dir, 'output', 'logs');

figure;
T = 0:1:20;
x = zeros(21,1);

subplot(3,3,1);
plot(T,L_ee_xi_e,'--k',T,L_ee_xi_l,'-k',T,L_ee_xi_c,'-.k',T,x,'--k','LineWidth',1.3);
title('低技能劳动','Fontsize',13);

subplot(3,3,2);
plot(T,w_ee_xi_e,'--k',T,w_ee_xi_l,'-k',T,w_ee_xi_c,'-.k',T,x,'--k','LineWidth',1.3);
title('低技能工资','Fontsize',13);

subplot(3,3,3);
plot(T,lambda1_ee_xi_e,'--k',T,lambda1_ee_xi_l,'-k',T,lambda1_ee_xi_c,'-.k',T,x,'--k','LineWidth',1.3);
title('低技能家庭边际效用','Fontsize',13);

subplot(3,3,4);
plot(T,C1_ee_xi_e,'--k',T,C1_ee_xi_l,'-k',T,C1_ee_xi_c,'-.k',T,x,'--k','LineWidth',1.3);
title('低技能家庭实际收入','Fontsize',13);

subplot(3,3,5);
plot(T,income3_ee_xi_e,'--k',T,income3_ee_xi_l,'-k',T,income3_ee_xi_c,'-.k',T,x,'--k','LineWidth',1.3);
title('资本型家庭实际收入','Fontsize',13);

subplot(3,3,6);
plot(T,INDX_ee_xi_e,'--k',T,INDX_ee_xi_l,'-k',T,INDX_ee_xi_c,'-.k',T,x,'--k','LineWidth',1.3);
title('收入差距','Fontsize',13);

subplot(3,3,7);
plot(T,MC_ee_xi_e,'--k',T,MC_ee_xi_l,'-k',T,MC_ee_xi_c,'-.k',T,x,'--k','LineWidth',1.3);
title('中间品价格','Fontsize',13);

subplot(3,3,8);
plot(T,Y_ee_xi_e,'--k',T,Y_ee_xi_l,'-k',T,Y_ee_xi_c,'-.k',T,x,'--k','LineWidth',1.3);
title('经济总产出','Fontsize',13);

legend('情形1：一次性转移支付','情形2：劳动补贴','情形3：消费补贴');
print(gcf, fullfile(out_fig_dir, 'fig3_reproduced.png'), '-dpng');
save(fullfile(out_data_dir, 'fig3_workspace.mat'), ...
    'L_ee_xi_e', 'L_ee_xi_l', 'L_ee_xi_c', ...
    'w_ee_xi_e', 'w_ee_xi_l', 'w_ee_xi_c', ...
    'lambda1_ee_xi_e', 'lambda1_ee_xi_l', 'lambda1_ee_xi_c', ...
    'C1_ee_xi_e', 'C1_ee_xi_l', 'C1_ee_xi_c', ...
    'income3_ee_xi_e', 'income3_ee_xi_l', 'income3_ee_xi_c', ...
    'INDX_ee_xi_e', 'INDX_ee_xi_l', 'INDX_ee_xi_c', ...
    'MC_ee_xi_e', 'MC_ee_xi_l', 'MC_ee_xi_c', ...
    'Y_ee_xi_e', 'Y_ee_xi_l', 'Y_ee_xi_c');

if exist(fullfile(orig_dir, 'robot_tau_c.log'), 'file')
    copyfile(fullfile(orig_dir, 'robot_tau_c.log'), fullfile(out_log_dir, 'robot_tau_c.log'));
end
if exist(fullfile(orig_dir, 'robot_tau_e.log'), 'file')
    copyfile(fullfile(orig_dir, 'robot_tau_e.log'), fullfile(out_log_dir, 'robot_tau_e.log'));
end
if exist(fullfile(orig_dir, 'robot_tau_l.log'), 'file')
    copyfile(fullfile(orig_dir, 'robot_tau_l.log'), fullfile(out_log_dir, 'robot_tau_l.log'));
end

fprintf('Figure 3 finished successfully.\n');
