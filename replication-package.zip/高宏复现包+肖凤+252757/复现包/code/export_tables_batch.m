% 批处理：导出表1、表2及关键动态结果为 CSV
1;

code_dir = fileparts(mfilename('fullpath'));
root_dir = fileparts(code_dir);
out_data_dir = fullfile(root_dir, 'output', 'data');
out_table_dir = fullfile(root_dir, 'output', 'tables');

function write_text(path, content)
  fid = fopen(path, 'w');
  if fid < 0
    error('Cannot open file: %s', path);
  end
  fputs(fid, content);
  fclose(fid);
end

% ---------- 表1：模型稳态值与样本经验值比较 ----------
load(fullfile(out_data_dir, 'robot_f_results.mat'));
endo_names = cellstr(M_.endo_names);

idxY = find(strcmp(endo_names, 'Y'));
idxC1 = find(strcmp(endo_names, 'C1'));
idxC2 = find(strcmp(endo_names, 'C2'));
idxC3 = find(strcmp(endo_names, 'C3'));
idxI = find(strcmp(endo_names, 'I'));
idxIR = find(strcmp(endo_names, 'I_R_A'));
idxg = find(strcmp(endo_names, 'g'));
idxA = find(strcmp(endo_names, 'A'));
idxZ = find(strcmp(endo_names, 'Z'));
idxWs = find(strcmp(endo_names, 'w_S'));
idxLs = find(strcmp(endo_names, 'L_S'));
idxRF = find(strcmp(endo_names, 'R_F'));
idxRobf = find(strcmp(endo_names, 'ROB_F'));
idxRK = find(strcmp(endo_names, 'R_K'));

Y = exp(oo_.steady_state(idxY));
C1 = exp(oo_.steady_state(idxC1));
C2 = exp(oo_.steady_state(idxC2));
C3 = exp(oo_.steady_state(idxC3));
I = exp(oo_.steady_state(idxI));
IR = exp(oo_.steady_state(idxIR));
g_ratio = exp(oo_.steady_state(idxg)) * 100;
A_div_Z = exp(oo_.steady_state(idxA)) / exp(oo_.steady_state(idxZ)) * 100;
wsLs_y = exp(oo_.steady_state(idxWs)) * exp(oo_.steady_state(idxLs)) / Y * 100;
rfrobf_y = exp(oo_.steady_state(idxRF)) * exp(oo_.steady_state(idxRobf)) / Y * 100;
rk = exp(oo_.steady_state(idxRK)) * 100;
cons_y = (C1 + C2 + C3) / Y * 100;
inv_y = (I + IR) / Y * 100;

paper_sample = [38.19, 43.43, 16.33, 81.01, 2.52, 23.00, 2.85];
paper_model = [36.53, 45.47, 18.00, 64.59, 2.88, 21.93, 5.18];
reproduced = [cons_y, inv_y, g_ratio, A_div_Z, wsLs_y, rfrobf_y, rk];
labels = {'消费产出比','投资产出比','政府支出产出比','技术推广比(A/Z)','研发支出产出比','机器人最终品份额','传统资本回报率'};

content = sprintf('指标,论文样本近似值(%%),论文模型值(%%),复现值(%%),复现-论文模型绝对差\n');
for i = 1:length(labels)
  content = [content, sprintf('%s,%.2f,%.2f,%.2f,%.4f\n', labels{i}, paper_sample(i), paper_model(i), reproduced(i), abs(reproduced(i)-paper_model(i)))];
end
write_text(fullfile(out_table_dir, 'table1_model_fit.csv'), content);

% ---------- 表2：长期稳态结果 ----------
load(fullfile(out_data_dir, 'fig2_workspace.mat'));
rep_a025 = [income1(1), income2(1), income3(1), wu_Y(1), ws_Y(1), we_Y(1)];
rep_a05 = [income1(end), income2(end), income3(end), wu_Y(end), ws_Y(end), we_Y(end)];
rep_change = (rep_a05 ./ rep_a025 - 1) * 100;

paper_a025 = [1.9171, 0.2073, 4.1697, 0.2659, 0.0288, 0.5784];
paper_a05 = [1.0066, 2.0064, 20.2093, 0.0364, 0.0725, 0.7307];
paper_change = [-47.49, 867.87, 384.67, -86.31, 151.74, 26.33];
labels2 = {'低技能工薪家庭实际收入','高技能工薪家庭实际收入','资本型家庭实际收入','低技能收入占产出比重','高技能收入占产出比重','资本型收入占产出比重'};

content2 = '变量,论文α=0.25,复现α=0.25,论文α=0.5,复现α=0.5,论文变化幅度(%),复现变化幅度(%),变化幅度绝对差\n';
for i = 1:length(labels2)
  content2 = [content2, sprintf('%s,%.4f,%.4f,%.4f,%.4f,%.2f,%.2f,%.4f\n', labels2{i}, paper_a025(i), rep_a025(i), paper_a05(i), rep_a05(i), paper_change(i), rep_change(i), abs(rep_change(i)-paper_change(i)))];
end
write_text(fullfile(out_table_dir, 'table2_steady_state.csv'), content2);

% ---------- 图1初始冲击响应摘要 ----------
load(fullfile(out_data_dir, 'fig1_workspace.mat'));
content3 = ['变量,t=0响应\n', ...
    sprintf('经济总产出,%.6f\n', Y_ee_xi(1)), ...
    sprintf('机器人技术创新,%.6f\n', A_ee_xi(1)), ...
    sprintf('低技能劳动,%.6f\n', L_ee_xi(1)), ...
    sprintf('低技能实际工资,%.6f\n', w_ee_xi(1)), ...
    sprintf('低技能家庭实际收入,%.6f\n', C1_ee_xi(1)), ...
    sprintf('收入差距指数,%.6f\n', INDX_ee_xi(1))];
write_text(fullfile(out_table_dir, 'figure1_initial_response.csv'), content3);

% ---------- 图3政策比较初始响应 ----------
load(fullfile(out_data_dir, 'fig3_workspace.mat'));
content4 = ['指标,一次性转移支付,劳动补贴,消费补贴\n', ...
    sprintf('低技能家庭实际收入t=0,%.6f,%.6f,%.6f\n', C1_ee_xi_e(1), C1_ee_xi_l(1), C1_ee_xi_c(1)), ...
    sprintf('经济总产出t=0,%.6f,%.6f,%.6f\n', Y_ee_xi_e(1), Y_ee_xi_l(1), Y_ee_xi_c(1)), ...
    sprintf('收入差距指数t=0,%.6f,%.6f,%.6f\n', INDX_ee_xi_e(1), INDX_ee_xi_l(1), INDX_ee_xi_c(1))];
write_text(fullfile(out_table_dir, 'figure3_policy_initial_response.csv'), content4);

fprintf('All tables exported successfully.\n');