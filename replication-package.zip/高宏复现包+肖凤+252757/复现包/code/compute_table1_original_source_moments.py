#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Backward-compatible wrapper for the Table 1 provenance audit.

The earlier file name is kept so old instructions do not break, but the actual
logic now lives in audit_table1_provenance.py. The output explicitly separates
exact, alternative-source and secondary-source evidence instead of claiming that
all empirical moments are original-source exact replications.
"""
from pathlib import Path
import runpy

ROOT = Path(__file__).resolve().parents[1]
runpy.run_path(str(ROOT / "code" / "audit_table1_provenance.py"), run_name="__main__")
