% ============================================================
% [ORIGINAL — DO NOT EDIT]
% Source : 齐亚东、于泽、朱军 (2026).《工业智能化与收入分配格局演变：
%          经济发展机遇背后的分配失衡隐忧》公开复现附件（Dynare/Matlab）.
% Role   : 作者原始程序，本文严格沿用，未改动模型设定、参数口径、实验目标.
% Note   : 本文件属"原始作者程序"，仅用于 DSGE 核心复现；任何修改都必须
%          放到 optional_supplementary_code/ 下，本文件保持与作者版本一致.
% ============================================================

clc
clear

%% 参数赋值
sigma1 = 0.8;
sigma2 = 0.8;
sigma3 = 0.8;
mu = 1.2;
alpha = 0.25;
eta = 0.5;
theta = 0.7;
beta = 0.995;
delta = 0.025;
delta_R = 0.05;
OMEGA_K = 4;
OMEGA_R = 2;
g_ss = 0.18;
phi = 0.967;
rho_lambda = 0.925;
rho_L = 0.37;
rho_z = 0.3;
theta_A = 1.35;
kappa = 0.95;


%% 趋势计算
gamma_y = 0.02708;
gamma_lambdau = (1+gamma_y)^(-sigma1)-1;
gamma_a = (1+gamma_y)^((1-theta)/(theta*(theta_A-1)))-1;
gamma_rob = (1+gamma_y)^(1/theta)-1;


%% 稳态求解
MC_ss = 1/mu;
LAMBDA_ss = beta*(1+gamma_lambdau);
R_ss = 1/(beta*(1+gamma_lambdau));
qk_ss = 1/(1-OMEGA_K*gamma_y^2/2-OMEGA_K*gamma_y*(1+gamma_y)+LAMBDA_ss*OMEGA_K*gamma_y*(1+gamma_y)^2);
qR_ss = 1/(  1-OMEGA_R*((1+gamma_y)/(1+gamma_a)-1)^2/2 -OMEGA_R*((1+gamma_y)/(1+gamma_a)-1)*(1+gamma_y)/(1+gamma_a)+...
        LAMBDA_ss*(1+gamma_a)*OMEGA_R*((1+gamma_y)/(1+gamma_a)-1)*((1+gamma_y)/(1+gamma_a))^2  );
RK_ss = qk_ss/LAMBDA_ss-(1-delta)*qk_ss;
K_ss =38.001; % 遍历资本的稳态值，得到使zeta_M取值为参数校准值的资本稳态
HT_ss =(K_ss/(1+gamma_y)) ^eta;
Y_ss = (RK_ss*K_ss/(eta*(1-alpha)*MC_ss*(1+gamma_y)*HT_ss))^(1/(1-kappa))*HT_ss;
HR_ss = ((Y_ss^kappa-(1-alpha)*HT_ss^kappa)/alpha)^(1/kappa);
ROBF_ss = HR_ss^(1/theta)*(1+gamma_rob);
RF_ss = alpha*theta*MC_ss*(Y_ss/HR_ss)^(1-kappa)*HR_ss/(ROBF_ss/(1+gamma_rob));
rob_ss = ROBF_ss;
RR_ss = RF_ss;
zeta_R = RR_ss/(qR_ss/LAMBDA_ss-(1-delta_R)*(1+gamma_a)*qR_ss);
I_ss = (1-(1-delta)/(1+gamma_y))*K_ss/(1-OMEGA_K*gamma_y^2/2);
IR_ss = (1-(1-delta_R)*(1+gamma_a)/(1+gamma_y))*ROBF_ss/(1-OMEGA_R*((1+gamma_y)/(1+gamma_a)-1)^2/2);
G_ss = g_ss*Y_ss;
w_ss = (1-eta)*(1-alpha)*MC_ss*(Y_ss/HT_ss)^(1-kappa)*HT_ss;
T1_ss = G_ss*w_ss/Y_ss;
tau_e_ss = 0.5*T1_ss;
C1_ss = w_ss-T1_ss+tau_e_ss;
tau_c_ss = tau_e_ss/C1_ss;
lambda1_ss = C1_ss^(-sigma1)/(1-tau_c_ss);
nu = lambda1_ss*w_ss;
lambdaA_ss = 0.5/4;
Z_ss = (1+gamma_a-phi)/(lambdaA_ss*phi)+1;
V_ss = (zeta_R-1)*RF_ss*ROBF_ss/((1-phi*LAMBDA_ss*(1+gamma_y)/(1+gamma_a))*zeta_R);
J_ss = phi*LAMBDA_ss*(1+gamma_y)/(1+gamma_a)*(1-rho_lambda)*lambdaA_ss*V_ss/(1+phi*LAMBDA_ss*(1+gamma_y)/(1+gamma_a)*(lambdaA_ss-rho_lambda*lambdaA_ss-1));
wsLsa = lambdaA_ss*rho_lambda*phi*LAMBDA_ss*(1+gamma_y)/(1+gamma_a)*(V_ss-J_ss);
wsLsr = LAMBDA_ss*(1+gamma_y)/(1+gamma_a)*J_ss*Z_ss*(1+gamma_a-phi);
ws_ss = (Z_ss-1)*wsLsa+wsLsr;
Lsa_ss = wsLsa/ws_ss;
Lsr_ss = wsLsr/ws_ss;
T2_ss = G_ss*ws_ss/Y_ss;
C2_ss = ws_ss-T2_ss;
lambda2_ss = C2_ss^(-sigma2);
nu_S = lambda2_ss*ws_ss;
kappa_lambda_ss = lambdaA_ss/(Z_ss*Lsa_ss)^rho_lambda;
chiZ_ss = (1+gamma_a-phi)/(Z_ss^(-rho_z)*Lsr_ss^rho_L);


%% 保存结果
save var_c_ss w_ss ws_ss Lsr_ss Lsa_ss qk_ss qR_ss RK_ss RR_ss...
     K_ss I_ss IR_ss Y_ss HR_ss HT_ss C1_ss C2_ss IR_ss G_ss...
     T1_ss T2_ss lambda1_ss lambda2_ss R_ss LAMBDA_ss MC_ss ...
     V_ss J_ss Z_ss lambdaA_ss g_ss chiZ_ss nu nu_S zeta_R rob_ss tau_e_ss;
     

 