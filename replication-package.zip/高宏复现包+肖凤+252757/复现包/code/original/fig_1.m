% ============================================================
% [ORIGINAL — DO NOT EDIT]
% Source : 齐亚东、于泽、朱军 (2026).《工业智能化与收入分配格局演变：
%          经济发展机遇背后的分配失衡隐忧》公开复现附件（Dynare/Matlab）.
% Role   : 作者原始程序，本文严格沿用，未改动模型设定、参数口径、实验目标.
% Note   : 本文件属"原始作者程序"，仅用于 DSGE 核心复现；任何修改都必须
%          放到 optional_supplementary_code/ 下，本文件保持与作者版本一致.
% ============================================================

%% 模型运行
clc
clear
close all
robot_f_ss
dynare robot_f

%% 画图
figure;
T = 0:1:20;
x = zeros(21,1);

subplot(4,4,1);
plot(T,Y_ee_xi,'-k',T,x,'--k','LineWidth',1.3);
title('经济总产出','Fontsize',13);

subplot(4,4,2);
plot(T,A_ee_xi,'-k',T,x,'--k','LineWidth',1.3);
title('机器人技术创新','Fontsize',13);

subplot(4,4,3);
plot(T,ROB_F_ee_xi,'-k',T,x,'--k','LineWidth',1.3);
title('机器人规模','Fontsize',13);

subplot(4,4,4);
plot(T,R_F_ee_xi,'-k',T,x,'--k','LineWidth',1.3);
title('机器人回报','Fontsize',13);

subplot(4,4,5);
plot(T,K_ee_xi,'-k',T,x,'--k','LineWidth',1.3);
title('传统资本','Fontsize',13);

subplot(4,4,6);
plot(T,R_K_ee_xi,'-k',T,x,'--k','LineWidth',1.3);
title('传统资本回报','Fontsize',13);


subplot(4,4,7);
plot(T,L_ee_xi,'-k',T,x,'--k','LineWidth',1.3);
title('低技能劳动','Fontsize',13);

subplot(4,4,8);
plot(T,w_ee_xi,'-k',T,x,'--k','LineWidth',1.3);
title('低技能实际工资','Fontsize',13);

subplot(4,4,9);
plot(T,L_S_ee_xi,'-k',T,x,'--k','LineWidth',1.3);
title('高技能劳动','Fontsize',13);

subplot(4,4,10);
plot(T,w_S_ee_xi,'-k',T,x,'--k','LineWidth',1.3);
title('高技能实际工资','Fontsize',13);

subplot(4,4,11);
plot(T,fe_u_ee_xi,'-k',T,x,'--k','LineWidth',1.3);
title('低技能收入份额','Fontsize',13);

subplot(4,4,12);
plot(T,fe_M_ee_xi,'-k',T,x,'--k','LineWidth',1.3);
title('机器人收入份额','Fontsize',13);

subplot(4,4,13);
plot(T,C1_ee_xi,'-k',T,x,'--k','LineWidth',1.3);
title('低技能家庭实际收入','Fontsize',13);

subplot(4,4,14);
plot(T,C2_ee_xi,'-k',T,x,'--k','LineWidth',1.3);
title('高技能家庭实际收入','Fontsize',13);

subplot(4,4,15);
plot(T,income3_ee_xi,'-k',T,x,'--k','LineWidth',1.3);
title('资本型家庭实际收入','Fontsize',13);

subplot(4,4,16);
plot(T,INDX_ee_xi,'-k',T,x,'--k','LineWidth',1.3);
title('收入差距指数','Fontsize',13);
