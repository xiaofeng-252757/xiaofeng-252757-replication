function T = static_g1_tt(T, y, x, params)
% function T = static_g1_tt(T, y, x, params)
%
% File created by Dynare Preprocessor from .mod file
%
% Inputs:
%   T         [#temp variables by 1]  double   vector of temporary terms to be filled by function
%   y         [M_.endo_nbr by 1]      double   vector of endogenous variables in declaration order
%   x         [M_.exo_nbr by 1]       double   vector of exogenous variables in declaration order
%   params    [M_.param_nbr by 1]     double   vector of parameter values in declaration order
%
% Output:
%   T         [#temp variables by 1]  double   vector of temporary terms
%

assert(length(T) >= 81);

T = robot_tau_l.static_resid_tt(T, y, x, params);

T(64) = T(30)*exp(y(2))*getPowerDeriv(exp(y(2)),1-params(7),1);
T(65) = getPowerDeriv(T(32),params(18),1);
T(66) = getPowerDeriv(T(33),1/params(18),1);
T(67) = exp(y(5))*getPowerDeriv(exp(y(5)),params(16)-1,1);
T(68) = exp(y(37))*y(46)*params(15)*exp(y(37))*exp(y(6))*getPowerDeriv(exp(y(37))*exp(y(6)),params(15)-1,1);
T(69) = (-(y(46)*exp(y(37))*exp(y(6))*getPowerDeriv(exp(y(37))*exp(y(6)),params(15),1)));
T(70) = T(31)*exp(y(41))*T(29)*getPowerDeriv(T(29),params(7),1);
T(71) = T(25)*getPowerDeriv(T(25),params(8),1);
T(72) = getPowerDeriv(exp(y(43))*T(28)*exp(y(42)),params(18),1);
T(73) = getPowerDeriv(T(2),1-params(18),1);
T(74) = getPowerDeriv(T(22),1-params(18),1);
T(75) = getPowerDeriv(T(40),1-params(72),1);
T(76) = (-(exp(y(17))*exp(y(1))*exp(y(2))))/(exp(y(17))*exp(y(17)));
T(77) = getPowerDeriv(T(48),1-params(65),1);
T(78) = T(73)*(-(exp(y(19))*exp(y(17))))/(exp(y(19))*exp(y(19)));
T(79) = exp(y(20))*getPowerDeriv(exp(y(20)),(-params(3)),1);
T(80) = exp(y(37))*getPowerDeriv(exp(y(37)),1-params(69),1);
T(81) = exp(y(40))*getPowerDeriv(exp(y(40)),params(18),1);

end
