function T = dynamic_resid_tt(T, y, x, params, steady_state, it_)
% function T = dynamic_resid_tt(T, y, x, params, steady_state, it_)
%
% File created by Dynare Preprocessor from .mod file
%
% Inputs:
%   T             [#temp variables by 1]     double  vector of temporary terms to be filled by function
%   y             [#dynamic variables by 1]  double  vector of endogenous variables in the order stored
%                                                    in M_.lead_lag_incidence; see the Manual
%   x             [nperiods by M_.exo_nbr]   double  matrix of exogenous variables (in declaration order)
%                                                    for all simulation periods
%   steady_state  [M_.endo_nbr by 1]         double  vector of steady state values
%   params        [M_.param_nbr by 1]        double  vector of parameter values in declaration order
%   it_           scalar                     double  time period for exogenous variables for which
%                                                    to evaluate the model
%
% Output:
%   T           [#temp variables by 1]       double  vector of temporary terms
%

assert(length(T) >= 72);

T(1) = exp(y(58))^params(18);
T(2) = exp(y(35))/exp(y(37));
T(3) = T(2)^(1-params(18));
T(4) = exp(y(37))*(1-params(7))*(1-params(6))*exp(y(49))*T(1)*T(3)/exp(y(20));
T(5) = exp(y(81))*exp(y(84))*exp(y(62))*(1+params(19))/(1+params(21));
T(6) = exp(y(10))^(1-params(69));
T(7) = T(5)*T(6);
T(8) = exp(y(23))^(params(16)-1);
T(9) = (exp(y(10))*exp(y(24)))^(params(15)-1);
T(10) = exp(y(10))*y(64)*params(15)*T(9);
T(11) = (1+params(19))*exp(y(81))*T(10)*params(14)/(1+params(21));
T(12) = T(11)*(exp(y(83))-exp(y(84)));
T(13) = (1+params(19))*exp(y(31))/exp(y(3));
T(14) = T(13)-1;
T(15) = 1-params(12)/2*T(14)^2;
T(16) = exp(y(25))*(T(15)-exp(y(31))*(1+params(19))*params(12)*T(14)/exp(y(3)));
T(17) = (1+params(19))*exp(y(78))/exp(y(31));
T(18) = params(12)*exp(y(48))*exp(y(74))*(T(17)-1);
T(19) = T(17)^2;
T(20) = T(18)*T(19);
T(21) = (1+params(19))/(1+params(21))*exp(y(32))/exp(y(4));
T(22) = T(21)-1;
T(23) = 1-params(13)/2*T(22)^2;
T(24) = exp(y(32))*(1+params(19))*params(13)*T(22)/(1+params(21));
T(25) = exp(y(26))*(T(23)-T(24)/exp(y(4)));
T(26) = params(13)*(1+params(21))*exp(y(48))*exp(y(47))/exp(y(7))*exp(y(75));
T(27) = (1+params(19))/(1+params(21))*exp(y(79))/exp(y(32));
T(28) = T(27)^2;
T(29) = T(26)*(T(27)-1)*T(28);
T(30) = exp(y(75))*exp(y(47))*(1+params(21))*(1-params(11))/exp(y(7));
T(31) = exp(y(37))*(1+params(19))*T(3)*T(1)*exp(y(49))*params(7)*(1-params(6))/exp(y(1));
T(32) = exp(y(35))/exp(y(36));
T(33) = T(32)^(1-params(18));
T(34) = exp(y(36))*T(1)*exp(y(49))*params(6)*params(8)*T(33);
T(35) = exp(y(5))/(1+params(22));
T(36) = exp(y(47))*exp(y(30))*exp(y(47))^(params(17)-1);
T(37) = exp(y(7))^(1-params(17))*exp(y(28));
T(38) = T(35)^params(8);
T(39) = exp(y(1))/(1+params(19));
T(40) = exp(y(59))*T(39)^params(7);
T(41) = exp(y(20))^(1-params(7));
T(42) = T(40)*T(41);
T(43) = params(6)*(exp(y(61))*T(38)*exp(y(60)))^params(18)+(1-params(6))*T(42)^params(18);
T(44) = exp(y(58))*T(43)^(1/params(18));
T(45) = (exp(y(18))/params(75))^params(72);
T(46) = exp(y(35))/params(34);
T(47) = T(46)^params(73);
T(48) = (exp(y(68))/params(76))^params(74);
T(49) = T(47)*T(48);
T(50) = T(49)^(1-params(72));
T(51) = exp(y(38))^(-params(3));
T(52) = params(9)*(1+params(20))*exp(y(63))*exp(y(80))^(-params(3));
T(53) = exp(y(19))*exp(y(20))/exp(y(35));
T(54) = exp(y(35))*exp(y(65))*T(53);
T(55) = exp(y(35))*exp(y(65))*exp(y(21))*exp(y(22))/exp(y(35));
T(56) = exp(y(50))^params(63);
T(57) = T(46)^params(64);
T(58) = T(56)*T(57)*params(45);
T(59) = T(58)^(1-params(65));
T(60) = exp(y(9))^params(65);
T(61) = (-1)/(params(1)-1);
T(62) = exp(y(8))^params(67);
T(63) = exp(y(34))*exp(y(33))*(params(61)-1)/params(61)/exp(y(7));
T(64) = (1+params(19))*exp(y(81))*params(14)/(1+params(21));
T(65) = T(64)*(exp(y(83))*exp(y(57))+exp(y(84))*(1-exp(y(57))));
T(66) = exp(y(62))*exp(y(10))^(-params(69));
T(67) = exp(y(23))^params(16);
T(68) = exp(y(10))*(params(14)+T(66)*T(67));
T(69) = params(14)/(1+params(21));
T(70) = (exp(y(10))*exp(y(24)))^params(15);
T(71) = T(53)/exp(y(49));
T(72) = exp(y(33))*exp(y(34))/exp(y(35))/exp(y(49));

end
