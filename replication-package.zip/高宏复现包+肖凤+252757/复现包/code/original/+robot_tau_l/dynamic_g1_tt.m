function T = dynamic_g1_tt(T, y, x, params, steady_state, it_)
% function T = dynamic_g1_tt(T, y, x, params, steady_state, it_)
%
% File created by Dynare Preprocessor from .mod file
%
% Inputs:
%   T             [#temp variables by 1]     double  vector of temporary terms to be filled by function
%   y             [#dynamic variables by 1]  double  vector of endogenous variables in the order stored
%                                                    in M_.lead_lag_incidence; see the Manual
%   x             [nperiods by M_.exo_nbr]   double  matrix of exogenous variables (in declaration order)
%                                                    for all simulation periods
%   steady_state  [M_.endo_nbr by 1]         double  vector of steady state values
%   params        [M_.param_nbr by 1]        double  vector of parameter values in declaration order
%   it_           scalar                     double  time period for exogenous variables for which
%                                                    to evaluate the model
%
% Output:
%   T           [#temp variables by 1]       double  vector of temporary terms
%

assert(length(T) >= 95);

T = robot_tau_l.dynamic_resid_tt(T, y, x, params, steady_state, it_);

T(73) = T(40)*exp(y(20))*getPowerDeriv(exp(y(20)),1-params(7),1);
T(74) = getPowerDeriv(T(42),params(18),1);
T(75) = getPowerDeriv(T(43),1/params(18),1);
T(76) = exp(y(23))*getPowerDeriv(exp(y(23)),params(16)-1,1);
T(77) = exp(y(10))*y(64)*params(15)*exp(y(10))*exp(y(24))*getPowerDeriv(exp(y(10))*exp(y(24)),params(15)-1,1);
T(78) = (-(y(64)*exp(y(10))*exp(y(24))*getPowerDeriv(exp(y(10))*exp(y(24)),params(15),1)));
T(79) = T(41)*exp(y(59))*T(39)*getPowerDeriv(T(39),params(7),1);
T(80) = (-((1+params(19))*exp(y(31))*exp(y(3))))/(exp(y(3))*exp(y(3)));
T(81) = (-(exp(y(31))*(1+params(19))*exp(y(78))))/(exp(y(31))*exp(y(31)));
T(82) = (-((1+params(19))/(1+params(21))*exp(y(32))*exp(y(4))))/(exp(y(4))*exp(y(4)));
T(83) = (-(exp(y(32))*(1+params(19))/(1+params(21))*exp(y(79))))/(exp(y(32))*exp(y(32)));
T(84) = T(35)*getPowerDeriv(T(35),params(8),1);
T(85) = getPowerDeriv(exp(y(61))*T(38)*exp(y(60)),params(18),1);
T(86) = getPowerDeriv(T(2),1-params(18),1);
T(87) = getPowerDeriv(T(32),1-params(18),1);
T(88) = getPowerDeriv(T(49),1-params(72),1);
T(89) = (-(exp(y(35))*exp(y(19))*exp(y(20))))/(exp(y(35))*exp(y(35)));
T(90) = getPowerDeriv(T(58),1-params(65),1);
T(91) = T(86)*(-(exp(y(35))*exp(y(37))))/(exp(y(37))*exp(y(37)));
T(92) = exp(y(38))*getPowerDeriv(exp(y(38)),(-params(3)),1);
T(93) = (-(exp(y(83))*T(64)));
T(94) = exp(y(10))*getPowerDeriv(exp(y(10)),1-params(69),1);
T(95) = exp(y(58))*getPowerDeriv(exp(y(58)),params(18),1);

end
