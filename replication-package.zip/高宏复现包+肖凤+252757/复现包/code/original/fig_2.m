% ============================================================
% [ORIGINAL — DO NOT EDIT]
% Source : 齐亚东、于泽、朱军 (2026).《工业智能化与收入分配格局演变：
%          经济发展机遇背后的分配失衡隐忧》公开复现附件（Dynare/Matlab）.
% Role   : 作者原始程序，本文严格沿用，未改动模型设定、参数口径、实验目标.
% Note   : 本文件属"原始作者程序"，仅用于 DSGE 核心复现；任何修改都必须
%          放到 optional_supplementary_code/ 下，本文件保持与作者版本一致.
% ============================================================

%% 参数赋值
clc
clear
sigma1 = 0.8;
sigma2 = 0.8;
sigma3 = 0.8;
mu = 1.2;
%alpha = 0.25;
eta = 0.5;
theta = 0.7;
beta = 0.995;
delta = 0.025;
delta_R = 0.05;
OMEGA_K = 4;
OMEGA_R = 2;
g_ss = 0.18;
phi = 0.967;
rho_lambda = 0.925;
rho_L = 0.37;
rho_zz = 0.3;
theta_A = 1.35;
kappa = 0.95;

%% 趋势计算
gamma_y = 0.02708;
gamma_lambdau = (1+gamma_y)^(-sigma1)-1;
gamma_a = (1+gamma_y)^((1-theta)/(theta*(theta_A-1)))-1;
gamma_rob = (1+gamma_y)^(1/theta)-1;

%% 长期趋势实验
xx = 0.25:0.01:0.25*2;
ht = linspace(1,2,length(xx));
Y = zeros(length(xx),1);
ROB = zeros(length(xx),1);
income1 = zeros(length(xx),1);
income2 = zeros(length(xx),1);
income3 = zeros(length(xx),1);
INDX = zeros(length(xx),1);
wu = zeros(length(xx),1);
ws = zeros(length(xx),1);
we = zeros(length(xx),1);
wu_Y = zeros(length(xx),1);
ws_Y = zeros(length(xx),1);
we_Y = zeros(length(xx),1);
ROB_Y = zeros(length(xx),1);
i = 1;


for alpha = xx
MC_ss = 1/mu;
LAMBDA_ss = beta*(1+gamma_lambdau);
R_ss = 1/(beta*(1+gamma_lambdau));
qk_ss = 1/(1-OMEGA_K*gamma_y^2/2-OMEGA_K*gamma_y*(1+gamma_y)+LAMBDA_ss*OMEGA_K*gamma_y*(1+gamma_y)^2);
qR_ss = 1/(  1-OMEGA_R*((1+gamma_y)/(1+gamma_a)-1)^2/2 -OMEGA_R*((1+gamma_y)/(1+gamma_a)-1)*(1+gamma_y)/(1+gamma_a)+...
        LAMBDA_ss*(1+gamma_a)*OMEGA_R*((1+gamma_y)/(1+gamma_a)-1)*((1+gamma_y)/(1+gamma_a))^2 );
RK_ss = qk_ss/LAMBDA_ss-(1-delta)*qk_ss;
zeta_R = 1.15;
RR_ss = (qR_ss/LAMBDA_ss-(1-delta_R)*(1+gamma_a)*qR_ss)*zeta_R;
RF_ss = RR_ss;
% fslove求解稳态
myfun = @(x)[x(3)-(x(1)/(1+gamma_y)) ^eta
x(5) - (RK_ss*x(1)/(eta*(1-alpha)*MC_ss*(1+gamma_y)*x(3)))^(1/(1-kappa))*x(3)
x(4) - ((x(5)^kappa-(1-alpha)*x(3)^kappa)/alpha)^(1/kappa)
x(2) - x(4)^(1/theta)*(1+gamma_rob)
RF_ss - alpha*theta*MC_ss*(x(5)/x(4))^(1-kappa)*x(4)/(x(2)/(1+gamma_rob))];
x0 = [30,20,4,6,8]*(1+0.01*i);
x = fsolve(myfun, x0);
K_ss = x(1);
ROBF_ss = x(2);
HT_ss = x(3);
HR_ss = x(4);
Y_ss = x(5);

rob_ss = ROBF_ss;
I_ss = (1-(1-delta)/(1+gamma_y))*K_ss/(1-OMEGA_K*gamma_y^2/2);
IR_ss = (1-(1-delta_R)*(1+gamma_a)/(1+gamma_y))*ROBF_ss/(1-OMEGA_R*((1+gamma_y)/(1+gamma_a)-1)^2/2);
G_ss = g_ss*Y_ss;
w_ss = (1-eta)*(1-alpha)*MC_ss*(Y_ss/HT_ss)^(1-kappa)*HT_ss;
T1_ss = G_ss*w_ss/Y_ss;
C1_ss = w_ss-T1_ss;
lambda1_ss = C1_ss^(-sigma1);
nu = lambda1_ss*w_ss;
lambdaA_ss = 0.5/4;
Z_ss = (1+gamma_a-phi)/(lambdaA_ss*phi)+1;
V_ss = (zeta_R-1)*RF_ss*ROBF_ss/((1-phi*LAMBDA_ss*(1+gamma_y)/(1+gamma_a))*zeta_R);
J_ss = phi*LAMBDA_ss*(1+gamma_y)/(1+gamma_a)*(1-rho_lambda)*lambdaA_ss*V_ss/(1+phi*LAMBDA_ss*(1+gamma_y)/(1+gamma_a)*(lambdaA_ss-rho_lambda*lambdaA_ss-1));
wsLsa = lambdaA_ss*rho_lambda*phi*LAMBDA_ss*(1+gamma_y)/(1+gamma_a)*(V_ss-J_ss);
wsLsr = LAMBDA_ss*(1+gamma_y)/(1+gamma_a)*J_ss*Z_ss*(1+gamma_a-phi);
ws_ss = (Z_ss-1)*wsLsa+wsLsr;
Lsa_ss = wsLsa/ws_ss;
Lsr_ss = wsLsr/ws_ss;
T2_ss = G_ss*ws_ss/Y_ss;
C2_ss = ws_ss-T2_ss;
lambda2_ss = C2_ss^(-sigma2);
nu_S = lambda2_ss*ws_ss;
kappa_lambda = lambdaA_ss/(Z_ss*Lsa_ss)^rho_lambda;
chiZ_ss = (1+gamma_a-phi)/(Z_ss^(-rho_zz)*Lsr_ss^rho_L);


Y(i) = Y_ss;
ROB(i) = ROBF_ss;
income1(i) = w_ss;
income2(i) = ws_ss;
income3(i) = Y_ss-C1_ss-C2_ss-G_ss;
INDX(i) = income3(i)-income1(i);
wu(i) = w_ss;
ws(i) = ws_ss;
ROB_Y(i) = RR_ss*ROBF_ss/(MC_ss*Y_ss);
wu_Y(i) = income1(i)/Y(i);
ws_Y(i) = income2(i)/Y(i);
we_Y(i) = income3(i)/Y(i);

i = 1+i;
end

%%  画图
subplot(3,4,1)
plot(ht,Y,'-k','LineWidth',1.3);
title('经济总产出','Fontsize',13);

subplot(3,4,2)
plot(ht,ROB,'-k','LineWidth',1.3);
title('机器人规模','Fontsize',13)

subplot(3,4,3)
plot(ht,wu_Y/MC_ss,'-k','LineWidth',1.3);
title('低技能收入份额','Fontsize',13)

subplot(3,4,4)
plot(ht,ROB_Y,'-k','LineWidth',1.3);
title('机器人收入份额','Fontsize',13)

subplot(3,4,5)
plot(ht,wu,'-k','LineWidth',1.3);
title('低技能实际工资','Fontsize',13)

subplot(3,4,6)
plot(ht,ws,'-k','LineWidth',1.3);
title('高技能实际工资','Fontsize',13)

subplot(3,4,7)
plot(ht,income1,'-k','LineWidth',1.3);
title('低技能家庭实际收入','Fontsize',13)

subplot(3,4,8)
plot(ht,income2,'-k','LineWidth',1.3);
title('高技能家庭实际收入','Fontsize',13)

subplot(3,4,9)
plot(ht,income3,'-k','LineWidth',1.3);
title('资本型家庭实际收入','Fontsize',13)

subplot(3,4,10)
plot(ht,wu_Y,'-k','LineWidth',1.3);
title('低技能收入占产出比重','Fontsize',13)

subplot(3,4,11)
plot(ht,ws_Y,'-k','LineWidth',1.3);
title('高技能收入占产出比重','Fontsize',13)

subplot(3,4,12)
plot(ht,we_Y,'-k','LineWidth',1.3);
title('资本型收入占产出比重','Fontsize',13)