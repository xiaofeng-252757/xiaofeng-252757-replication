function residual = static_resid(T, y, x, params, T_flag)
% function residual = static_resid(T, y, x, params, T_flag)
%
% File created by Dynare Preprocessor from .mod file
%
% Inputs:
%   T         [#temp variables by 1]  double   vector of temporary terms to be filled by function
%   y         [M_.endo_nbr by 1]      double   vector of endogenous variables in declaration order
%   x         [M_.exo_nbr by 1]       double   vector of exogenous variables in declaration order
%   params    [M_.param_nbr by 1]     double   vector of parameter values in declaration order
%                                              to evaluate the model
%   T_flag    boolean                 boolean  flag saying whether or not to calculate temporary terms
%
% Output:
%   residual
%

if T_flag
    T = robot_tau_c.static_resid_tt(T, y, x, params);
end
residual = zeros(55, 1);
lhs = exp(y(26))*exp(y(1));
rhs = params(59)*exp(y(2))^params(62);
residual(1) = lhs - rhs;
lhs = exp(y(1));
rhs = T(4);
residual(2) = lhs - rhs;
lhs = exp(y(27))*exp(y(3));
rhs = params(60)*exp(y(4))^params(62);
residual(3) = lhs - rhs;
lhs = T(7)*T(8);
rhs = exp(y(3));
residual(4) = lhs - rhs;
lhs = T(12);
rhs = exp(y(3));
residual(5) = lhs - rhs;
lhs = exp(y(5))+exp(y(6))*(exp(y(37))-exp(y(29)));
rhs = exp(y(4));
residual(6) = lhs - rhs;
lhs = 1;
rhs = T(15);
residual(7) = lhs - rhs;
lhs = 1;
rhs = T(19);
residual(8) = lhs - rhs;
lhs = exp(y(7));
rhs = exp(y(30))*(exp(y(9))+exp(y(7))*(1-params(10)));
residual(9) = lhs - rhs;
lhs = exp(y(8));
rhs = T(20);
residual(10) = lhs - rhs;
lhs = exp(y(9));
rhs = T(21);
residual(11) = lhs - rhs;
lhs = exp(y(15));
rhs = T(24)/T(25);
residual(12) = lhs - rhs;
lhs = exp(y(11));
rhs = exp(y(13))*T(13)+(1-params(10))*exp(y(11))/(1+params(19));
residual(13) = lhs - rhs;
lhs = exp(y(12));
rhs = exp(y(14))*T(17)+exp(y(12))*(1+params(21))*(1-params(11))/(1+params(19));
residual(14) = lhs - rhs;
lhs = exp(y(16));
rhs = T(26);
residual(15) = lhs - rhs;
lhs = exp(y(15));
rhs = T(27);
residual(16) = lhs - rhs;
lhs = exp(y(17));
rhs = T(34);
residual(17) = lhs - rhs;
lhs = exp(y(18));
rhs = exp(y(43))*T(28)*exp(y(41));
residual(18) = lhs - rhs;
lhs = exp(y(19));
rhs = T(32);
residual(19) = lhs - rhs;
lhs = exp(y(20));
rhs = exp(y(1))*exp(y(2))-exp(y(23))+exp(y(54));
residual(20) = lhs - rhs;
lhs = T(35);
rhs = T(36)*T(41);
residual(21) = lhs - rhs;
lhs = exp(y(21));
rhs = exp(y(3))*exp(y(4))-exp(y(24));
residual(22) = lhs - rhs;
lhs = exp(y(50));
rhs = exp(y(53))-exp(y(20));
residual(23) = lhs - rhs;
lhs = exp(y(17));
rhs = exp(y(13))+exp(y(20))+exp(y(21))+exp(y(22))+exp(y(29))*exp(y(14))+exp(y(17))*exp(y(47));
residual(24) = lhs - rhs;
lhs = T(42);
rhs = T(42)*params(9)*(1+params(20))*exp(y(45));
residual(25) = lhs - rhs;
lhs = exp(y(23));
rhs = T(44);
residual(26) = lhs - rhs;
lhs = exp(y(24));
rhs = T(45);
residual(27) = lhs - rhs;
lhs = exp(y(25));
rhs = exp(y(17))*exp(y(47))-exp(y(23))-exp(y(24));
residual(28) = lhs - rhs;
lhs = exp(y(26))*(1-exp(y(55)));
rhs = T(42);
residual(29) = lhs - rhs;
lhs = exp(y(20))*exp(y(55));
rhs = exp(y(54));
residual(30) = lhs - rhs;
lhs = exp(y(27));
rhs = exp(y(21))^(-params(4));
residual(31) = lhs - rhs;
lhs = exp(y(28));
rhs = exp(y(22))^(-params(5));
residual(32) = lhs - rhs;
lhs = exp(y(30));
rhs = params(9)*(1+params(20));
residual(33) = lhs - rhs;
lhs = exp(y(34));
rhs = T(49)*T(50);
residual(34) = lhs - rhs;
lhs = exp(y(34));
rhs = exp(y(45))*exp(y(32));
residual(35) = lhs - rhs;
lhs = y(32);
rhs = params(66)*(y(31)-(y(31)))+y(32)*params(67)/(1+params(9)*params(67))+y(32)*params(9)/(1+params(9)*params(67));
residual(36) = lhs - rhs;
lhs = exp(y(32))^T(51);
rhs = (1-params(68))*exp(y(33))^T(51)+params(68)*(T(52))^T(51);
residual(37) = lhs - rhs;
lhs = exp(y(35));
rhs = T(53)+T(55);
residual(38) = lhs - rhs;
lhs = exp(y(36));
rhs = T(56)-exp(y(3))*exp(y(6));
residual(39) = lhs - rhs;
lhs = exp(y(37));
rhs = T(59)/(1+params(21));
residual(40) = lhs - rhs;
lhs = exp(y(29));
rhs = T(60)*(exp(y(29))+(exp(y(37))-exp(y(29)))*exp(y(39)));
residual(41) = lhs - rhs;
lhs = exp(y(38));
rhs = T(8)*exp(y(44))*T(6);
residual(42) = lhs - rhs;
lhs = exp(y(39));
rhs = y(46)*T(61);
residual(43) = lhs - rhs;
lhs = y(40);
rhs = y(40)*params(52)+x(1);
residual(44) = lhs - rhs;
lhs = y(41);
rhs = y(41)*params(53)+x(3);
residual(45) = lhs - rhs;
lhs = y(42);
rhs = y(42)*params(54)+x(2);
residual(46) = lhs - rhs;
lhs = y(43);
rhs = y(43)*params(55)+x(4);
residual(47) = lhs - rhs;
lhs = y(44);
rhs = y(44)*params(56)+(1-params(56))*log(params(50))+x(5);
residual(48) = lhs - rhs;
lhs = y(46);
rhs = y(46)*params(57)+(1-params(57))*params(51)+x(6);
residual(49) = lhs - rhs;
lhs = y(47);
rhs = y(47)*params(58)+(1-params(58))*log(params(2))+x(7);
residual(50) = lhs - rhs;
lhs = exp(y(48));
rhs = T(62);
residual(51) = lhs - rhs;
lhs = exp(y(49));
rhs = T(63);
residual(52) = lhs - rhs;
lhs = exp(y(51));
rhs = exp(y(1))*exp(y(2));
residual(53) = lhs - rhs;
lhs = exp(y(52));
rhs = exp(y(3))*exp(y(4));
residual(54) = lhs - rhs;
lhs = exp(y(53));
rhs = exp(y(29))*exp(y(14))+exp(y(13))+exp(y(22));
residual(55) = lhs - rhs;
if ~isreal(residual)
  residual = real(residual)+imag(residual).^2;
end
end
