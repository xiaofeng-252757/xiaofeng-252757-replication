% ============================================================
% [ORIGINAL — DO NOT EDIT]
% Source : 齐亚东、于泽、朱军 (2026).《工业智能化与收入分配格局演变：
%          经济发展机遇背后的分配失衡隐忧》公开复现附件（Dynare/Matlab）.
% Role   : 作者原始程序，本文严格沿用，未改动模型设定、参数口径、实验目标.
% Note   : 本文件属"原始作者程序"，仅用于 DSGE 核心复现；任何修改都必须
%          放到 optional_supplementary_code/ 下，本文件保持与作者版本一致.
% ============================================================

%% 模型运行
clc
clear
close all
robot_c_ss
robot_e_ss
robot_l_ss
dynare robot_tau_c
dynare robot_tau_e
dynare robot_tau_l


%% 画图
close all
figure;
T = 0:1:20;
x = zeros(21,1);

subplot(3,3,1);
plot(T,L_ee_xi_e,'--k',T,L_ee_xi_l,'-k',T,L_ee_xi_c,'-.k',T,x,'--k','LineWidth',1.3);
title('低技能劳动','Fontsize',13);

subplot(3,3,2);
plot(T,w_ee_xi_e,'--k',T,w_ee_xi_l,'-k',T,w_ee_xi_c,'-.k',T,x,'--k','LineWidth',1.3);
title('低技能工资','Fontsize',13);

subplot(3,3,3);
plot(T,lambda1_ee_xi_e,'--k',T,lambda1_ee_xi_l,'-k',T,lambda1_ee_xi_c,'-.k',T,x,'--k','LineWidth',1.3);
title('低技能家庭边际效用','Fontsize',13);

subplot(3,3,4);
plot(T,C1_ee_xi_e,'--k',T,C1_ee_xi_l,'-k',T,C1_ee_xi_c,'-.k',T,x,'--k','LineWidth',1.3);
title('低技能家庭实际收入','Fontsize',13);

subplot(3,3,5);
plot(T,income3_ee_xi_e,'--k',T,income3_ee_xi_l,'-k',T,income3_ee_xi_c,'-.k',T,x,'--k','LineWidth',1.3);
title('资本型家庭实际收入','Fontsize',13);

subplot(3,3,6);
plot(T,INDX_ee_xi_e,'--k',T,INDX_ee_xi_l,'-k',T,INDX_ee_xi_c,'-.k',T,x,'--k','LineWidth',1.3);
title('收入差距','Fontsize',13);

subplot(3,3,7);
plot(T,MC_ee_xi_e,'--k',T,MC_ee_xi_l,'-k',T,MC_ee_xi_c,'-.k',T,x,'--k','LineWidth',1.3);
title('中间品价格','Fontsize',13);

subplot(3,3,8);
plot(T,Y_ee_xi_e,'--k',T,Y_ee_xi_l,'-k',T,Y_ee_xi_c,'-.k',T,x,'--k','LineWidth',1.3);
title('经济总产出','Fontsize',13);

legend('情形1：一次性转移支付','情形2：劳动补贴','情形3：消费补贴','Fontsize',13)



