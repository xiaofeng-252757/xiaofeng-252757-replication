function T = static_resid_tt(T, y, x, params)
% function T = static_resid_tt(T, y, x, params)
%
% File created by Dynare Preprocessor from .mod file
%
% Inputs:
%   T         [#temp variables by 1]  double   vector of temporary terms to be filled by function
%   y         [M_.endo_nbr by 1]      double   vector of endogenous variables in declaration order
%   x         [M_.exo_nbr by 1]       double   vector of exogenous variables in declaration order
%   params    [M_.param_nbr by 1]     double   vector of parameter values in declaration order
%
% Output:
%   T         [#temp variables by 1]  double   vector of temporary terms
%

assert(length(T) >= 55);

T(1) = exp(y(40))^params(18);
T(2) = exp(y(17))/exp(y(19));
T(3) = T(2)^(1-params(18));
T(4) = exp(y(19))*(1-params(7))*(1-params(6))*exp(y(31))*T(1)*T(3)/exp(y(2));
T(5) = exp(y(30))*exp(y(36))*exp(y(44))*(1+params(19))/(1+params(21));
T(6) = exp(y(37))^(1-params(69));
T(7) = T(5)*T(6);
T(8) = exp(y(5))^(params(16)-1);
T(9) = (exp(y(37))*exp(y(6)))^(params(15)-1);
T(10) = exp(y(37))*y(46)*params(15)*T(9);
T(11) = (1+params(19))*exp(y(30))*T(10)*params(14)/(1+params(21));
T(12) = T(11)*(exp(y(35))-exp(y(36)));
T(13) = 1-params(12)/2*params(19)^2;
T(14) = params(19)*params(12)*exp(y(30))*exp(y(7))*(1+params(19))^2;
T(15) = exp(y(7))*(T(13)-(1+params(19))*params(19)*params(12))+T(14);
T(16) = (1+params(19))/(1+params(21))-1;
T(17) = 1-params(13)/2*T(16)^2;
T(18) = T(16)*params(13)*exp(y(8))*exp(y(30))*(1+params(21))*((1+params(19))/(1+params(21)))^2;
T(19) = exp(y(8))*(T(17)-(1+params(19))*params(13)*T(16)/(1+params(21)))+T(18);
T(20) = exp(y(30))*(exp(y(10))/params(61)+exp(y(8))*(1+params(21))*(1-params(11)));
T(21) = exp(y(19))*(1+params(19))*T(3)*T(1)*exp(y(31))*params(7)*(1-params(6))/exp(y(11));
T(22) = exp(y(17))/exp(y(18));
T(23) = T(22)^(1-params(18));
T(24) = exp(y(18))*T(1)*exp(y(31))*params(6)*params(8)*T(23);
T(25) = exp(y(16))/(1+params(22));
T(26) = exp(y(29))*exp(y(12))*exp(y(29))^(params(17)-1);
T(27) = exp(y(10))*exp(y(29))^(1-params(17));
T(28) = T(25)^params(8);
T(29) = exp(y(11))/(1+params(19));
T(30) = exp(y(42))*T(29)^params(7);
T(31) = exp(y(2))^(1-params(7));
T(32) = T(30)*T(31);
T(33) = params(6)*(exp(y(43))*T(28)*exp(y(41)))^params(18)+(1-params(6))*T(32)^params(18);
T(34) = exp(y(40))*T(33)^(1/params(18));
T(35) = exp(y(1))*exp(y(2))/exp(y(17));
T(36) = exp(y(17))*exp(y(47))*T(35);
T(37) = exp(y(17))*exp(y(47))*exp(y(3))*exp(y(4))/exp(y(17));
T(38) = exp(y(32))^params(63);
T(39) = (exp(y(17))/params(34))^params(64);
T(40) = T(38)*T(39)*params(45);
T(41) = T(40)^(1-params(65));
T(42) = exp(y(34))^params(65);
T(43) = (-1)/(params(1)-1);
T(44) = exp(y(32))^params(67);
T(45) = exp(y(16))*exp(y(15))*(params(61)-1)/params(61)/exp(y(29));
T(46) = (1+params(19))*exp(y(30))*params(14)/(1+params(21));
T(47) = exp(y(35))*T(46);
T(48) = T(46)*(exp(y(35))*exp(y(39))+exp(y(36))*(1-exp(y(39))));
T(49) = exp(y(44))*exp(y(37))^(-params(69));
T(50) = exp(y(5))^params(16);
T(51) = exp(y(37))*(params(14)+T(49)*T(50));
T(52) = params(14)/(1+params(21));
T(53) = (exp(y(37))*exp(y(6)))^params(15);
T(54) = T(35)/exp(y(31));
T(55) = exp(y(15))*exp(y(16))/exp(y(17))/exp(y(31));

end
