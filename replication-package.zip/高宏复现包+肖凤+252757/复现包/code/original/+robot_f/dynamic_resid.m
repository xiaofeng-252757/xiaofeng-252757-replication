function residual = dynamic_resid(T, y, x, params, steady_state, it_, T_flag)
% function residual = dynamic_resid(T, y, x, params, steady_state, it_, T_flag)
%
% File created by Dynare Preprocessor from .mod file
%
% Inputs:
%   T             [#temp variables by 1]     double   vector of temporary terms to be filled by function
%   y             [#dynamic variables by 1]  double   vector of endogenous variables in the order stored
%                                                     in M_.lead_lag_incidence; see the Manual
%   x             [nperiods by M_.exo_nbr]   double   matrix of exogenous variables (in declaration order)
%                                                     for all simulation periods
%   steady_state  [M_.endo_nbr by 1]         double   vector of steady state values
%   params        [M_.param_nbr by 1]        double   vector of parameter values in declaration order
%   it_           scalar                     double   time period for exogenous variables for which
%                                                     to evaluate the model
%   T_flag        boolean                    boolean  flag saying whether or not to calculate temporary terms
%
% Output:
%   residual
%

if T_flag
    T = robot_f.dynamic_resid_tt(T, y, x, params, steady_state, it_);
end
residual = zeros(53, 1);
lhs = exp(y(43))*exp(y(18));
rhs = params(59)*exp(y(19))^params(62);
residual(1) = lhs - rhs;
lhs = exp(y(18));
rhs = T(4);
residual(2) = lhs - rhs;
lhs = exp(y(44))*exp(y(20));
rhs = params(60)*exp(y(21))^params(62);
residual(3) = lhs - rhs;
lhs = T(7)*T(8);
rhs = exp(y(20));
residual(4) = lhs - rhs;
lhs = T(12);
rhs = exp(y(20));
residual(5) = lhs - rhs;
lhs = exp(y(22))+exp(y(23))*(exp(y(10))-exp(y(7)));
rhs = exp(y(21));
residual(6) = lhs - rhs;
lhs = 1;
rhs = T(16)+T(20);
residual(7) = lhs - rhs;
lhs = 1;
rhs = T(25)+T(29);
residual(8) = lhs - rhs;
lhs = exp(y(24));
rhs = exp(y(47))*(exp(y(73))+exp(y(71))*(1-params(10)));
residual(9) = lhs - rhs;
lhs = exp(y(25));
rhs = exp(y(47))*(exp(y(74))/params(61)+T(30));
residual(10) = lhs - rhs;
lhs = exp(y(26));
rhs = T(31);
residual(11) = lhs - rhs;
lhs = exp(y(32));
rhs = T(34)/T(35);
residual(12) = lhs - rhs;
lhs = exp(y(28));
rhs = exp(y(30))*T(15)+(1-params(10))*exp(y(1))/(1+params(19));
residual(13) = lhs - rhs;
lhs = exp(y(29));
rhs = exp(y(31))*T(23)+(1+params(21))*(1-params(11))/(1+params(19))*exp(y(2));
residual(14) = lhs - rhs;
lhs = exp(y(33));
rhs = T(36);
residual(15) = lhs - rhs;
lhs = exp(y(32));
rhs = T(37);
residual(16) = lhs - rhs;
lhs = exp(y(34));
rhs = T(44);
residual(17) = lhs - rhs;
lhs = exp(y(35));
rhs = exp(y(60))*T(38)*exp(y(58));
residual(18) = lhs - rhs;
lhs = exp(y(36));
rhs = T(42);
residual(19) = lhs - rhs;
lhs = exp(y(37));
rhs = exp(y(18))*exp(y(19))-exp(y(40));
residual(20) = lhs - rhs;
lhs = exp(y(38));
rhs = exp(y(20))*exp(y(21))-exp(y(41));
residual(21) = lhs - rhs;
lhs = exp(y(67));
rhs = exp(y(70))-exp(y(37));
residual(22) = lhs - rhs;
lhs = exp(y(34));
rhs = exp(y(30))+exp(y(37))+exp(y(38))+exp(y(39))+exp(y(31))*exp(y(46))+exp(y(34))*exp(y(64));
residual(23) = lhs - rhs;
lhs = exp(y(43));
rhs = params(9)*(1+params(20))*exp(y(62))*exp(y(77));
residual(24) = lhs - rhs;
lhs = exp(y(40));
rhs = T(46);
residual(25) = lhs - rhs;
lhs = exp(y(41));
rhs = T(47);
residual(26) = lhs - rhs;
lhs = exp(y(42));
rhs = exp(y(34))*exp(y(64))-exp(y(40))-exp(y(41));
residual(27) = lhs - rhs;
lhs = exp(y(43));
rhs = exp(y(37))^(-params(3));
residual(28) = lhs - rhs;
lhs = exp(y(44));
rhs = exp(y(38))^(-params(4));
residual(29) = lhs - rhs;
lhs = exp(y(45));
rhs = exp(y(39))^(-params(5));
residual(30) = lhs - rhs;
lhs = exp(y(47));
rhs = params(9)*(1+params(20))*exp(y(45))/exp(y(6));
residual(31) = lhs - rhs;
lhs = exp(y(51));
rhs = T(51)*T(52);
residual(32) = lhs - rhs;
lhs = exp(y(51));
rhs = exp(y(62))*exp(y(79));
residual(33) = lhs - rhs;
lhs = y(49);
rhs = params(66)*(y(48)-(steady_state(31)))+params(67)/(1+params(9)*params(67))*y(8)+y(79)*params(9)/(1+params(9)*params(67));
residual(34) = lhs - rhs;
lhs = exp(y(49))^T(53);
rhs = (1-params(68))*exp(y(50))^T(53)+params(68)*(T(54))^T(53);
residual(35) = lhs - rhs;
lhs = exp(y(52));
rhs = T(55)+exp(y(80))*T(56);
residual(36) = lhs - rhs;
lhs = exp(y(53));
rhs = T(57)-exp(y(20))*exp(y(23));
residual(37) = lhs - rhs;
lhs = exp(y(54));
rhs = T(60)/(1+params(21));
residual(38) = lhs - rhs;
lhs = exp(y(46));
rhs = T(61)*(exp(y(7))+(exp(y(10))-exp(y(7)))*exp(y(56)));
residual(39) = lhs - rhs;
lhs = exp(y(55));
rhs = T(8)*exp(y(61))*T(6);
residual(40) = lhs - rhs;
lhs = exp(y(56));
rhs = y(63)*T(62);
residual(41) = lhs - rhs;
lhs = y(57);
rhs = params(52)*y(11)+x(it_, 1);
residual(42) = lhs - rhs;
lhs = y(59);
rhs = params(54)*y(13)+x(it_, 2);
residual(43) = lhs - rhs;
lhs = y(58);
rhs = params(53)*y(12)+x(it_, 3);
residual(44) = lhs - rhs;
lhs = y(60);
rhs = params(55)*y(14)+x(it_, 4);
residual(45) = lhs - rhs;
lhs = y(61);
rhs = params(56)*y(15)+(1-params(56))*log(params(50))+x(it_, 5);
residual(46) = lhs - rhs;
lhs = y(63);
rhs = params(57)*y(16)+(1-params(57))*params(51)+x(it_, 6);
residual(47) = lhs - rhs;
lhs = y(64);
rhs = params(58)*y(17)+(1-params(58))*log(params(2))+x(it_, 7);
residual(48) = lhs - rhs;
lhs = exp(y(65));
rhs = T(63);
residual(49) = lhs - rhs;
lhs = exp(y(66));
rhs = T(64);
residual(50) = lhs - rhs;
lhs = exp(y(68));
rhs = exp(y(18))*exp(y(19));
residual(51) = lhs - rhs;
lhs = exp(y(69));
rhs = exp(y(20))*exp(y(21));
residual(52) = lhs - rhs;
lhs = exp(y(70));
rhs = exp(y(31))*exp(y(46))+exp(y(30))+exp(y(39));
residual(53) = lhs - rhs;

end
