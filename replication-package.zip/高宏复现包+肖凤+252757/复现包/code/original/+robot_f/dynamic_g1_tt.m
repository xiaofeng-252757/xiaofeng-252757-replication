function T = dynamic_g1_tt(T, y, x, params, steady_state, it_)
% function T = dynamic_g1_tt(T, y, x, params, steady_state, it_)
%
% File created by Dynare Preprocessor from .mod file
%
% Inputs:
%   T             [#temp variables by 1]     double  vector of temporary terms to be filled by function
%   y             [#dynamic variables by 1]  double  vector of endogenous variables in the order stored
%                                                    in M_.lead_lag_incidence; see the Manual
%   x             [nperiods by M_.exo_nbr]   double  matrix of exogenous variables (in declaration order)
%                                                    for all simulation periods
%   steady_state  [M_.endo_nbr by 1]         double  vector of steady state values
%   params        [M_.param_nbr by 1]        double  vector of parameter values in declaration order
%   it_           scalar                     double  time period for exogenous variables for which
%                                                    to evaluate the model
%
% Output:
%   T           [#temp variables by 1]       double  vector of temporary terms
%

assert(length(T) >= 85);

T = robot_f.dynamic_resid_tt(T, y, x, params, steady_state, it_);

T(65) = T(40)*exp(y(19))*getPowerDeriv(exp(y(19)),1-params(7),1);
T(66) = getPowerDeriv(T(42),params(18),1);
T(67) = getPowerDeriv(T(43),1/params(18),1);
T(68) = exp(y(22))*getPowerDeriv(exp(y(22)),params(16)-1,1);
T(69) = exp(y(10))*y(63)*params(15)*exp(y(10))*exp(y(23))*getPowerDeriv(exp(y(10))*exp(y(23)),params(15)-1,1);
T(70) = (-(y(63)*exp(y(10))*exp(y(23))*getPowerDeriv(exp(y(10))*exp(y(23)),params(15),1)));
T(71) = T(41)*exp(y(59))*T(39)*getPowerDeriv(T(39),params(7),1);
T(72) = (-((1+params(19))*exp(y(30))*exp(y(3))))/(exp(y(3))*exp(y(3)));
T(73) = (-(exp(y(30))*(1+params(19))*exp(y(75))))/(exp(y(30))*exp(y(30)));
T(74) = (-((1+params(19))/(1+params(21))*exp(y(31))*exp(y(4))))/(exp(y(4))*exp(y(4)));
T(75) = (-(exp(y(31))*(1+params(19))/(1+params(21))*exp(y(76))))/(exp(y(31))*exp(y(31)));
T(76) = T(35)*getPowerDeriv(T(35),params(8),1);
T(77) = getPowerDeriv(exp(y(60))*T(38)*exp(y(58)),params(18),1);
T(78) = getPowerDeriv(T(2),1-params(18),1);
T(79) = getPowerDeriv(T(32),1-params(18),1);
T(80) = (-(exp(y(34))*exp(y(18))*exp(y(19))))/(exp(y(34))*exp(y(34)));
T(81) = getPowerDeriv(T(50),1-params(65),1);
T(82) = T(78)*(-(exp(y(34))*exp(y(36))))/(exp(y(36))*exp(y(36)));
T(83) = (-(exp(y(80))*T(56)));
T(84) = exp(y(10))*getPowerDeriv(exp(y(10)),1-params(69),1);
T(85) = exp(y(57))*getPowerDeriv(exp(y(57)),params(18),1);

end
