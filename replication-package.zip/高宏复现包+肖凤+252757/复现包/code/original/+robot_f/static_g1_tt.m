function T = static_g1_tt(T, y, x, params)
% function T = static_g1_tt(T, y, x, params)
%
% File created by Dynare Preprocessor from .mod file
%
% Inputs:
%   T         [#temp variables by 1]  double   vector of temporary terms to be filled by function
%   y         [M_.endo_nbr by 1]      double   vector of endogenous variables in declaration order
%   x         [M_.exo_nbr by 1]       double   vector of exogenous variables in declaration order
%   params    [M_.param_nbr by 1]     double   vector of parameter values in declaration order
%
% Output:
%   T         [#temp variables by 1]  double   vector of temporary terms
%

assert(length(T) >= 71);

T = robot_f.static_resid_tt(T, y, x, params);

T(56) = T(30)*exp(y(2))*getPowerDeriv(exp(y(2)),1-params(7),1);
T(57) = getPowerDeriv(T(32),params(18),1);
T(58) = getPowerDeriv(T(33),1/params(18),1);
T(59) = exp(y(5))*getPowerDeriv(exp(y(5)),params(16)-1,1);
T(60) = exp(y(37))*y(46)*params(15)*exp(y(37))*exp(y(6))*getPowerDeriv(exp(y(37))*exp(y(6)),params(15)-1,1);
T(61) = (-(y(46)*exp(y(37))*exp(y(6))*getPowerDeriv(exp(y(37))*exp(y(6)),params(15),1)));
T(62) = T(31)*exp(y(42))*T(29)*getPowerDeriv(T(29),params(7),1);
T(63) = T(25)*getPowerDeriv(T(25),params(8),1);
T(64) = getPowerDeriv(exp(y(43))*T(28)*exp(y(41)),params(18),1);
T(65) = getPowerDeriv(T(2),1-params(18),1);
T(66) = getPowerDeriv(T(22),1-params(18),1);
T(67) = (-(exp(y(17))*exp(y(1))*exp(y(2))))/(exp(y(17))*exp(y(17)));
T(68) = getPowerDeriv(T(40),1-params(65),1);
T(69) = T(65)*(-(exp(y(19))*exp(y(17))))/(exp(y(19))*exp(y(19)));
T(70) = exp(y(37))*getPowerDeriv(exp(y(37)),1-params(69),1);
T(71) = exp(y(40))*getPowerDeriv(exp(y(40)),params(18),1);

end
