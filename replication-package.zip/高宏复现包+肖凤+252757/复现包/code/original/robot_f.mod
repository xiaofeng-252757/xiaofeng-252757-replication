% ============================================================
% [ORIGINAL — DO NOT EDIT]
% Source : 齐亚东、于泽、朱军 (2026).《工业智能化与收入分配格局演变：
%          经济发展机遇背后的分配失衡隐忧》公开复现附件（Dynare/Matlab）.
% Role   : 作者原始程序，本文严格沿用，未改动模型设定、参数口径、实验目标.
% Note   : 本文件属"原始作者程序"，仅用于 DSGE 核心复现；任何修改都必须
%          放到 optional_supplementary_code/ 下，本文件保持与作者版本一致.
% ============================================================

var
w L w_S L_S Lsr Lsa q_K q_R R_K R_R K Rob_A
I I_R_A R_F ROB_F Y HR HT C1 C2 C3 T1 T2 T3 
lambda1 lambda2 lambda3 A LAMBDA MC pi pi_star
R_n V J Z phi_Z lambda_A A_Y A_R A_T xi chi_Z R
kappa_lambda g fe_u fe_M INDX income1 income2 income3;

varexo
ee_AY ee_AT ee_AR ee_xi ee_Z ee_kappa ee_g;

parameters
mu g_ss sigma1 sigma2 sigma3 alpha eta theta beta
delta delta_R OMEGA_K OMEGA_R phi rho_lambda rho_L
theta_A kappa gamma_y gamma_lambdau gamma_a gamma_rob
w_ss ws_ss Lsr_ss Lsa_ss qk_ss qR_ss RK_ss RR_ss 
K_ss rob_ss I_ss Y_ss HR_ss HT_ss C1_ss C2_ss IR_ss
G_ss T1_ss T2_ss lambda1_ss lambda2_ss R_ss LAMBDA_ss
MC_ss Z_ss lambdaA_ss chiZ_ss kappa_lambda_ss rho_AY rho_AR
rho_AT rho_xi rho_chi rho_k rho_g nu nu_S zeta_R phi_L
phi_pi phi_Y rho_R kappa_pi lp xi_p rho_z V_ss J_ss;

lp = 0.5;
xi_p = 0.75;
rho_z = 0.3;
rho_L = 0.37;
phi_Y = 0.5;
rho_R= 0.8;
phi_pi= 1.5;  
mu = 1.2;
phi_L = 2;
sigma1 = 0.8;
sigma2 = 0.8;
sigma3 = 0.8;
alpha = 0.25;
eta = 0.5;
theta = 0.7;
beta = 0.995;
delta = 0.025;
delta_R = 0.05;
OMEGA_K = 4;
OMEGA_R = 2;
phi = 0.967; 
rho_lambda = 0.925;
theta_A = 1.35;
kappa = 0.95;
rho_AY = 0.75;
rho_AT = 0.75;
rho_AR = 0.75;
rho_xi = 0.75;
rho_chi = 0.75;
rho_g = 0.75;
rho_k = 0.75;
gamma_y = 0.02708;
gamma_lambdau = (1+gamma_y)^(-sigma1)-1;
gamma_a = (1+gamma_y)^((1-theta)/(theta*(theta_A-1)))-1;
gamma_rob = (1+gamma_y)^(1/theta)-1;


load var_ss;
set_param_value('nu', nu);
set_param_value('nu_S', nu_S);
set_param_value('zeta_R', zeta_R);
set_param_value('zeta_R', zeta_R);
set_param_value('rob_ss', rob_ss);
set_param_value('w_ss', w_ss);
set_param_value('ws_ss', ws_ss);
set_param_value('Lsr_ss', Lsr_ss);
set_param_value('Lsa_ss', Lsa_ss);
set_param_value('qk_ss', qk_ss);
set_param_value('qR_ss', qR_ss);
set_param_value('RK_ss', RK_ss);
set_param_value('RR_ss', RR_ss);
set_param_value('K_ss', K_ss);
set_param_value('I_ss', I_ss);
set_param_value('IR_ss', IR_ss);
set_param_value('Y_ss', Y_ss);
set_param_value('HR_ss', HR_ss);
set_param_value('HT_ss', HT_ss);
set_param_value('C1_ss', C1_ss);
set_param_value('C2_ss', C2_ss);
set_param_value('G_ss', G_ss);
set_param_value('T1_ss', T1_ss);
set_param_value('T2_ss', T2_ss);
set_param_value('lambda1_ss', lambda1_ss);
set_param_value('lambda2_ss', lambda2_ss);
set_param_value('R_ss', R_ss);
set_param_value('LAMBDA_ss', LAMBDA_ss);
set_param_value('MC_ss', MC_ss);
set_param_value('V_ss', V_ss);
set_param_value('J_ss', J_ss);
set_param_value('Z_ss', Z_ss);
set_param_value('lambdaA_ss', lambdaA_ss);
set_param_value('g_ss', g_ss);
set_param_value('chiZ_ss', chiZ_ss);
kappa_pi = (1-xi_p*beta)*(1-xi_p)/(xi_p*(1+lp*beta));
kappa_lambda_ss = lambdaA_ss/(Z_ss*Lsa_ss)^rho_lambda;

model;
%劳动力市场 w L w_S L_S Lsr Lsa
exp(lambda1)*exp(w) = nu*exp(L)^phi_L;
exp(w) = (1-eta)*(1-alpha)*exp(MC)*exp(A_Y)^kappa*(exp(Y)/exp(HT))^(1-kappa)*exp(HT)/exp(L);
exp(lambda2)*exp(w_S) = nu_S*exp(L_S)^phi_L;
exp(LAMBDA(+1))*exp(J(+1))*exp(chi_Z)*(1+gamma_y)/(1+gamma_a)*exp(Z(-1))^(1-rho_z)*exp(Lsr)^(rho_L-1) = exp(w_S);
kappa_lambda*rho_lambda*(exp(Z(-1))*exp(Lsa))^(rho_lambda-1)*exp(Z(-1))*phi*exp(LAMBDA(+1))*(1+gamma_y)/(1+gamma_a)*(exp(V(+1))-exp(J(+1))) = exp(w_S);
exp(Lsr)+(exp(Z(-1))-exp(A(-1)))*exp(Lsa) = exp(L_S);


%资本市场 q_K q_R R_K R_R K Rob_A I I_R_A
1 = exp(q_K)*(1-OMEGA_K/2*((1+gamma_y)*exp(I)/exp(I(-1))-1)^2-OMEGA_K*((1+gamma_y)*exp(I)/exp(I(-1))-1)*(1+gamma_y)*exp(I)/exp(I(-1)))
  + exp(LAMBDA)*exp(q_K(+1))*OMEGA_K*((1+gamma_y)*exp(I(+1))/exp(I)-1)*((1+gamma_y)*exp(I(+1))/exp(I))^2;
1 = exp(q_R)*(1-OMEGA_R/2*((1+gamma_y)/(1+gamma_a)*exp(I_R_A)/exp(I_R_A(-1))-1)^2-OMEGA_R*((1+gamma_y)/(1+gamma_a)*exp(I_R_A)/exp(I_R_A(-1))-1)*(1+gamma_y)/(1+gamma_a)*exp(I_R_A)/exp(I_R_A(-1)))
  + exp(LAMBDA)*(1+gamma_a)*exp(A)/exp(A(-1))*exp(q_R(+1))*OMEGA_R *((1+gamma_y)/(1+gamma_a)*exp(I_R_A(+1))/exp(I_R_A)-1)*((1+gamma_y)/(1+gamma_a)*exp(I_R_A(+1))/exp(I_R_A))^2;
exp(q_K) = exp(LAMBDA)*(exp(R_K(+1))+(1-delta)*exp(q_K(+1)));
exp(q_R) = exp(LAMBDA)*(exp(R_R(+1))/zeta_R+(1-delta_R)*(1+gamma_a)*exp(A)/exp(A(-1))*exp(q_R(+1)));
exp(R_K) = eta*(1-alpha)*exp(MC)*exp(A_Y)^kappa*(exp(Y)/exp(HT))^(1-kappa)*(1+gamma_y)*exp(HT)/exp(K(-1));  
exp(R_F) = alpha*theta*exp(MC)*exp(A_Y)^kappa*(exp(Y)/exp(HR))^(1-kappa)*exp(HR)/(exp(ROB_F(-1))/(1+gamma_rob));
exp(K) = (1-OMEGA_K/2*((1+gamma_y)*exp(I)/exp(I(-1))-1)^2)*exp(I)+(1-delta)*exp(K(-1))/(1+gamma_y);
exp(Rob_A) = (1-OMEGA_R/2*((1+gamma_y)/(1+gamma_a)*exp(I_R_A)/exp(I_R_A(-1))-1)^2)*exp(I_R_A)+(1-delta_R)*(1+gamma_a)/(1+gamma_y)*exp(Rob_A(-1));

%厂商生产活动 R_F ROB_F Y HR HT
exp(ROB_F) = exp(A)^(theta_A-1)* exp(Rob_A)*exp(A);
exp(R_F) = exp(A(-1))^(1-theta_A)*exp(R_R);
exp(Y) = exp(A_Y)*(alpha*(exp(xi)*(exp(ROB_F(-1))/(1+gamma_rob))^theta*exp(A_R))^kappa+(1-alpha)*(exp(A_T)*(exp(K(-1))/(1+gamma_y))^eta*exp(L)^(1-eta))^kappa)^(1/kappa);
exp(HR) = exp(A_R)*(exp(ROB_F(-1))/(1+gamma_rob))^theta*exp(xi);
exp(HT) = exp(A_T)*(exp(K(-1))/(1+gamma_y))^eta*exp(L)^(1-eta);

%消费活动与市场出清 C1 C2 C3 R INDX
exp(C1) = exp(w)*exp(L)-exp(T1);
exp(C2) = exp(w_S)*exp(L_S)-exp(T2);
exp(INDX) = exp(income3)-exp(C1);
exp(Y) = exp(C1)+exp(C2)+exp(C3)+exp(I)+exp(I_R_A)*exp(A)+exp(g)*exp(Y);
exp(lambda1) = beta*(1+gamma_lambdau)*exp(R)*exp(lambda1(+1));

%税收 T1 T2 T3
exp(T1) = exp(w)*exp(L)/exp(Y) * exp(g)*exp(Y);
exp(T2) = exp(w_S)*exp(L_S)/exp(Y) * exp(g)*exp(Y);
exp(T3) = exp(g)*exp(Y)-exp(T1)-exp(T2);

%拉格朗日乘子和随机贴现因子 lambda1 lambda2 lambda3 LAMBDA
exp(lambda1) = exp(C1)^(-sigma1);
exp(lambda2) = exp(C2)^(-sigma2);
exp(lambda3) = exp(C3)^(-sigma3);
exp(LAMBDA) = beta*(1+gamma_lambdau)*exp(lambda3)/exp(lambda3(-1));

%利率市场和货币政策规则 MC pi pi_star R_n
exp(R_n) = (exp(pi)^phi_pi*(exp(Y)/Y_ss)^phi_Y*R_ss)^(1-rho_R)*exp(R_n(-1))^rho_R;
exp(R_n) = exp(R)*exp(pi(+1));
pi = kappa_pi*(MC-steady_state(MC))+lp/(1+lp*beta)*pi(-1)+beta/(1+lp*beta)*pi(+1);
exp(pi)^(-1/(mu-1)) = (1-xi_p)*exp(pi_star)^(-1/(mu-1))+xi_p*(exp(pi(-1))^lp)^(-1/(mu-1));

%技术研发与推广活动 V J Z A phi_Z lambda_A
exp(V) = (zeta_R-1)/zeta_R*exp(R_F)*exp(ROB_F)/exp(A(-1))+phi*exp(LAMBDA(+1))*(1+gamma_y)/(1+gamma_a)*exp(V(+1));
exp(J) = phi*exp(LAMBDA(+1))*(1+gamma_y)/(1+gamma_a)*(exp(lambda_A)*exp(V(+1))+(1-exp(lambda_A))*exp(J(+1)))
        -exp(w_S)*exp(Lsa);
exp(Z) = (exp(chi_Z)*exp(Z(-1))^(-rho_z)*exp(Lsr)^rho_L+phi)*exp(Z(-1))/(1+gamma_a);
exp(A) = phi/(1+gamma_a)*(exp(lambda_A)*(exp(Z(-1))-exp(A(-1)))+exp(A(-1)));
exp(phi_Z) = exp(chi_Z)*exp(Z(-1))^(1-rho_z)*exp(Lsr)^(rho_L-1);
exp(lambda_A) = kappa_lambda*(exp(Z(-1))*exp(Lsa))^rho_lambda;

%外生冲击 A_Y A_T A_R chi_Z kappa_lambda g
A_Y = rho_AY*A_Y(-1)+ee_AY;
A_T = rho_AT*A_T(-1)+ee_AT;
A_R = rho_AR*A_R(-1)+ee_AR;
xi = rho_xi*xi(-1)+ee_xi;
chi_Z = rho_chi*chi_Z(-1)+(1-rho_chi)*log(chiZ_ss)+ee_Z;
kappa_lambda = rho_k*kappa_lambda(-1)+(1-rho_k)*kappa_lambda_ss+ee_kappa;
g = rho_g*g(-1)+(1-rho_g)*log(g_ss)+ee_g;

%分析变量定义 fe_u fe_M income1 income2 income3
exp(fe_u) = exp(w)*exp(L)/exp(Y)/exp(MC);
exp(fe_M) = exp(R_F)*exp(ROB_F)/exp(Y)/exp(MC);
exp(income1) = exp(w)*exp(L);
exp(income2) = exp(w_S)*exp(L_S);
exp(income3) = exp(C3)+exp(I)+exp(I_R_A)*exp(A);


end;



initval;
w = log(w_ss);
w_S = log(ws_ss);
Lsr = log(Lsr_ss);
q_K = log(qk_ss);
q_R = log(qR_ss);
R_K = log(RK_ss);
R_R = log(RR_ss);
K = log(K_ss);
Rob_A  = log(rob_ss);
I = log(I_ss);
I_R_A = log(IR_ss);
R_F = log(RR_ss);
ROB_F = log(rob_ss);
Y = log(Y_ss);
HR = log(HR_ss);
HT = log(HT_ss);
C1 = log(C1_ss);
C2 = log(C2_ss);
C3 = log(Y_ss-C1_ss-C2_ss-I_ss-IR_ss-G_ss);
T1 = log(T1_ss);
T2 = log(T2_ss);
T3 = log(G_ss-T1_ss-T2_ss);
lambda1 = log(lambda1_ss);
lambda2 = log(lambda2_ss);
lambda3 = log(exp(C3)^(-sigma3));
R = log(R_ss);
LAMBDA = log(LAMBDA_ss);
MC  = log(MC_ss);
R_n = log(R_ss);
Z = log(Z_ss);
lambda_A = log(lambdaA_ss);
INDX = log(Y_ss-C1_ss-C2_ss-G_ss-C1_ss);
g = log(g_ss);
chi_Z = log(chiZ_ss);
phi_Z = log(chiZ_ss*Z_ss^(1-rho_z)*Lsr_ss^(rho_L-1));
kappa_lambda = kappa_lambda_ss;
J = log(J_ss);
V = log(V_ss);
Lsa = log(Lsa_ss);
fe_u = log(w_ss/Y_ss/MC_ss);
fe_M = log(RR_ss*rob_ss/Y_ss/MC_ss);
income1 = log(w_ss);
income2 = log(ws_ss);
income3 = log(Y_ss-C1_ss-C2_ss-G_ss);
end;


shocks;
var ee_AY = 0.01^2;
var ee_AT = 0.01^2;
var ee_AR = 0.01^2;
var ee_xi = 0.01^2;
var ee_g = 0.01^2;
var ee_Z = 0.01^2;
var ee_kappa = 0.01^2;

end;


resid(1);
steady;
model_diagnostics;
check;
model_info; 

stoch_simul(order=1, irf=21,  periods=2000, irf_shocks=(ee_xi),nograph);   
