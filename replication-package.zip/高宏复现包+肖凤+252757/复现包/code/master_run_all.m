function master_run_all()
% 统一运行整个复现包（Octave + Dynare 环境）
code_dir = fileparts(mfilename('fullpath'));
sh_path = fullfile(code_dir, 'master_run_all.sh');
cmd = sprintf('bash "%s"', sh_path);
[status, cmdout] = system(cmd);
disp(cmdout);
if status ~= 0
    error('master_run_all failed. Please check output/logs/*.log for details.');
end
end