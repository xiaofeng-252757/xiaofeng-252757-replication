% 批处理：运行基准模型并导出关键结果
1;

code_dir = fileparts(mfilename('fullpath'));
root_dir = fileparts(code_dir);
orig_dir = fullfile(code_dir, 'original');
out_data_dir = fullfile(root_dir, 'output', 'data');
out_log_dir = fullfile(root_dir, 'output', 'logs');

% Dynare should be available in Octave/MATLAB path.
% (Course requirement: avoid absolute paths; please configure Dynare in your environment.)
if exist('dynare', 'file') ~= 2
    error('Dynare not found in path. Please install Dynare and add it to Octave path before running.');
end

addpath(orig_dir);

old_dir = pwd();
cleanup = onCleanup(@() cd(old_dir));
cd(orig_dir);

robot_f_ss;

code_dir = fileparts(mfilename('fullpath'));
root_dir = fileparts(code_dir);
orig_dir = fullfile(code_dir, 'original');
out_data_dir = fullfile(root_dir, 'output', 'data');
out_log_dir = fullfile(root_dir, 'output', 'logs');
cd(orig_dir);
if exist(fullfile(root_dir, 'var_ss'), 'file')
    copyfile(fullfile(root_dir, 'var_ss'), fullfile(orig_dir, 'var_ss'));
end
dynare robot_f;

code_dir = fileparts(mfilename('fullpath'));
root_dir = fileparts(code_dir);
orig_dir = fullfile(code_dir, 'original');
out_data_dir = fullfile(root_dir, 'output', 'data');
out_log_dir = fullfile(root_dir, 'output', 'logs');

if exist(fullfile(orig_dir, 'robot_f.log'), 'file')
    copyfile(fullfile(orig_dir, 'robot_f.log'), fullfile(out_log_dir, 'robot_f.log'));
end
if exist(fullfile(orig_dir, 'var_ss'), 'file')
    copyfile(fullfile(orig_dir, 'var_ss'), fullfile(out_data_dir, 'var_ss.mat'));
end
if exist(fullfile(orig_dir, 'robot_f', 'Output', 'robot_f_results.mat'), 'file')
    copyfile(fullfile(orig_dir, 'robot_f', 'Output', 'robot_f_results.mat'), fullfile(out_data_dir, 'robot_f_results.mat'));
end

fprintf('Baseline model finished successfully.\n');
