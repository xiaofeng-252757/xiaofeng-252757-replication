% 批处理：运行图1脚本并保存图像与关键变量
1;

code_dir = fileparts(mfilename('fullpath'));
root_dir = fileparts(code_dir);
orig_dir = fullfile(code_dir, 'original');
out_fig_dir = fullfile(root_dir, 'output', 'figures');
out_data_dir = fullfile(root_dir, 'output', 'data');
out_log_dir = fullfile(root_dir, 'output', 'logs');

% Dynare should be available in Octave/MATLAB path.
% (Course requirement: avoid absolute paths; please configure Dynare in your environment.)
if exist('dynare', 'file') ~= 2
    error('Dynare not found in path. Please install Dynare and add it to Octave path before running.');
end

graphics_toolkit('gnuplot');
set(0, 'defaultfigurevisible', 'off');
addpath(orig_dir);

old_dir = pwd();
cleanup = onCleanup(@() cd(old_dir));
cd(orig_dir);

robot_f_ss;

code_dir = fileparts(mfilename('fullpath'));
root_dir = fileparts(code_dir);
orig_dir = fullfile(code_dir, 'original');
out_fig_dir = fullfile(root_dir, 'output', 'figures');
out_data_dir = fullfile(root_dir, 'output', 'data');
out_log_dir = fullfile(root_dir, 'output', 'logs');
cd(orig_dir);
if exist(fullfile(root_dir, 'var_ss'), 'file')
    copyfile(fullfile(root_dir, 'var_ss'), fullfile(orig_dir, 'var_ss'));
end
dynare robot_f;

code_dir = fileparts(mfilename('fullpath'));
root_dir = fileparts(code_dir);
orig_dir = fullfile(code_dir, 'original');
out_fig_dir = fullfile(root_dir, 'output', 'figures');
out_data_dir = fullfile(root_dir, 'output', 'data');
out_log_dir = fullfile(root_dir, 'output', 'logs');
figure;
T = 0:1:20;
x = zeros(21,1);
subplot(4,4,1); plot(T,Y_ee_xi,'-k',T,x,'--k','LineWidth',1.3); title('经济总产出','Fontsize',13);
subplot(4,4,2); plot(T,A_ee_xi,'-k',T,x,'--k','LineWidth',1.3); title('机器人技术创新','Fontsize',13);
subplot(4,4,3); plot(T,ROB_F_ee_xi,'-k',T,x,'--k','LineWidth',1.3); title('机器人规模','Fontsize',13);
subplot(4,4,4); plot(T,R_F_ee_xi,'-k',T,x,'--k','LineWidth',1.3); title('机器人回报','Fontsize',13);
subplot(4,4,5); plot(T,K_ee_xi,'-k',T,x,'--k','LineWidth',1.3); title('传统资本','Fontsize',13);
subplot(4,4,6); plot(T,R_K_ee_xi,'-k',T,x,'--k','LineWidth',1.3); title('传统资本回报','Fontsize',13);
subplot(4,4,7); plot(T,L_ee_xi,'-k',T,x,'--k','LineWidth',1.3); title('低技能劳动','Fontsize',13);
subplot(4,4,8); plot(T,w_ee_xi,'-k',T,x,'--k','LineWidth',1.3); title('低技能实际工资','Fontsize',13);
subplot(4,4,9); plot(T,L_S_ee_xi,'-k',T,x,'--k','LineWidth',1.3); title('高技能劳动','Fontsize',13);
subplot(4,4,10); plot(T,w_S_ee_xi,'-k',T,x,'--k','LineWidth',1.3); title('高技能实际工资','Fontsize',13);
subplot(4,4,11); plot(T,fe_u_ee_xi,'-k',T,x,'--k','LineWidth',1.3); title('低技能收入份额','Fontsize',13);
subplot(4,4,12); plot(T,fe_M_ee_xi,'-k',T,x,'--k','LineWidth',1.3); title('机器人收入份额','Fontsize',13);
subplot(4,4,13); plot(T,C1_ee_xi,'-k',T,x,'--k','LineWidth',1.3); title('低技能家庭实际收入','Fontsize',13);
subplot(4,4,14); plot(T,C2_ee_xi,'-k',T,x,'--k','LineWidth',1.3); title('高技能家庭实际收入','Fontsize',13);
subplot(4,4,15); plot(T,income3_ee_xi,'-k',T,x,'--k','LineWidth',1.3); title('资本型家庭实际收入','Fontsize',13);
subplot(4,4,16); plot(T,INDX_ee_xi,'-k',T,x,'--k','LineWidth',1.3); title('收入差距指数','Fontsize',13);
print(gcf, fullfile(out_fig_dir, 'fig1_reproduced.png'), '-dpng');
save(fullfile(out_data_dir, 'fig1_workspace.mat'), ...
    'Y_ee_xi', 'A_ee_xi', 'ROB_F_ee_xi', 'R_F_ee_xi', 'K_ee_xi', 'R_K_ee_xi', ...
    'L_ee_xi', 'w_ee_xi', 'L_S_ee_xi', 'w_S_ee_xi', 'fe_u_ee_xi', 'fe_M_ee_xi', ...
    'C1_ee_xi', 'C2_ee_xi', 'income3_ee_xi', 'INDX_ee_xi');

if exist(fullfile(orig_dir, 'robot_f.log'), 'file')
    copyfile(fullfile(orig_dir, 'robot_f.log'), fullfile(out_log_dir, 'robot_f_fig1_run.log'));
end

fprintf('Figure 1 finished successfully.\n');
