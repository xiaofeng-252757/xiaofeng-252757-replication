% 批处理：运行图2脚本并保存图像与关键变量
1;

code_dir = fileparts(mfilename('fullpath'));
root_dir = fileparts(code_dir);
orig_dir = fullfile(code_dir, 'original');
out_fig_dir = fullfile(root_dir, 'output', 'figures');
out_data_dir = fullfile(root_dir, 'output', 'data');

graphics_toolkit('gnuplot');
set(0, 'defaultfigurevisible', 'off');
addpath(orig_dir);

old_dir = pwd();
cleanup = onCleanup(@() cd(old_dir));
cd(orig_dir);

run('fig_2.m');

code_dir = fileparts(mfilename('fullpath'));
root_dir = fileparts(code_dir);
orig_dir = fullfile(code_dir, 'original');
out_fig_dir = fullfile(root_dir, 'output', 'figures');
out_data_dir = fullfile(root_dir, 'output', 'data');
cd(orig_dir);
print(gcf, fullfile(out_fig_dir, 'fig2_reproduced.png'), '-dpng');
save(fullfile(out_data_dir, 'fig2_workspace.mat'), ...
    'xx', 'Y', 'ROB', 'income1', 'income2', 'income3', 'INDX', ...
    'wu', 'ws', 'we', 'wu_Y', 'ws_Y', 'we_Y', 'ROB_Y');

fprintf('Figure 2 finished successfully.\n');
