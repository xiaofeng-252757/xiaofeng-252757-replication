#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Audit Table 1 empirical moments and data provenance.

This script uses the paper appendix definitions and China Statistical Yearbook
2024 expenditure-account tables to reproduce the sample empirical moments in
Table 1. It documents that while C/Y and G/Y match the 2014-2023 sample,
I/Y matches the 2014-2022 (9-year) sample mean.
"""
from __future__ import annotations

import csv
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data" / "moments"
PROCESSED_DIR = ROOT / "data" / "processed"
OUT_DIR = ROOT / "output" / "tables"
NBS_CSV = DATA_DIR / "nbs_2024_C03-10_C03-11_expenditure_gdp_series.csv"

PAPER_EMPIRICAL = {
    "C/Y": 38.19,
    "I/Y": 43.43,
    "G/Y": 16.33,
}


def read_rows(path: Path):
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def write_csv(path: Path, header, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(header)
        writer.writerows(rows)


def mean(xs):
    return sum(xs) / len(xs)


def main():
    rows = [r for r in read_rows(NBS_CSV) if r["year"].isdigit()]
    ratio_rows = []
    for r in rows:
        gdp = float(r["gdp_expenditure_100m"])
        hh = float(r["household_consumption_100m"])
        gov = float(r["govt_consumption_100m"])
        inv = float(r["gross_capital_formation_100m"])
        ratio_rows.append([
            r["year"],
            round(hh / gdp * 100, 6),
            round(gov / gdp * 100, 6),
            round(inv / gdp * 100, 6),
        ])

    # C/Y, G/Y use 2014-2023
    cy_10yr = mean([float(r[1]) for r in ratio_rows])
    gy_10yr = mean([float(r[2]) for r in ratio_rows])
    
    # I/Y matching 2014-2022
    ratio_rows_9yr = ratio_rows[:-1] # drop 2023
    iy_9yr = mean([float(r[3]) for r in ratio_rows_9yr])
    iy_10yr = mean([float(r[3]) for r in ratio_rows])

    write_csv(
        PROCESSED_DIR / "table1_nbs_yearbook_ratio_by_year.csv",
        ["year", "household_consumption_gdp_pct", "govt_consumption_gdp_pct", "gross_capital_formation_gdp_pct"],
        ratio_rows + [
            ["average_2014_2023", round(cy_10yr, 6), round(gy_10yr, 6), round(iy_10yr, 6)],
            ["average_2014_2022", "-", "-", round(iy_9yr, 6)],
            ["paper_table1", PAPER_EMPIRICAL["C/Y"], PAPER_EMPIRICAL["G/Y"], PAPER_EMPIRICAL["I/Y"]],
        ],
    )

    write_csv(
        OUT_DIR / "table1_nbs_yearbook_raw_recalculation.csv",
        ["指标", "样本期", "分子", "分母", "年度平均值_pct", "论文值_pct", "差异_pp", "数据源"],
        [
            ["居民消费/GDP", "2014—2023", "居民消费支出", "支出法国内生产总值", round(cy_10yr, 4), PAPER_EMPIRICAL["C/Y"], round(cy_10yr - PAPER_EMPIRICAL["C/Y"], 4), "中国统计年鉴2024表3-10与表3-11"],
            ["资本形成总额/GDP", "2014—2022", "资本形成总额", "支出法国内生产总值", round(iy_9yr, 4), PAPER_EMPIRICAL["I/Y"], round(iy_9yr - PAPER_EMPIRICAL["I/Y"], 4), "中国统计年鉴2024表3-10"],
            ["资本形成总额/GDP (对照)", "2014—2023", "资本形成总额", "支出法国内生产总值", round(iy_10yr, 4), PAPER_EMPIRICAL["I/Y"], round(iy_10yr - PAPER_EMPIRICAL["I/Y"], 4), "中国统计年鉴2024表3-10"],
            ["政府消费/GDP", "2014—2023", "政府消费支出", "支出法国内生产总值", round(gy_10yr, 4), PAPER_EMPIRICAL["G/Y"], round(gy_10yr - PAPER_EMPIRICAL["G/Y"], 4), "中国统计年鉴2024表3-10与表3-11"],
        ],
    )

    write_csv(
        OUT_DIR / "table1_empirical_moments_audit.csv",
        ["指标", "论文样本近似值", "本文重算值", "差异_pp", "数据源", "复现状态", "说明"],
        [
            ["C/Y", PAPER_EMPIRICAL["C/Y"], round(cy_10yr, 4), round(cy_10yr - PAPER_EMPIRICAL["C/Y"], 4), "中国统计年鉴2024表3-10与表3-11", "Exact reconstruction", "2014—2023年居民消费支出/GDP年度比率均值。"],
            ["I/Y", PAPER_EMPIRICAL["I/Y"], round(iy_9yr, 4), round(iy_9yr - PAPER_EMPIRICAL["I/Y"], 4), "中国统计年鉴2024表3-10", "Exact reconstruction conditional on 2014—2022 sample", "原文43.43%与2014—2022年资本形成总额/GDP年度比率均值43.4304%精确吻合；公开材料仍写作2014—2023年，因此本文不将这一数值对应关系表述为对原作者样本截断过程的直接证明。"],
            ["G/Y", PAPER_EMPIRICAL["G/Y"], round(gy_10yr, 4), round(gy_10yr - PAPER_EMPIRICAL["G/Y"], 4), "中国统计年鉴2024表3-10与表3-11", "Exact reconstruction", "2014—2023年政府消费支出/GDP年度比率均值。"],
        ],
    )

    write_csv(
        OUT_DIR / "table1_what_can_and_cannot_be_replicated.csv",
        ["结果", "复现状态", "说明"],
        [
            ["C/Y 经验矩", "Exact reconstruction", f"中国统计年鉴2024重算居民消费支出/GDP={cy_10yr:.4f}%，与论文38.19%完全对齐。"],
            ["I/Y 经验矩", "Exact reconstruction conditional on 2014—2022 sample", f"原文43.43%与2014—2022年均值{iy_9yr:.4f}%精确吻合；2014—2023年重算值为{iy_10yr:.4f}%；公开材料不足以直接证明原作者的实际样本截断过程。"],
            ["G/Y 经验矩", "Exact reconstruction", f"中国统计年鉴2024重算政府消费支出/GDP={gy_10yr:.4f}%，与论文16.33%完全对齐。"],
        ],
    )

    write_csv(
        OUT_DIR / "table1_sample_moments_original_sources.csv",
        ["指标", "论文样本近似值", "原文口径", "本文数据源", "本文重算值", "复现状态", "说明"],
        [
            ["C/Y", PAPER_EMPIRICAL["C/Y"], "2014—2023年居民消费支出/GDP年度平均", "中国统计年鉴2024表3-10与表3-11", round(cy_10yr, 4), "Exact reconstruction", "原文附录5与年鉴表可直接闭环。"],
            ["I/Y", PAPER_EMPIRICAL["I/Y"], "资本形成总额/GDP年度平均", "中国统计年鉴2024表3-10", round(iy_9yr, 4), "Exact reconstruction conditional on 2014—2022 sample", "原文43.43%与2014—2022年均值精确吻合；按原文写明的2014—2023年重算则为43.3018%，因此本文不将该对应关系表述为对原作者实际样本截断过程的直接证明。"],
            ["G/Y", PAPER_EMPIRICAL["G/Y"], "2014—2023年政府消费支出/GDP年度平均", "中国统计年鉴2024表3-10与表3-11", round(gy_10yr, 4), "Exact reconstruction", "原文附录5与年鉴表可直接闭环。"],
        ],
    )

    print("Table 1 provenance audit completed (with sample-period conditional logic).")


if __name__ == "__main__":
    main()
