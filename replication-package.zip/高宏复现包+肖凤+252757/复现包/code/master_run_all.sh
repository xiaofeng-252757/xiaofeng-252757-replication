#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
LOG_DIR="$ROOT/output/logs"
mkdir -p "$LOG_DIR" "$ROOT/output/figures" "$ROOT/output/tables" "$ROOT/output/data"

{
  echo "Run timestamp: $(date '+%Y-%m-%d %H:%M:%S %Z')"
  echo "Working root: $ROOT"
  echo "Octave binary: $(command -v octave)"
  octave --version | head -2
  echo "Dynare preprocessor: $(command -v dynare-preprocessor)"
  dynare-preprocessor --version || true
} > "$LOG_DIR/environment.txt" 2>&1

echo "[1/7] Running baseline model..."
octave --quiet "$ROOT/code/run_baseline_batch.m" 2>&1 | tee "$LOG_DIR/01_run_baseline.log"

echo "[2/7] Generating Figure 1..."
octave --quiet "$ROOT/code/run_fig1_batch.m" 2>&1 | tee "$LOG_DIR/02_run_fig1.log"

echo "[3/7] Generating Figure 2..."
octave --quiet "$ROOT/code/run_fig2_batch.m" 2>&1 | tee "$LOG_DIR/03_run_fig2.log"

echo "[4/7] Generating Figure 3..."
octave --quiet "$ROOT/code/run_fig3_batch.m" 2>&1 | tee "$LOG_DIR/04_run_fig3.log"

echo "[5/7] Exporting reproduced tables..."
octave --quiet "$ROOT/code/export_tables_batch.m" 2>&1 | tee "$LOG_DIR/05_export_tables.log"

echo "[6/7] Reproducing Table 1 sample moments with public-source cross-check..."
python3 "$ROOT/code/compute_table1_sample_moments.py" 2>&1 | tee "$LOG_DIR/06_compute_table1_sample_moments.log"

echo "[7/7] Auditing Table 1 empirical moments and data provenance..."
python3 "$ROOT/code/audit_table1_provenance.py" 2>&1 | tee "$LOG_DIR/07_audit_table1_provenance.log"

echo "All replication tasks finished."