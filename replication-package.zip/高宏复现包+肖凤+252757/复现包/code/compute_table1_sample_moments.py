#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Compute Table 1 sample moments from *publicly accessible* data sources.

Purpose
-------
The original author code hard-codes the "paper sample" moments in Table 1.
To close the "data → code → numbers" loop required by the course, this script:

1) Downloads (or updates) the key national-account ratios from the World Bank
   WDI API and saves the raw yearly series to
   `gaohong_replication_package/data/moments/`.
2) Reads the 2022 CNIPA patent statistics (domestic applications & grants by
   patent type) and computes the technology promotion ratio A/Z.
3) Produces a reproducible sample-moment table:
   `gaohong_replication_package/output/tables/table1_sample_moments_reproduced.csv`

Notes
-----
- The paper uses China Statistical Yearbooks / Science & Technology Yearbooks.
  Those sources are not always programmatically accessible. Here we use WDI for
  the national-account ratios and R&D/GDP, and we cite CNIPA annual report for
  patent applications/grants.
- You can swap the data source by replacing the cached CSVs in
  `data/moments/` and re-running this script.

Usage
-----
python3 gaohong_replication_package/code/compute_table1_sample_moments.py
python3 gaohong_replication_package/code/compute_table1_sample_moments.py --refresh
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path
from typing import Dict, List, Tuple

import requests

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data" / "moments"
OUT_DIR = ROOT / "output" / "tables"

WDI_COUNTRY = "CHN"

# National accounts shares (% of GDP)
WDI_SERIES = {
    "consumption_output_ratio": "NE.CON.PRVT.ZS",  # Household final consumption expenditure (% of GDP)
    "investment_output_ratio": "NE.GDI.TOTL.ZS",  # Gross capital formation (% of GDP)
    "government_output_ratio": "NE.CON.GOVT.ZS",  # General government final consumption expenditure (% of GDP)
    "rd_gdp_ratio": "GB.XPD.RSDV.GD.ZS",  # Research and development expenditure (% of GDP)
}


def fetch_wdi_series(indicator: str, timeout: int = 120) -> Dict[int, float]:
    url = (
        f"https://api.worldbank.org/v2/country/{WDI_COUNTRY}/indicator/{indicator}"
        "?format=json&per_page=2000"
    )
    r = requests.get(url, timeout=timeout, headers={"User-Agent": "Mozilla/5.0"})
    r.raise_for_status()
    payload = r.json()
    if not isinstance(payload, list) or len(payload) < 2:
        raise RuntimeError(f"Unexpected WDI response for {indicator}: {payload}")

    series: Dict[int, float] = {}
    for row in payload[1]:
        if row.get("value") is None:
            continue
        try:
            year = int(row["date"])
            val = float(row["value"])
        except Exception:
            continue
        series[year] = val

    return dict(sorted(series.items()))


def write_yearly_csv(path: Path, series: Dict[int, float], col_name: str):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["year", col_name])
        for y, v in sorted(series.items()):
            w.writerow([y, v])


def read_yearly_csv(path: Path) -> Dict[int, float]:
    out: Dict[int, float] = {}
    with path.open("r", encoding="utf-8") as f:
        r = csv.DictReader(f)
        cols = r.fieldnames or []
        if len(cols) < 2:
            raise ValueError(f"Bad csv header: {cols}")
        val_col = cols[1]
        for row in r:
            out[int(row["year"])] = float(row[val_col])
    return dict(sorted(out.items()))


def mean_over_years(series: Dict[int, float], start: int, end: int) -> float:
    vals = [v for y, v in series.items() if start <= y <= end]
    if not vals:
        raise RuntimeError(f"No data in years {start}-{end}")
    return sum(vals) / len(vals)


def read_cnipa_patent_2022(path: Path) -> Tuple[float, float]:
    """Return (domestic_applications, domestic_grants) in *counts*.

    The file is a small, course-friendly cache extracted from CNIPA 2022 annual report.

    Unit convention in the csv:
    - values are in "万件" (10,000 pieces).
    """

    apps_wanjian = 0.0
    grants_wanjian = 0.0

    with path.open("r", encoding="utf-8") as f:
        r = csv.DictReader(f)
        for row in r:
            if row.get("scope") != "domestic":
                continue
            if row.get("metric") == "applications_wanjian":
                apps_wanjian += float(row["value"])
            if row.get("metric") == "grants_wanjian":
                grants_wanjian += float(row["value"])

    return apps_wanjian * 10000.0, grants_wanjian * 10000.0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--refresh", action="store_true", help="redownload WDI series")
    ap.add_argument("--na_start", type=int, default=2014, help="national accounts start year")
    ap.add_argument("--na_end", type=int, default=2023, help="national accounts end year")
    ap.add_argument("--rd_year", type=int, default=2022, help="use this year for R&D/GDP")
    args = ap.parse_args()

    DATA_DIR.mkdir(parents=True, exist_ok=True)
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    # 1) WDI series cache
    wdi_cache_paths = {
        key: DATA_DIR / f"wdi_{WDI_COUNTRY}_{ind}.csv" for key, ind in WDI_SERIES.items()
    }

    for key, ind in WDI_SERIES.items():
        p = wdi_cache_paths[key]
        if args.refresh or not p.exists():
            series = fetch_wdi_series(ind)
            write_yearly_csv(p, series, col_name=ind)

    cons = read_yearly_csv(wdi_cache_paths["consumption_output_ratio"])
    inv = read_yearly_csv(wdi_cache_paths["investment_output_ratio"])
    gov = read_yearly_csv(wdi_cache_paths["government_output_ratio"])
    rd = read_yearly_csv(wdi_cache_paths["rd_gdp_ratio"])

    # 2) CNIPA patents (A/Z)
    cnipa_csv = DATA_DIR / "cnipa_patent_2022_domestic_by_type.csv"
    if not cnipa_csv.exists():
        raise FileNotFoundError(
            f"Missing CNIPA cache: {cnipa_csv}. It should be included in the replication package."
        )
    apps_cnt, grants_cnt = read_cnipa_patent_2022(cnipa_csv)
    tech_promotion_ratio = (grants_cnt / apps_cnt) * 100.0

    # 3) Compute moments
    cons_mean = mean_over_years(cons, args.na_start, args.na_end)
    inv_mean = mean_over_years(inv, args.na_start, args.na_end)
    gov_mean = mean_over_years(gov, args.na_start, args.na_end)

    if args.rd_year not in rd:
        raise RuntimeError(f"R&D/GDP missing year {args.rd_year}")
    rd_ratio = rd[args.rd_year]

    # 4) Output table
    out_path = OUT_DIR / "table1_sample_moments_reproduced.csv"
    with out_path.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["指标", "复现口径", "数值(%)", "说明"])
        w.writerow([
            "消费产出比",
            f"WDI {WDI_SERIES['consumption_output_ratio']} 年均({args.na_start}-{args.na_end})",
            round(cons_mean, 2),
            "居民最终消费支出占GDP比重（%）",
        ])
        w.writerow([
            "投资产出比",
            f"WDI {WDI_SERIES['investment_output_ratio']} 年均({args.na_start}-{args.na_end})",
            round(inv_mean, 2),
            "资本形成总额占GDP比重（%）",
        ])
        w.writerow([
            "政府支出产出比",
            f"WDI {WDI_SERIES['government_output_ratio']} 年均({args.na_start}-{args.na_end})",
            round(gov_mean, 2),
            "政府最终消费支出占GDP比重（%）",
        ])
        w.writerow([
            "技术推广比(A/Z)",
            "CNIPA 2022 国内专利授权/申请（按三种专利类型合计）",
            round(tech_promotion_ratio, 2),
            "授权数=发明+实用新型+外观设计；申请量同口径",
        ])
        w.writerow([
            "研发支出/GDP",
            f"WDI {WDI_SERIES['rd_gdp_ratio']}（{args.rd_year}）",
            round(rd_ratio, 2),
            "研发经费支出占GDP比重（%），按论文口径取最新年份值",
        ])

    print(f"wrote {out_path}")


if __name__ == "__main__":
    main()
