# 高级宏观经济学期末复现包

本包对应论文《工业智能化与收入分配格局演变：经济发展机遇背后的分配失衡隐忧》（《中国工业经济》2026 年第 4 期），包含作者公开附件原始代码、复现报告、运行脚本、复现生成的图表与日志，以及表 1 样本经验矩的数据溯源审计文件。

目录与入口：

- 主报告（Word）位于本包外层目录，与 `复现包/` 同级
- 统一运行入口在 `code/master_run_all.sh`
- 复现产出（图、表、误差核验、日志）在 `output/`

文件列表：
- [../论文复现报告.docx](../论文复现报告.docx)
- [自述文件.md](自述文件.md)

## 运行方式

在已安装 Octave 与 Dynare 的环境中，进入本目录后执行：

```bash
bash code/master_run_all.sh > output/logs/master_run.log 2>&1
```

运行完成后，图、表和日志将写入 [output](output)。

如需保留 Matlab/Octave 的 m 文件入口，也可以调用 [code/master_run_all.m](code/master_run_all.m)，它会转而调用上述 shell 脚本。

## 核心复现产出与核验文件

- 图 1： [output/figures/fig1_reproduced.png](output/figures/fig1_reproduced.png)
- 图 2： [output/figures/fig2_reproduced.png](output/figures/fig2_reproduced.png)
- 图 3： [output/figures/fig3_reproduced.png](output/figures/fig3_reproduced.png)
- 表 1（模型稳态拟合）： [output/tables/table1_model_fit.csv](output/tables/table1_model_fit.csv)
- 表 2（长期稳态）： [output/tables/table2_steady_state.csv](output/tables/table2_steady_state.csv)
- 误差核验： [output/tables/replication_check.csv](output/tables/replication_check.csv)
- 总日志： [output/logs/master_run.log](output/logs/master_run.log)

## 表 1 的数据溯源（Data Provenance）

表 1 的“样本经验矩”并不都是“拿到原始数据就能逐项精确重算”的类型：有些可以用公开数据直接重算（或近似重算），有些只能用公开替代口径交叉核对，也有些本身就是二手文献校准值。

据此，本包将其分为三类证据（Exact / Alternative / Secondary），并在审计表中逐项说明数据来源、计算方式与可复核边界。相关文件如下：

- 审计脚本： [code/audit_table1_provenance.py](code/audit_table1_provenance.py)
- 表 1 经验矩审计表： [output/tables/table1_empirical_moments_audit.csv](output/tables/table1_empirical_moments_audit.csv)
- Data Provenance 表： [output/tables/table1_data_provenance.csv](output/tables/table1_data_provenance.csv)
- NBS 年鉴转录重算： [output/tables/table1_nbs_yearbook_raw_recalculation.csv](output/tables/table1_nbs_yearbook_raw_recalculation.csv)
- WDI/CNIPA 公开交叉检验： [output/tables/table1_sample_moments_reproduced.csv](output/tables/table1_sample_moments_reproduced.csv)

## 目录说明

- [code](code)：主脚本、批处理脚本、数据溯源审计脚本与作者原始代码
- [data](data)：数据说明、WDI/CNIPA/NBS 转录数据与来源文件
- [output](output)：本次复现生成的图、表、日志和中间结果
- [paper](paper)：论文原文、附录与公开附件使用说明
- [optional_supplementary_code](optional_supplementary_code)：附录拓展与呈现层脚本（不影响核心复现流程）

## 环境说明

作者原始 readme 标注的推荐环境为 Matlab 2022b + Dynare 5.4；本复现包在当前工作区实际验证通过的环境为 GNU Octave 7.3.0 + Dynare 5.3。

注：Octave 下连续调用 Dynare 时会清空前次变量，因此图 3 的生成使用了兼容脚本 [code/run_fig3_batch.m](code/run_fig3_batch.m)。该兼容仅调整调用方式，不改动任何模型方程、参数或实验目标。绘图字体、线条渲染和极小浮点残差属于跨软件环境差异，不代表复现失败。